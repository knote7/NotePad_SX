﻿using System;
using System.Windows.Forms;
using NiggerDick;
using ScintillaNET;

namespace ScintillaFindReplaceControl
{
    public partial class FindReplace : Form
    {
        public SearchFlags _findSearchFlags;
        public SearchFlags _replaceSearchFlags;


        // Pointer to the Scintilla control to apply actions to


        // Search Flags for Find and for Replace

        public void ReplaceAll(string findText, string replaceText)
        {
            var pos = 0;
            // Iterate until text is no longer found
            while (pos >= 0)
            {
                NotePad frm = (NotePad)this.Owner;
                pos =ReplaceNext(findText, replaceText);
            }
        }

        /// <summary>
        ///     Creates an instance of the FindReplace dialogs
        /// </summary>
        public FindReplace()
        {
            InitializeComponent();
            NotePad frm = (NotePad)this.Owner;
            // Initialise the SearchFlags
            _findSearchFlags = new SearchFlags();
           _replaceSearchFlags = new SearchFlags();
            _findSearchFlags = SearchFlags.None;
            _replaceSearchFlags = SearchFlags.None;
        }
   
    


        /// <summary>
        ///     Prevents the form from being destroyed
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void FindReplace_FormClosing(object sender, FormClosingEventArgs e)
        {
            Hide();
            e.Cancel = true;
        }

        /// <summary>
        ///     Handles the 'Find Previous' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonFindPrev_Click(object sender, EventArgs e)
        {
            NotePad frm1 = (NotePad)Owner;
            SetFindSearchFlags();
            var text = textBoxFind.Text;
            frm1.FindPrevious(text, _findSearchFlags);
        }

        /// <summary>
        ///     Handles the 'Find Next' button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonFindNext_Click(object sender, EventArgs e)
        {
            NotePad frm1 = (NotePad)Owner;
            SetFindSearchFlags();
            var text = textBoxFind.Text;
            frm1.FindNext(text, _findSearchFlags);
        }
        public int ReplaceNext(string findText, string replaceText)
        {
            NotePad frm = (NotePad)this.Owner;
            var pos = frm.FindNext(findText, _replaceSearchFlags);
            if (pos >= 0)
                frm.nigger_button_replace_next(replaceText);
            return pos;
        }

        /// <summary>
        ///     Handles the Replace Next button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonReplaceNext_Click(object sender, EventArgs e)
        {
            NotePad frm1 = (NotePad)Owner;
            SetReplaceSearchFlags();
            ReplaceNext(textBoxFindRep.Text, textBoxReplace.Text);
        }

        /// <summary>
        ///     Handles with Replace All button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonReplaceAll_Click(object sender, EventArgs e)
        {
            NotePad frm = (NotePad)this.Owner;
            SetReplaceSearchFlags();
             frm.buttonReplaceAll_Click();
            ReplaceAll(textBoxFindRep.Text,textBoxReplace.Text);
            frm.buttonReplaceAl32l_Click();



        }

        /// <summary>
        ///     Set the Find search flags based on checked options
        /// </summary>
        public void SetFindSearchFlags()
        {
            NotePad frm = (NotePad)this.Owner;

            if (checkBoxMatchCase.Checked)
               _findSearchFlags |= SearchFlags.MatchCase;
            if (checkBoxRegEx.Checked)
                _findSearchFlags |= SearchFlags.Regex;
            if (checkBoxWholeWord.Checked)
              _findSearchFlags |= SearchFlags.WholeWord;
            if (checkBoxWordStart.Checked)
                _findSearchFlags |= SearchFlags.WordStart;
        }

        /// <summary>
        ///     Set the Replace search flags based on checked options
        /// </summary>
        public void SetReplaceSearchFlags()
        {
            NotePad frm = (NotePad)this.Owner;
            if (checkBoxMatchCaseRep.Checked)
                _replaceSearchFlags |= SearchFlags.MatchCase;
            if (checkBoxRegExRep.Checked)
                _replaceSearchFlags |= SearchFlags.Regex;
            if (checkBoxWholeWordRep.Checked)
                _replaceSearchFlags |= SearchFlags.WholeWord;
            if (checkBoxWordStartRep.Checked)
                _replaceSearchFlags |= SearchFlags.WordStart;
        }

     

        public void FindReplace_Load(object sender, EventArgs e)
        {
            
        }

        public void richTextBox_Form2_Receive_TextChanged(object sender, EventArgs e)
        {
            
        }

        public void iTalk_Button_11_Click(object sender, EventArgs e)
        {

            
        }

        public void timer1_Tick(object sender, EventArgs e)
        {
           
        }

        public void button1_Click(object sender, EventArgs e)
        {
            Close();
        }

        public void iTalk_Button_11_Click_1(object sender, EventArgs e)
        {
            
        }

        private void checkBoxWordStartRep_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
          
        }
    }
}