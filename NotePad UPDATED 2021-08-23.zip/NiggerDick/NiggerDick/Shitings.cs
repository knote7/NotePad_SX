﻿using Sexploit_Y;
using sxlib.Static;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NiggerDick
{
    public partial class Shitings : Form
    {
        NotePad frm1;
        public Shitings()
        {
            InitializeComponent();
        }
        public Shitings(NotePad fr_FORMm1)
        {
            InitializeComponent();
            frm1 = fr_FORMm1;
        }


        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            

        }

        private void Shitings_Load(object sender, EventArgs e)
        {
            this.AutoDildo.CheckedChanged += new System.EventHandler(this.NoEven);
            this.internalturelove.CheckedChanged += new System.EventHandler(this.NoEven);
            this.unlucky.CheckedChanged += new System.EventHandler(this.NoEven);
            this.notfullautoinbuilding.CheckedChanged += new System.EventHandler(this.NoEven);
            this.wap.CheckedChanged += new System.EventHandler(this.NoEven);
            this.checkBox1.CheckedChanged += new System.EventHandler(this.NoEven);

           

            string aa = this.inicls.GetIniValue("Settings", "AutoAttach", "./Nbin/Settings.ini");
            string bb = this.inicls.GetIniValue("Settings", "AutoLaunch", "./Nbin/Settings.ini");
            string cc = this.inicls.GetIniValue("Settings", "UnlockFPS", "./Nbin/Settings.ini");
            string dd = this.inicls.GetIniValue("Settings", "InternalUI", "./Nbin/Settings.ini");
            string ee = this.inicls.GetIniValue("Settings", "TopMost", "./Nbin/Settings.ini");

            bool a;
            bool b;
            bool c;
            bool d;
            bool eee;
            if (Boolean.TryParse(aa, out a))
            {
                this.AutoDildo.Checked = a;
            }
            else
            {
            }
            if (Boolean.TryParse(bb, out b))
            {
                this.notfullautoinbuilding.Checked = b;
            }
            else
            {
            }
            if (Boolean.TryParse(cc, out c))
            {
                this.unlucky.Checked = c;
            }
            else
            {
            }
            if (Boolean.TryParse(dd, out d))
            {
                this.internalturelove.Checked = d;
            }
            else
            {
            }
            if (Boolean.TryParse(ee, out eee))
            {
                this.wap.Checked = eee;
            }
            else
            {
            }
            this.AutoDildo.CheckedChanged += new System.EventHandler(this.Update);
            this.internalturelove.CheckedChanged += new System.EventHandler(this.Update);
            this.unlucky.CheckedChanged += new System.EventHandler(this.Update);
            this.notfullautoinbuilding.CheckedChanged += new System.EventHandler(this.Update);
            this.wap.CheckedChanged += new System.EventHandler(this.Update);
            this.checkBox1.CheckedChanged += new System.EventHandler(this.Update);

        }
        private iniClass inicls = new iniClass();
        private void NoEven(object sender, EventArgs e)
        {
            string da = "please the niggershit";
        }
        private void Update(object sender, EventArgs e)
        {
             //idk why but sx GetOptions not working maybe im a skidded
            //idk why but sx GetOptions not working maybe im a skidded
            this.inicls.SetIniValue("Settings", "AutoAttach", this.AutoDildo.Checked.ToString(), "./Nbin/Settings.ini");
            this.inicls.SetIniValue("Settings", "AutoLaunch", this.notfullautoinbuilding.Checked.ToString(), "./Nbin/Settings.ini");
            this.inicls.SetIniValue("Settings", "UnlockFPS", this.unlucky.Checked.ToString(), "./Nbin/Settings.ini");
            this.inicls.SetIniValue("Settings", "InternalUI", this.internalturelove.Checked.ToString(), "./Nbin/Settings.ini");
            this.inicls.SetIniValue("Settings", "TopMost", this.wap.Checked.ToString(), "./Nbin/Settings.ini");
            this.inicls.SetIniValue("Settings", "InjectedMes", this.checkBox1.Checked.ToString(), "./Nbin/Settings.ini");
            Data.Options options2 = new Data.Options
            {
                AutoAttach = this.AutoDildo.Checked,
                AutoLaunch = this.notfullautoinbuilding.Checked,
                UnlockFPS = this.unlucky.Checked,
                InternalUI = this.internalturelove.Checked,
                TopMost = this.wap.Checked
            };
            Functions.Lib.SetOptions(options2);
            frm1.ugly_highlight_text(this.wap.Checked);
           
        }
        
    }
}
