﻿
namespace NiggerDick
{
    partial class Shitings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Shitings));
            this.AutoDildo = new System.Windows.Forms.CheckBox();
            this.internalturelove = new System.Windows.Forms.CheckBox();
            this.unlucky = new System.Windows.Forms.CheckBox();
            this.notfullautoinbuilding = new System.Windows.Forms.CheckBox();
            this.wap = new System.Windows.Forms.CheckBox();
            this.iTalk_Label1 = new iTalk.iTalk_Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // AutoDildo
            // 
            this.AutoDildo.AutoSize = true;
            this.AutoDildo.Font = new System.Drawing.Font("Consolas", 10F);
            this.AutoDildo.Location = new System.Drawing.Point(28, 34);
            this.AutoDildo.Name = "AutoDildo";
            this.AutoDildo.Size = new System.Drawing.Size(107, 21);
            this.AutoDildo.TabIndex = 0;
            this.AutoDildo.Text = "AutoAttach";
            this.AutoDildo.UseVisualStyleBackColor = true;
            // 
            // internalturelove
            // 
            this.internalturelove.AutoSize = true;
            this.internalturelove.Font = new System.Drawing.Font("Consolas", 10F);
            this.internalturelove.Location = new System.Drawing.Point(28, 77);
            this.internalturelove.Name = "internalturelove";
            this.internalturelove.Size = new System.Drawing.Size(115, 21);
            this.internalturelove.TabIndex = 2;
            this.internalturelove.Text = "Internal UI";
            this.internalturelove.UseVisualStyleBackColor = true;
            // 
            // unlucky
            // 
            this.unlucky.AutoSize = true;
            this.unlucky.Font = new System.Drawing.Font("Consolas", 10F);
            this.unlucky.Location = new System.Drawing.Point(28, 168);
            this.unlucky.Name = "unlucky";
            this.unlucky.Size = new System.Drawing.Size(107, 21);
            this.unlucky.TabIndex = 3;
            this.unlucky.Text = "Unlock FPS";
            this.unlucky.UseVisualStyleBackColor = true;
            // 
            // notfullautoinbuilding
            // 
            this.notfullautoinbuilding.AutoSize = true;
            this.notfullautoinbuilding.Font = new System.Drawing.Font("Consolas", 10F);
            this.notfullautoinbuilding.Location = new System.Drawing.Point(28, 122);
            this.notfullautoinbuilding.Name = "notfullautoinbuilding";
            this.notfullautoinbuilding.Size = new System.Drawing.Size(115, 21);
            this.notfullautoinbuilding.TabIndex = 4;
            this.notfullautoinbuilding.Text = "Auto Launch";
            this.notfullautoinbuilding.UseVisualStyleBackColor = true;
            // 
            // wap
            // 
            this.wap.AutoSize = true;
            this.wap.Font = new System.Drawing.Font("Consolas", 10F);
            this.wap.Location = new System.Drawing.Point(28, 212);
            this.wap.Name = "wap";
            this.wap.Size = new System.Drawing.Size(91, 21);
            this.wap.TabIndex = 5;
            this.wap.Text = "Top Most";
            this.wap.UseVisualStyleBackColor = true;
            // 
            // iTalk_Label1
            // 
            this.iTalk_Label1.AutoSize = true;
            this.iTalk_Label1.BackColor = System.Drawing.Color.Transparent;
            this.iTalk_Label1.Font = new System.Drawing.Font("Consolas", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.iTalk_Label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(142)))));
            this.iTalk_Label1.Location = new System.Drawing.Point(12, 9);
            this.iTalk_Label1.Name = "iTalk_Label1";
            this.iTalk_Label1.Size = new System.Drawing.Size(115, 13);
            this.iTalk_Label1.TabIndex = 1;
            this.iTalk_Label1.Text = "Injection Settings";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Font = new System.Drawing.Font("Consolas", 10F);
            this.checkBox1.Location = new System.Drawing.Point(28, 257);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(155, 21);
            this.checkBox1.TabIndex = 6;
            this.checkBox1.Text = "Injected Message";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // Shitings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(349, 322);
            this.Controls.Add(this.checkBox1);
            this.Controls.Add(this.wap);
            this.Controls.Add(this.notfullautoinbuilding);
            this.Controls.Add(this.unlucky);
            this.Controls.Add(this.internalturelove);
            this.Controls.Add(this.iTalk_Label1);
            this.Controls.Add(this.AutoDildo);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Shitings";
            this.Text = "Settings";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.Shitings_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.CheckBox AutoDildo;
        private iTalk.iTalk_Label iTalk_Label1;
        private System.Windows.Forms.CheckBox internalturelove;
        private System.Windows.Forms.CheckBox unlucky;
        private System.Windows.Forms.CheckBox notfullautoinbuilding;
        private System.Windows.Forms.CheckBox wap;
        private System.Windows.Forms.CheckBox checkBox1;
    }
}