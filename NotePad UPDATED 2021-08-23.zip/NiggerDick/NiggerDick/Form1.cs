﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Policy;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using ScintillaFindReplaceControl;
using ScintillaNET;
using Sexploit_Y;
using sxlib;
using sxlib.Specialized;
using sxlib.Static;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrackBar;
using static ScintillaNET.Style;

namespace NiggerDick
{
    public partial class NotePad : Form
    {
        [DllImport("Kernel32.dll")]
        public static extern IntPtr CreateMutex(IntPtr lpMutexAttributes, bool initialOwner, string lpName);
        public bool Loaded;
        public static string Direct = Directory.GetCurrentDirectory();
        public NotePad()
        {
            InitializeComponent();
            
        }
        private static void HubEvent(List<SxLibBase.SynHubEntry> Entries)
        {
            foreach (SxLibBase.SynHubEntry synHubEntry in Entries)
            {
                if (NotePad.data == synHubEntry.Name)
                {
                    
                    synHubEntry.Execute();
                }
            }
        }
        private async void SynLoadEvent(SxLibBase.SynLoadEvents Event, object Param)
        {
            switch (Event)
            {
                case SxLibBase.SynLoadEvents.CHECKING_WL:
                    this.label1.Text = "Checking whitelist...";
                    
                    return;
                case SxLibBase.SynLoadEvents.CHANGING_WL:
                    this.label1.Text = "Changing whitelist...";
                   
                    return;
                case SxLibBase.SynLoadEvents.DOWNLOADING_DATA:
                    this.label1.Text = "Downloading data..";
                  
                    return;
                case SxLibBase.SynLoadEvents.CHECKING_DATA:
                    this.label1.Text = "Checking data...";
                   
                    return;
                case SxLibBase.SynLoadEvents.DOWNLOADING_DLLS:
                    this.label1.Text = "Downloading DLLs...";
                   
                    return;
                case SxLibBase.SynLoadEvents.READY:

                    string aa = this.inicls.GetIniValue("Settings", "AutoAttach", "./Nbin/Settings.ini");
                    string bb = this.inicls.GetIniValue("Settings", "AutoLaunch", "./Nbin/Settings.ini");
                    string cc = this.inicls.GetIniValue("Settings", "UnlockFPS", "./Nbin/Settings.ini");
                    string dd = this.inicls.GetIniValue("Settings", "InternalUI", "./Nbin/Settings.ini");
                    string ee = this.inicls.GetIniValue("Settings", "TopMost", "./Nbin/Settings.ini");

                    bool a;
                    bool b;
                    bool c;
                    bool d;
                    bool eee;

                    if (!Boolean.TryParse(aa, out a))
                    {
                    }
                    if (!Boolean.TryParse(bb, out b))
                    {
                    }
                    if (!Boolean.TryParse(cc, out c))
                    {
                    }
                    if (!Boolean.TryParse(dd, out d))
                    {
                    }
                    if (!Boolean.TryParse(ee, out eee))
                    {
                    }
                    Data.Options options2 = new Data.Options
                    {
                        AutoAttach = a,
                        AutoLaunch = b,
                        UnlockFPS = c,
                        InternalUI = d,
                        TopMost = eee
                    };
                    Functions.Lib.SetOptions(options2);


                    this.label1.Text = "Ready to launch!";
                    Loaded = true;
                    Functions.Lib.ScriptHubEvent += new SxLibWinForms.SynScriptHubDelegate(NotePad.HubEvent);
                    this.scintilla2.ReadOnly = false;
                   

                    


                   
                    

                    await Task.Delay(1500);
                    this.label1.Text = "UTF-8";

                    return;
                default:
                    return;
            }
        }

        private async void SynAttachEvent(SxLibBase.SynAttachEvents Event, object Param)
        {

            switch (Event)
            {
                case SxLibBase.SynAttachEvents.REINJECTING:
                    label1.Text = "Reinjecting";
                    return;
                case SxLibBase.SynAttachEvents.NOT_INJECTED:
                    label1.Text = "Not Injected";
                    await Task.Delay(1500);
                    label1.Text = "UTF-8";
                    return;
                case SxLibBase.SynAttachEvents.NOT_RUNNING_LATEST_VER_UPDATING:
                    label1.Text = "NOT_RUNNING_LATEST_VER";
                    await Task.Delay(1500);
                    label1.Text = "UTF-8";
                    return;
                case SxLibBase.SynAttachEvents.NOT_UPDATED:

                    label1.Text = "S^X is not up to date!";
                    await Task.Delay(1500);
                    label1.Text = "UTF-8";
                    return;
                case SxLibBase.SynAttachEvents.PROC_CREATION:
                    
                    return;
                case SxLibBase.SynAttachEvents.PROC_DELETION:
                    
                    return;
                case SxLibBase.SynAttachEvents.SCANNING:
                    label1.Text = "Scanning";
                    return;
                case SxLibBase.SynAttachEvents.CHECKING:
                    label1.Text = "Checking";
                    return;
                case SxLibBase.SynAttachEvents.CHECKING_WHITELIST:
                    label1.Text = "Checking Whitelist";
                    return;
                case SxLibBase.SynAttachEvents.FAILED_TO_UPDATE:
                    label1.Text = "Failed to Update!";
                    await Task.Delay(1500);
                    label1.Text = "UTF-8";
                    return;
                case SxLibBase.SynAttachEvents.FAILED_TO_ATTACH:
                    label1.Text = "Failed to Attach!";
                    await Task.Delay(1500);
                    label1.Text = "UTF-8";
                    return;
                case SxLibBase.SynAttachEvents.ALREADY_INJECTED:
                    label1.Text = "Already Injected!";
                    await Task.Delay(1500);
                    label1.Text = "UTF-8";
                    return;
                case SxLibBase.SynAttachEvents.UPDATING_DLLS:
                    label1.Text = "Updating DLLs";
                    return;
                case SxLibBase.SynAttachEvents.INJECTING:
                    label1.Text = "Injecting";
                    return;
                case SxLibBase.SynAttachEvents.READY:
                    label1.Text = "Ready";
                    await Task.Delay(1500);
                    label1.Text = "UTF-8";
                    return;
                case SxLibBase.SynAttachEvents.FAILED_TO_FIND:
                    label1.Text = "Failed to find";
                    await Task.Delay(1500);
                    label1.Text = "UTF-8";
                    return;
            }
        }
        private void Populate(string path)
        {
            listBox1.Items.Clear();

            DirectoryInfo dinfo = new DirectoryInfo(Application.StartupPath + path);
            FileInfo[] Files = dinfo.GetFiles("*.txt");
            FileInfo[] Files1 = dinfo.GetFiles("*.lua");
            foreach (FileInfo file in Files)
            {
                listBox1.Items.Add(file.Name);
            }

            foreach (FileInfo file in Files1)
            {
                listBox1.Items.Add(file.Name);
            }
        }
        public void niggershitnigger()
        {
            MessageBox.Show("adasd");
        }
        
            
            
        public static void PopulateListBox(ListBox lsb, string Folder, string FileType)
        {
            DirectoryInfo dinfo = new DirectoryInfo(Folder);
            FileInfo[] Files = dinfo.GetFiles(FileType);
            foreach (FileInfo file in Files)
            {
                lsb.Items.Add(file.Name);
            }
        }
        private static string ReadLine(string text, int lineNumber)
        {
            var reader = new StringReader(text);

            string line;
            int currentLineNumber = 0;

            do
            {
                currentLineNumber += 1;
                line = reader.ReadLine();
            }
            while (line != null && currentLineNumber < lineNumber);

            return (currentLineNumber == lineNumber) ? line :
                                                       string.Empty;
        }
        private void button3_Click(object sender, EventArgs e)
        {
                                                       //StreamReader를 닫아줌
        }



        private void NotePad_Load(object sender, EventArgs e)
        {
            
            if (!Directory.Exists("scripts"))
            {
                Directory.CreateDirectory("scripts");
            }

            listBox1.Items.Clear();
            Functions.PopulateListBox(listBox1, "./Scripts", "*.txt");
            Functions.PopulateListBox(listBox1, "./Scripts", "*.lua");

            string Locc = this.inicls.GetIniValue("Save", "Save", "./Nbin/Settings.ini");

            this.FileLocation = Locc;
            if (!string.IsNullOrEmpty(Locc))
            {
                savedshit = File.ReadAllText(FileLocation);
            }

            string SettingsTOPMOST = this.inicls.GetIniValue("Settings", "TopMost", "./Nbin/Settings.ini");
            if (SettingsTOPMOST == "")
            {
                this.TopMost = false;
            }
            else if (SettingsTOPMOST == "True")
            {
                this.TopMost = true;
            }
            else if (SettingsTOPMOST == "False")
            {
                this.TopMost = false;
            }
            else
            {
                MessageBox.Show("Something went wrong.","failed to getting setting value");
            }
            string Siz = this.inicls.GetIniValue("Point", "Siz", "./Nbin/Settings.ini");
            string Loc = this.inicls.GetIniValue("Location", "Loc", "./Nbin/Settings.ini");
            if (Siz == "") { }
            else
            {
                string[] coords2 = Siz.Split(',');
                Size point2 = new Size(int.Parse(coords2[0]), int.Parse(coords2[1]));
                this.Size = point2;

            }

            if (Loc == "") { }
            else
            {
                string[] coords = Loc.Split(',');
                Point point = new Point(int.Parse(coords[0]), int.Parse(coords[1]));
                this.Location = point;
            }
            string font = this.inicls.GetIniValue("Font", "font", "./Nbin/Settings.ini");
            

            연결된적있음 = false; 
            Loaded = false;
            니거 = false;
            

            if (!Directory.Exists("./Nbin/"))
            {
                Directory.CreateDirectory("./Nbin");
                File.Create("./Nbin/Settings.ini");
            }
            if (!File.Exists("./Nbin/INPUT"))
            {
                File.Create("./Nbin/INPUT").Close();
            }
            Functions.Lib = SxLib.InitializeWinForms(this, Directory.GetCurrentDirectory());
            Functions.Lib.Load();
            Functions.Lib.LoadEvent += this.SynLoadEvent;
            scintilla2.Text = "";
            this.scintilla2.Text = File.ReadAllText("./Nbin/INPUT");








            this.scintilla2.ForeColor = Color.Black;
            this.scintilla2.BackColor = Color.FromArgb(101, 148, 239);
            string str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string str2 = "0123456789";
            string str3 = "ŠšŒœŸÿÀàÁáÂâÃãÄäÅåÆæÇçÈèÉéÊêËëÌìÍíÎîÏïÐðÑñÒòÓóÔôÕõÖØøÙùÚúÛûÜüÝýÞþßö";
            this.scintilla2.StyleResetDefault();
            //this.scintilla2.Styles[32].Font = "Consolas";
            if (font == "")
            {
                this.scintilla2.Styles[32].Font = "Consolas";
            }
            else
            {
                FontShit = font;
                this.scintilla2.Styles[32].Font = FontShit;
            }
            this.scintilla2.Styles[32].Size = 11;
            this.scintilla2.StyleClearAll();
            this.scintilla2.Styles[0].ForeColor = Color.Silver;
            this.scintilla2.Styles[1].ForeColor = Color.FromArgb(0, 0, 127, 0);
            this.scintilla2.Styles[2].ForeColor = Color.FromArgb(0, 0, 127, 0);
            this.scintilla2.Styles[4].ForeColor = Color.FromArgb(0, 0, 127, 127);
            this.scintilla2.Styles[5].ForeColor = Color.FromArgb(0, 0, 0, 127);
            this.scintilla2.Styles[13].ForeColor = Color.FromArgb(0, 255, 128, 0);
            this.scintilla2.Styles[14].ForeColor = Color.FromArgb(0, 255, 0, 0);
            this.scintilla2.Styles[15].ForeColor = Color.DarkSlateBlue;
            this.scintilla2.Styles[6].ForeColor = Color.FromArgb(0, 127, 0, 127);
            this.scintilla2.Styles[7].ForeColor = Color.FromArgb(0, 127, 0, 127);
            this.scintilla2.Styles[8].ForeColor = Color.FromArgb(0, 127, 0, 127);
            this.scintilla2.Styles[10].ForeColor = Color.FromArgb(0, 127, 127, 127);
            this.scintilla2.Styles[9].ForeColor = Color.Maroon;
            this.scintilla2.Lexer = Lexer.Lua;
            this.scintilla2.WordChars = str + str2 + str3;
            this.scintilla2.SetKeywords(0, "info and break do else elseif end for function if in local nil not or repeat return then until while false true goto assert collectgarbage dofile _G getmetatable ipairs loadfile next pairs pcall print rawequal bit rawget rawset metatable setmetatable tonumber tostring type _VERSION xpcall string table math coroutine io os debug getfenv gcinfo load loadlib loadstring require select setfenv unpack _LOADED LUA_PATH _REQUIREDNAME package rawlen package bit32 utf8 _ENV string.byte string.char string.dump string.find hookfunction hookmetamethod readfile writefile appendfile newcclosure string.format rconsoleprint rconsoleinfo rconsolewarn rconsoleerr rconsoleclear rconsolename rconsoleinput printconsole string.gsub string.len string.lower string.rep string.sub string.upper table.concat table.insert table.remove table.sort math.abs math.acos math.asin math.atan math.atan2 math.ceil math.cos math.deg math.exp math.floor math.frexp math.ldexp math.log math.max math.min math.pi math.pow math.rad math.random math.randomseed math.sin math.sqrt math.tan string.gfind string.gmatch string.match string.reverse string.pack string.packsize string.unpack  table.foreach table.foreachi table.getn table.setn table.maxn table.pack table.unpack table.move math.cosh math.fmod math.huge math.log10 math.modf math.mod math.sinh math.tanh math.maxinteger math.mininteger math.tointeger math.type math.ult bit32.arshift bit32.band bit32.bnot bit32.bor bit32.btest bit32.bxor bit32.extract bit32.replace bit32.lrotate bit32.lshift bit32.rrotate bit32.rshift utf8.char utf8.charpattern utf8.codes utf8.codepoint utf8.len utf8.offset coroutine.create coroutine.resume coroutine.status coroutine.wrap coroutine.yield io.close io.flush io.input io.lines io.open io.output io.read io.tmpfile io.type io.write io.stdin io.stdout io.stderr os.clock os.date os.difftime os.execute os.exit os.getenv os.remove os.rename os.setlocale os.time os.tmpname coroutine.isyieldable coroutine.running io.popen module package.loaders package.seeall package.config package.searchers package.searchpath require package.cpath package.loaded package.loadlib package.path package.preload");
            this.scintilla2.SetKeywords(1, "warn");
            this.scintilla2.SetKeywords(2, "error");
            this.scintilla2.SetKeywords(3, "getgenv getrenv getreg getgc getinstances getnilinstances getscripts getloadedmodules getconnections firesignal fireclickdetector fireproximityprompt firetouchinterest isnetworkowner gethiddenproperty sethiddenproperty setsimulationradius getsenv getcallingscript getscriptclosure getscripthash getrawmetatable setrawmetatable setreadonly isreadonly iswindowactive keypress keyrelease mouse1click mouse1press mouse1release mouse2click mouse2press mouse2release mousescroll mousemoverel mousemoveabs checkcaller islclosure dumpstring decompile listfiles isfile isfolder makefolder delfolder delfile setclipboard setfflag getnamecallmethod setnamecallmethod getsynasset getspecialinfo saveinstance messagebox syn.crypt.encrypt syn syn.crypt.decrypt syn.crypt.base64.encode syn.crypt.base64.decode syn.crypt.hash syn.crypt.derive syn.crypt.random syn.crypt.custom.encrypt syn.crypt.custom.decrypt syn.crypt.custom.hash debug.getconstants debug.getconstant debug.setconstant debug.getupvalues debug.getupvalue debug.setupvalue debug.getprotos debug.getproto debug.setproto debug.getstack debug.setstack debug.setmetatable debug.getregistry debug.getinfo Drawing syn.cache_replace syn.cache_invalidate syn.set_thread_identity syn.get_thread_identity syn.is_cached syn.write_clipboard syn.queue_on_teleport syn.protect_gui syn.unprotect_gui syn.is_beta syn.request syn.secure_call syn.create_secure_function syn.run_secure_function syn.websocket.connect WebSocket:Send WebSocket:Close ");
            this.scintilla2.SetProperty("fold", "1");
            this.scintilla2.SetProperty("fold.compact", "1");
            this.scintilla2.Margins[1].Type = MarginType.Symbol;
            this.scintilla2.Margins[1].Mask = 4261412864U;
            this.scintilla2.Margins[1].Sensitive = true;
            this.scintilla2.Margins[1].Width = 20;
            for (int i = 25; i <= 31; i++)
            {
                this.scintilla2.Markers[i].SetForeColor(SystemColors.ControlLightLight);
                this.scintilla2.Markers[i].SetBackColor(SystemColors.ControlDark);
            }
            this.scintilla2.Markers[30].Symbol = MarkerSymbol.BoxPlus;
            this.scintilla2.Markers[31].Symbol = MarkerSymbol.BoxMinus;
            this.scintilla2.Markers[25].Symbol = MarkerSymbol.BoxPlusConnected;
            this.scintilla2.Markers[27].Symbol = MarkerSymbol.TCorner;
            this.scintilla2.Markers[26].Symbol = MarkerSymbol.BoxMinusConnected;
            this.scintilla2.Markers[29].Symbol = MarkerSymbol.VLine;
            this.scintilla2.Markers[28].Symbol = MarkerSymbol.LCorner;
            this.scintilla2.AutomaticFold = (AutomaticFold.Show | AutomaticFold.Click | AutomaticFold.Change);
            //scintilla2.SetSelectionForeColor(true,Color.FromArgb(32,32,32));
            scintilla2.SetSelectionBackColor(true, Color.FromArgb(255, 51, 153));

            //this.scintilla2.ReadOnly = true;


            


        }
        
        
        private int maxLineNumberCharLength;
        private iniClass inicls = new iniClass();
        private void Form1_Loadd(object sender, EventArgs e)
        {
            
           
            

            
        }

        private void button1_Click(object sender, EventArgs e)
        {

            //Settings(OBJSHIT.UnlockFPS, true);
        }

        private void iTalk_MenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void NotePad_FormClosing(object sender, FormClosingEventArgs e)
        {
            File.WriteAllText("./Nbin/INPUT", this.scintilla2.Text);
            string Siz = this.Size.ToString();
            string Loc = this.Location.ToString();
            string Siz1 = Siz.Replace("{Width=", "");
            string Siz2 = Siz1.Replace("Height=", "");
            string Siz3 = Siz2.Replace("}", "");
            string Loc1 = Loc.Replace("{X=", "");
            string Loc2 = Loc1.Replace("Y=", "");
            string Loc3 = Loc2.Replace("}", "");
            this.inicls.SetIniValue("Save", "Save", FileLocation, "./Nbin/Settings.ini");
            this.inicls.SetIniValue("Point", "Siz", Siz3, "./Nbin/Settings.ini");
            this.inicls.SetIniValue("Location", "Loc", Loc3, "./Nbin/Settings.ini");
            Environment.Exit(0);

        }

        private void scintilla2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < 32)
            {
                e.Handled = true;
                return;
            }
        }
        bool ischanged;
        private void scintilla2_TextChanged(object sender, EventArgs e)
        {
          
            if (this.FileLocation == "")
            {



            }
            else
            {
                if (Functions.Lib.Ready() == true)
                {
                    if (savedshit.Contains(scintilla2.Text) == true)
                    {
                        ischanged = false;
                        this.Text = FileLocation + " - NotePad [Hooked]";
                    }
                    else
                    {
                        ischanged = true;
                        this.Text = "*" + FileLocation + " - NotePad [Hooked]";

                    }
                }
                else
                {
                    if (savedshit.Contains(scintilla2.Text) == true)
                    {
                        ischanged = false;
                        this.Text = FileLocation + " - NotePad";
                    }
                    else
                    {
                        ischanged = true;
                        this.Text = "*" + FileLocation + " - NotePad";

                    }
                }

            }

            var maxLineNumberCharLength = scintilla2.Lines.Count.ToString().Length;
            if (maxLineNumberCharLength == this.maxLineNumberCharLength)
                return;
            const int padding = 2;
            scintilla2.Margins[0].Width = scintilla2.TextWidth(Style.LineNumber, new string('9', maxLineNumberCharLength + 1)) + padding;
            this.maxLineNumberCharLength = maxLineNumberCharLength;
            
            
        }

        private void shitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("sry");
        }
        private string FileLocation = "";
        private void New_TOOL_Click(object sender, EventArgs e)
        {
            

            bool flag = this.FileLocation == "";
            bool flag2 = flag;
            if (flag2)
            {
                this.scintilla2.Text = "";
                this.FileLocation = "";
                ischanged = false;
            }
            else
            {
                
                if (ischanged == true)
                {
                    DialogResult dialogResult = MessageBox.Show("Do you want to save your changes?", "Confirmation", MessageBoxButtons.YesNoCancel);
                    bool flag3 = dialogResult == DialogResult.Yes;
                    bool flag4 = flag3;
                    if (flag4)
                    {
                        try
                        {
                            File.WriteAllText(this.FileLocation, this.scintilla2.Text);
                        }
                        catch
                        {
                        }
                        this.scintilla2.Text = "";
                        this.FileLocation = "";
                        this.Text = "NotePad";
                    }
                    else
                    {
                        bool flag5 = dialogResult == DialogResult.No;
                        bool flag6 = flag5;
                        if (flag6)
                        {
                            this.scintilla2.Text = "";
                            this.FileLocation = "";
                            this.Text = "NotePad";
                        }
                    }
                }
                else
                {

                    this.scintilla2.Text = "";
                    this.FileLocation = "";
                    this.Text = "NotePad";
                }
            }
        }

        private void scintilla2_Click(object sender, EventArgs e)
        {

        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {

        }

        private void splitter1_SplitterMoved(object sender, SplitterEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void scintilla2_ZoomChanged(object sender, EventArgs e)
        {
            int niggerint = 100;

            
            if (scintilla2.Zoom.ToString() == "0")
            {
                label3.Text = "100%";
            }
            if (scintilla2.Zoom.ToString() == "1")
            {
                label3.Text = "110%";
            }
            if (scintilla2.Zoom.ToString() == "2")
            {
                label3.Text = "120%";
            }
            if (scintilla2.Zoom.ToString() == "3")
            {
                label3.Text = "130%";
            }
            if (scintilla2.Zoom.ToString() == "4")
            {
                label3.Text = "140%";
            }
            if (scintilla2.Zoom.ToString() == "5")
            {
                label3.Text = "150%";
            }
            if (scintilla2.Zoom.ToString() == "6")
            {
                label3.Text = "160%";
            }
            if (scintilla2.Zoom.ToString() == "7")
            {
                label3.Text = "170%";
            }
            if (scintilla2.Zoom.ToString() == "8")
            {
                label3.Text = "180%";
            }
            if (scintilla2.Zoom.ToString() == "9")
            {
                label3.Text = "190%";
            }
            if (scintilla2.Zoom.ToString() == "10")
            {
                label3.Text = "200%";
            }
            if (scintilla2.Zoom.ToString() == "11")
            {
                label3.Text = "210%";
            }
            if (scintilla2.Zoom.ToString() == "12")
            {
                label3.Text = "220%";
            }
            if (scintilla2.Zoom.ToString() == "13")
            {
                label3.Text = "230%";
            }
            if (scintilla2.Zoom.ToString() == "14")
            {
                label3.Text = "240%";
            }
            if (scintilla2.Zoom.ToString() == "15")
            {
                label3.Text = "250%";
            }
            if (scintilla2.Zoom.ToString() == "16")
            {
                label3.Text = "260%";
            }
            if (scintilla2.Zoom.ToString() == "17")
            {
                label3.Text = "270%";
            }
            if (scintilla2.Zoom.ToString() == "18")
            {
                label3.Text = "280%";
            }
            if (scintilla2.Zoom.ToString() == "19")
            {
                label3.Text = "290%";
            }
            if (scintilla2.Zoom.ToString() == "20")
            {
                label3.Text = "300%";
            }

            if (scintilla2.Zoom.ToString() == "-1")
            {
                label3.Text = "90%";
            }
            if (scintilla2.Zoom.ToString() == "-2")
            {
                label3.Text = "80%";
            }
            if (scintilla2.Zoom.ToString() == "-3")
            {
                label3.Text = "70%";
            }
            if (scintilla2.Zoom.ToString() == "-4")
            {
                label3.Text = "60%";
            }
            if (scintilla2.Zoom.ToString() == "-5")
            {
                label3.Text = "50%";
            }
            if (scintilla2.Zoom.ToString() == "-6")
            {
                label3.Text = "40%";
            }
            if (scintilla2.Zoom.ToString() == "-7")
            {
                label3.Text = "30%";
            }
            if (scintilla2.Zoom.ToString() == "-8")
            {
                label3.Text = "20%";
            }
            if (scintilla2.Zoom.ToString() == "-9")
            {
                label3.Text = "10%";
            }



        }

        private void label3_TextChanged(object sender, EventArgs e)
        {

        }

        private void helpToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }
        string savedshit = "";
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            


            bool flag = this.FileLocation == "";
            bool flag2 = flag;
            if (flag2)
            {
                bool flag3 = this.OpenFileDialog1.ShowDialog() != DialogResult.Cancel;
                bool flag4 = flag3;
                if (flag4)
                {
                    try
                    {
                        this.FileLocation = this.OpenFileDialog1.FileName; 
                        savedshit = File.ReadAllText(FileLocation);
                        this.scintilla2.Text = File.ReadAllText(this.OpenFileDialog1.FileName);
                        this.Text = FileLocation + " - NotePad";
                    }
                    catch
                    {
                    }
                }
            }
            else
            {
                if (ischanged == true)
                {
                    DialogResult dialogResult = MessageBox.Show("Do you want to save your changes?", "Confirmation", MessageBoxButtons.YesNoCancel);
                    bool flag5 = dialogResult == DialogResult.Yes;
                    bool flag6 = flag5;
                    if (flag6)
                    {
                        try
                        {
                            File.WriteAllText(this.FileLocation, this.scintilla2.Text);
                        }
                        catch
                        {
                        }
                        bool flag7 = this.OpenFileDialog1.ShowDialog() != DialogResult.Cancel;
                        bool flag8 = flag7;
                        if (flag8)
                        {
                            try
                            {
                                this.FileLocation = this.OpenFileDialog1.FileName; 
                                this.savedshit = File.ReadAllText(this.FileLocation);
                                this.scintilla2.Text = File.ReadAllText(this.OpenFileDialog1.FileName);
                                
                            }
                            catch
                            {
                            }
                        }
                    }
                    else
                    {
                        bool flag9 = dialogResult == DialogResult.No;
                        bool flag10 = flag9;
                        if (flag10)
                        {
                            bool flag11 = this.OpenFileDialog1.ShowDialog() != DialogResult.Cancel;
                            bool flag12 = flag11;
                            if (flag12)
                            {
                                try
                                {
                                    this.FileLocation = this.OpenFileDialog1.FileName; 
                                    this.savedshit = File.ReadAllText(this.FileLocation);
                                    this.scintilla2.Text = File.ReadAllText(this.OpenFileDialog1.FileName);
                                   
                                }
                                catch
                                {
                                }
                            }
                        }
                    }
                }
                else
                {
                    bool flag11 = this.OpenFileDialog1.ShowDialog() != DialogResult.Cancel;
                    bool flag12 = flag11;
                    if (flag12)
                    {
                        try
                        {
                            this.FileLocation = this.OpenFileDialog1.FileName;
                            this.savedshit = File.ReadAllText(this.FileLocation);
                            this.scintilla2.Text = File.ReadAllText(this.OpenFileDialog1.FileName);
                           
                        }
                        catch
                        {
                        }
                    }
                }
                
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
          

            bool flag = this.FileLocation == "";
            bool flag2 = flag;
            if (flag2)
            {
                bool flag3 = this.saveFileDialog1.ShowDialog() != DialogResult.Cancel;
                bool flag4 = flag3;
                if (flag4)
                {
                    try
                    {
                        this.FileLocation = this.saveFileDialog1.FileName;
                        File.Create(this.saveFileDialog1.FileName).Close();
                        File.WriteAllText(this.saveFileDialog1.FileName, this.scintilla2.Text);
                    }
                    catch
                    {
                    }
                }
            }
            else
            {
                if (ischanged == true)
                {
                    try
                    {
                        File.WriteAllText(this.FileLocation, this.scintilla2.Text);
                        this.savedshit = File.ReadAllText(this.FileLocation);
                        this.Text = FileLocation + " - NotePad";
                    }
                    catch
                    {
                    }
                }
                else
                {
                    try
                    {
                        File.WriteAllText(this.FileLocation, this.scintilla2.Text);
                        this.savedshit = File.ReadAllText(this.FileLocation);
                        this.Text = FileLocation + " - NotePad";
                    }
                    catch
                    {
                    }
                }

               
            }
        }

        private async void Exe_Click(object sender, EventArgs e)
        {
            MessageBox.Show(savedshit, FileLocation);
            isAttached.Enabled = false;
            timer1.Enabled = false;
            string script = this.scintilla2.Text;
            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    Functions.Lib.Execute(script);
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;

        }

        private async void button1_Click_1(object sender, EventArgs e)
        {
            
        }

        private void isAttached_Tick(object sender, EventArgs e)
        {
            


            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad [Hooked]";
                    }
                    else
                    {
                        if (ischanged == true)
                        {
                            this.Text ="*"+ FileLocation + " - NotePad [Hooked]";
                        }
                        else
                        {
                            this.Text = FileLocation + " - NotePad [Hooked]";
                        }
                        
                    }

                }

                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        if (ischanged == true)
                        {
                            this.Text = "*" + FileLocation + " - NotePad";
                        }
                        else
                        {
                            this.Text = FileLocation + " - NotePad";
                        }
                    }

                }
            }

        }

        private void dToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
        }

        private void scintilla2_KeyDown(object sender, KeyEventArgs e)
        {
            Keys key = ~(Keys.Shift | Keys.Control);
            if (e.KeyCode == ~(Keys.Control & Keys.N))
            {
                New_TOOL.PerformClick();
            } 
            switch (key)
            {
                case Keys.N:

                    if ((Keys.Control) != 0)
                    {
                        
                    }
                    break;
                case Keys.S:
                    if ((Keys.Control) != 0)
                    {
                        saveToolStripMenuItem.PerformClick();
                    }
                    break;
                case Keys.O:
                    if ((Keys.Control) != 0)
                    {
                        openToolStripMenuItem.PerformClick();

                    }
                    break;


                default:
                    return;

            }
        }

        private void iTalk_Button_21_Click(object sender, EventArgs e)
        {
            this.Text = FileLocation;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
        }
       
        private void timer2_Tick(object sender, EventArgs e)
        {
            if (tastebread == true)
            {
                if (Process.GetProcessesByName("RobloxPlayerBeta").Length == 1) //로블켜져있을때
                {

                }
                else
                {
                    fullbrightToggleToolStripMenuItem.Checked = false;
                    tastebread = false;
                }
            }
            else
            {

            }
            
            
        }
        bool 연결된적있음;

        bool 니거;
        private void isrunning_Tick(object sender, EventArgs e)
        {
            if (Process.GetProcessesByName("RobloxPlayerBeta").Length == 1) //로블켜져있을때
            {
                if (Functions.Lib.Ready() == true)//로블켜져있고 연결됨
                {
                    연결된적있음 = true;
                    if (니거 == false)
                    {
                        string niga = this.inicls.GetIniValue("Settings", "InjectedMes", "./Nbin/Settings.ini");
                        if (niga == "")
                        {
                            string bb = this.inicls.GetIniValue("Settings", "AutoLaunch", "./Nbin/Settings.ini");
                            if (bb == "False")
                            {
                                try
                                {
                                    Functions.Lib.Execute("wait(1)\ngame.StarterGui:SetCore('SendNotification', {\nTitle = 'NotePad';\nText = 'Power by NotePad';\nIcon = '';\nDuration = 8;\n})");
                                }
                                catch (Exception ex)
                                {
                                    Functions.Lib.Execute("Print('error : " + ex + "')");
                                }
                            }
                            
                            니거 = true;
                        }
                        else if (niga == "True")
                        {
                            string bb = this.inicls.GetIniValue("Settings", "AutoLaunch", "./Nbin/Settings.ini");
                            if (bb == "False")
                            {
                                try
                                {
                                    Functions.Lib.Execute("wait(1)\ngame.StarterGui:SetCore('SendNotification', {\nTitle = 'NotePad';\nText = 'Power by NotePad';\nIcon = '';\nDuration = 8;\n})");
                                }
                                catch (Exception ex)
                                {
                                    Functions.Lib.Execute("Print('error : " + ex + "')");
                                }
                            }
                            니거 = true;
                        }
                        else if (niga == "False")
                        {

                        }
                    }
                    
                    
                    //
                }
                else//로블은 켜져있는데 연결은 안됨
                {
                    
                }
            }
            else//로블 꺼져있음
            {
                if (연결된적있음 == true)
                {
                    니거 = false;
                }
            }
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool flag = this.saveFileDialog1.ShowDialog() != DialogResult.Cancel;
            bool flag2 = flag;
            if (flag2)
            {
                try
                {
                    this.FileLocation = this.saveFileDialog1.FileName;
                    File.Create(this.saveFileDialog1.FileName).Close();
                    File.WriteAllText(this.saveFileDialog1.FileName, this.scintilla2.Text);
                }
                catch
                {
                }
            }
        }

        private void scintilla2_CharAdded(object sender, CharAddedEventArgs e)
        {
            

            
        }

        private void scintilla2_InsertCheck(object sender, InsertCheckEventArgs e)
        {
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            scintilla2.SelectAll();
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            scintilla2.Undo();
        }

        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            scintilla2.Redo();
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            scintilla2.Cut();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.scintilla2 != null)
            {
                scintilla2.Text = scintilla2.Text.Replace(scintilla2.SelectedText, "");

            }
        }

        private void NotePad_MouseHover(object sender, EventArgs e)
        {
           
        }

        private void niggerToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void niggerToolStripMenuItem_VisibleChanged(object sender, EventArgs e)
        {
            
        }

        private void niggerToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            DataObject retrievedData = (DataObject)Clipboard.GetDataObject();
            if (retrievedData == null)
            {
                pasteToolStripMenuItem.Enabled = false;
            }
            else
            {
                pasteToolStripMenuItem.Enabled = true;
            }
            bool da = scintilla2.SelectedText == "";

            if (da)
            {
                cutToolStripMenuItem.Enabled = false;
                copyToolStripMenuItem.Enabled = false;
                deleteToolStripMenuItem.Enabled = false;
                searchWithBingToolStripMenuItem.Enabled = false;
            }
            else
            {
                cutToolStripMenuItem.Enabled = true;
                copyToolStripMenuItem.Enabled = true;
                deleteToolStripMenuItem.Enabled = true;
                searchWithBingToolStripMenuItem.Enabled = true;
            }

            
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(scintilla2.SelectedText);
        }

        private void searchWithBingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string niggershit = scintilla2.SelectedText.Replace(" ","+");
            string linkl1 = "https://www.bing.com/search?q=" + niggershit;

            Process.Start(linkl1);
        }

        public static string niggershit = "";
        private void serchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            niggershit = "serach";
            ScintillaFindReplaceControl.FindReplace da = new ScintillaFindReplaceControl.FindReplace();
            da.Show(this);
        }

        private void replaceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            niggershit = "replace";
            ScintillaFindReplaceControl.FindReplace da = new ScintillaFindReplaceControl.FindReplace();
            da.Show(this);
            
        }

        private void sendFeedbackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FeedBack fuckthatshitniggershitsuckmydickandsomebitcheslikemelolthisisfeelgoodlol = new FeedBack();
            fuckthatshitniggershitsuckmydickandsomebitcheslikemelolthisisfeelgoodlol.ShowDialog();
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("what u gon do");
        }

        private async void injectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;
            if (Loaded == true)
            {
                
                    Functions.Lib.Attach();
                    Functions.Lib.AttachEvent += SynAttachEvent;
               
                   
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
        }

        private async void executeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;
            string script = this.scintilla2.Text;
            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    Functions.Lib.Execute(script);
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
        }
        
        public void SetTarget(Scintilla scintilla)
        {
            scintilla2 = scintilla;
        }


        public void SetFind(Scintilla scintilla)
        {
            ScintillaFindReplaceControl.FindReplace frm = (ScintillaFindReplaceControl.FindReplace)this.Owner;
            frm.tabControlFindReplace.SelectTab(0);
            scintilla2 = scintilla;
        }


        public void SetReplace(Scintilla scintilla)
        {
            ScintillaFindReplaceControl.FindReplace frm = (ScintillaFindReplaceControl.FindReplace)this.Owner;

            frm.tabControlFindReplace.SelectTab(1);
            scintilla2 = scintilla;
        }




        public void buttonFindPrev_Click()
        {
            ScintillaFindReplaceControl.FindReplace frm = (ScintillaFindReplaceControl.FindReplace)this.Owner;

            frm.SetFindSearchFlags();
            var text = frm.textBoxFind.Text;
            FindPrevious(text, frm._findSearchFlags);
        }

        public void buttonFindNext(string niga)
        {
            ScintillaFindReplaceControl.FindReplace frm = (ScintillaFindReplaceControl.FindReplace)this.Owner;
            frm.SetFindSearchFlags();
            var text = frm.textBoxFind.Text;
            FindNext(text,frm._findSearchFlags);
        }

      

        public void buttonReplaceNext_Click()
        {
            ScintillaFindReplaceControl.FindReplace frm = (ScintillaFindReplaceControl.FindReplace)this.Owner;
            frm.SetReplaceSearchFlags();

            frm.ReplaceNext(frm.textBoxFindRep.Text, frm.textBoxReplace.Text);
        }

        public void nigger_button_replace_next(string replaceText)
        {
            scintilla2.ReplaceSelection(replaceText);
        }

        public void buttonReplaceAll_Click()
        {
           

            scintilla2.CurrentPosition = 0;
            scintilla2.AnchorPosition = 0;
        }
        public void buttonReplaceAl32l_Click()
        {
            var currentPos = scintilla2.CurrentPosition;
            var currentAnchorPos = scintilla2.AnchorPosition;
            scintilla2.CurrentPosition = currentPos;
            scintilla2.AnchorPosition = currentAnchorPos;
        }


        public int FindNext(string text, SearchFlags searchFlags)
        {
            scintilla2.SearchFlags = searchFlags;
            scintilla2.TargetStart = Math.Max(scintilla2.CurrentPosition, scintilla2.AnchorPosition);
            scintilla2.TargetEnd = scintilla2.TextLength;

            var pos = scintilla2.SearchInTarget(text);
            if (pos >= 0)
                scintilla2.SetSel(scintilla2.TargetStart, scintilla2.TargetEnd);

            return pos;
        }

   
        public int FindPrevious(string text, SearchFlags searchFlags)
        {
            scintilla2.SearchFlags = searchFlags;
            scintilla2.TargetStart = Math.Min(scintilla2.CurrentPosition, scintilla2.AnchorPosition);
            scintilla2.TargetEnd = 0;

            var pos = scintilla2.SearchInTarget(text);
            if (pos >= 0)
                scintilla2.SetSel(scintilla2.TargetStart, scintilla2.TargetEnd);
            
            return pos;
        }

        private void wordWrapToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void wordWrapToolStripMenuItem_CheckedChanged(object sender, EventArgs e)
        {
            if (wordWrapToolStripMenuItem.Checked == true)
            {
                scintilla2.WrapMode = WrapMode.Word;
            }
            else
            {
                scintilla2.WrapMode = WrapMode.None;
            }
        }
        string FontShit;
        private void nigToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fontDlg = new FontDialog();
            fontDlg.ShowColor = true;
            fontDlg.ShowApply = true;
            fontDlg.ShowEffects = true;
            fontDlg.ShowHelp = true;
            if (fontDlg.ShowDialog() != DialogResult.Cancel)
            {
                
                FontShit = fontDlg.Font.Name.ToString();


                this.scintilla2.ForeColor = Color.Black;
                this.scintilla2.BackColor = Color.FromArgb(101, 148, 239);
                string str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
                string str2 = "0123456789";
                string str3 = "ŠšŒœŸÿÀàÁáÂâÃãÄäÅåÆæÇçÈèÉéÊêËëÌìÍíÎîÏïÐðÑñÒòÓóÔôÕõÖØøÙùÚúÛûÜüÝýÞþßö";
                this.scintilla2.StyleResetDefault();

                this.scintilla2.Styles[32].Font = FontShit;

                this.scintilla2.Styles[32].Size = 11;
                this.scintilla2.StyleClearAll();
                this.scintilla2.Styles[0].ForeColor = Color.Silver;
                this.scintilla2.Styles[1].ForeColor = Color.FromArgb(0, 0, 127, 0);
                this.scintilla2.Styles[2].ForeColor = Color.FromArgb(0, 0, 127, 0);
                this.scintilla2.Styles[4].ForeColor = Color.FromArgb(0, 0, 127, 127);
                this.scintilla2.Styles[5].ForeColor = Color.FromArgb(0, 0, 0, 127);
                this.scintilla2.Styles[13].ForeColor = Color.FromArgb(0, 255, 128, 0);
                this.scintilla2.Styles[14].ForeColor = Color.FromArgb(0, 255, 0, 0);
                this.scintilla2.Styles[15].ForeColor = Color.DarkSlateBlue;
                this.scintilla2.Styles[6].ForeColor = Color.FromArgb(0, 127, 0, 127);
                this.scintilla2.Styles[7].ForeColor = Color.FromArgb(0, 127, 0, 127);
                this.scintilla2.Styles[8].ForeColor = Color.FromArgb(0, 127, 0, 127);
                this.scintilla2.Styles[10].ForeColor = Color.FromArgb(0, 127, 127, 127);
                this.scintilla2.Styles[9].ForeColor = Color.Maroon;
                this.scintilla2.Lexer = Lexer.Lua;
                this.scintilla2.WordChars = str + str2 + str3;
                this.scintilla2.SetKeywords(0, "info and break do else elseif end for function if in local nil not or repeat return then until while false true goto assert collectgarbage dofile _G getmetatable ipairs loadfile next pairs pcall print rawequal rawget rawset metatable setmetatable tonumber tostring type _VERSION xpcall string table math coroutine io os debug getfenv gcinfo load loadlib loadstring require select setfenv unpack _LOADED LUA_PATH _REQUIREDNAME package rawlen package bit32 utf8 _ENV string.byte string.char string.dump string.find string.format string.gsub string.len string.lower string.rep string.sub string.upper table.concat table.insert table.remove table.sort math.abs math.acos math.asin math.atan math.atan2 math.ceil math.cos math.deg math.exp math.floor math.frexp math.ldexp math.log math.max math.min math.pi math.pow math.rad math.random math.randomseed math.sin math.sqrt math.tan string.gfind string.gmatch string.match string.reverse string.pack string.packsize string.unpack table.foreach table.foreachi table.getn table.setn table.maxn table.pack table.unpack table.move math.cosh math.fmod math.huge math.log10 math.modf math.mod math.sinh math.tanh math.maxinteger math.mininteger math.tointeger math.type math.ult bit32.arshift bit32.band bit32.bnot bit32.bor bit32.btest bit32.bxor bit32.extract bit32.replace bit32.lrotate bit32.lshift bit32.rrotate bit32.rshift utf8.char utf8.charpattern utf8.codes utf8.codepoint utf8.len utf8.offset coroutine.create coroutine.resume coroutine.status coroutine.wrap coroutine.yield io.close io.flush io.input io.lines io.open io.output io.read io.tmpfile io.type io.write io.stdin io.stdout io.stderr os.clock os.date os.difftime os.execute os.exit os.getenv os.remove os.rename os.setlocale os.time os.tmpname coroutine.isyieldable coroutine.running io.popen module package.loaders package.seeall package.config package.searchers package.searchpath require package.cpath package.loaded package.loadlib package.path package.preload");
                this.scintilla2.SetKeywords(1, "warn");
                this.scintilla2.SetKeywords(2, "error");
                this.scintilla2.SetKeywords(3, "getgenv getrenv getreg getgc getinstances getnilinstances getscripts getloadedmodules getconnections firesignal fireclickdetector fireproximityprompt firetouchinterest isnetworkowner gethiddenproperty sethiddenproperty setsimulationradius getsenv getcallingscript getscriptclosure getscripthash getrawmetatable setrawmetatable setreadonly isreadonly iswindowactive keypress keyrelease mouse1click mouse1press mouse1release mouse2click mouse2press mouse2release mousescroll mousemoverel mousemoveabs checkcaller islclosure dumpstring decompile listfiles isfile isfolder makefolder delfolder delfile setclipboard setfflag getnamecallmethod setnamecallmethod getsynasset getspecialinfo saveinstance messagebox syn.crypt.encrypt syn syn.crypt.decrypt syn.crypt.base64.encode syn.crypt.base64.decode syn.crypt.hash syn.crypt.derive syn.crypt.random syn.crypt.custom.encrypt syn.crypt.custom.decrypt syn.crypt.custom.hash debug.getconstants debug.getconstant debug.setconstant debug.getupvalues debug.getupvalue debug.setupvalue debug.getprotos debug.getproto debug.setproto debug.getstack debug.setstack debug.setmetatable debug.getregistry debug.getinfo Drawing syn.cache_replace syn.cache_invalidate syn.set_thread_identity syn.get_thread_identity syn.is_cached syn.write_clipboard syn.queue_on_teleport syn.protect_gui syn.unprotect_gui syn.is_beta syn.request syn.secure_call syn.create_secure_function syn.run_secure_function syn.websocket.connect WebSocket:Send WebSocket:Close ");
                this.scintilla2.SetProperty("fold", "1");
                this.scintilla2.SetProperty("fold.compact", "1");
                this.scintilla2.Margins[1].Type = MarginType.Symbol;
                this.scintilla2.Margins[1].Mask = 4261412864U;
                this.scintilla2.Margins[1].Sensitive = true;
                this.scintilla2.Margins[1].Width = 20;
                for (int i = 25; i <= 31; i++)
                {
                    this.scintilla2.Markers[i].SetForeColor(SystemColors.ControlLightLight);
                    this.scintilla2.Markers[i].SetBackColor(SystemColors.ControlDark);
                }
                this.scintilla2.Markers[30].Symbol = MarkerSymbol.BoxPlus;
                this.scintilla2.Markers[31].Symbol = MarkerSymbol.BoxMinus;
                this.scintilla2.Markers[25].Symbol = MarkerSymbol.BoxPlusConnected;
                this.scintilla2.Markers[27].Symbol = MarkerSymbol.TCorner;
                this.scintilla2.Markers[26].Symbol = MarkerSymbol.BoxMinusConnected;
                this.scintilla2.Markers[29].Symbol = MarkerSymbol.VLine;
                this.scintilla2.Markers[28].Symbol = MarkerSymbol.LCorner;
                this.scintilla2.AutomaticFold = (AutomaticFold.Show | AutomaticFold.Click | AutomaticFold.Change);
                //scintilla2.SetSelectionForeColor(true,Color.FromArgb(32,32,32));
                scintilla2.SetSelectionBackColor(true, Color.FromArgb(0, 127, 127));

              

               
                this.inicls.SetIniValue("Font", "font", FontShit, "./Nbin/Settings.ini");
            }
        }

        private void iTalk_Button_11_Click(object sender, EventArgs e)
        {
           
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
        }

        private void scintilla2_SizeChanged(object sender, EventArgs e)
        {
            listBox1.Height = scintilla2.Size.Height;
        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            Functions.PopulateListBox(listBox1, "./Scripts", "*.txt");
            Functions.PopulateListBox(listBox1, "./Scripts", "*.lua");
        }
        public void TOpMost(bool val)
        {
            base.TopMost = val;
        }
        private async void executeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;
            string script = File.ReadAllText($"./Scripts/{listBox1.SelectedItem}");
            bool niga = listBox1.SelectedIndex == -1;
            if (!niga)
            {
                if (Loaded == true)
                {
                    if (Functions.Lib.Ready() == true)
                    {
                        Functions.Lib.Execute(script);
                    }
                    else
                    {
                        if (FileLocation == "")
                        {
                            this.Text = "NotePad (NotePad is Not Attached!)";
                        }
                        else
                        {
                            this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                        }
                        await Task.Delay(1500);
                        if (FileLocation == "")
                        {
                            this.Text = "NotePad";
                        }
                        else
                        {
                            this.Text = FileLocation + " - NotePad";
                        }
                    }
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Loaded!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }

                }
                isAttached.Enabled = true;
                timer1.Enabled = true;
            }
            
        }
        bool mousein = false;
        private void listBox1_MouseHover(object sender, EventArgs e)
        {
            mousein = true;
        }

        private void listBox1_MouseLeave(object sender, EventArgs e)
        {
            mousein = false;
        }
        [DllImport("user32.dll")]
        static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, int dwExtraInfo);

        private const uint MOUSEEVENTF_RDOWN = 0x0002;      // The left button is down.
        private const uint MOUSEEVENTF_RUP = 0x0004;
        private void listBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                
                 mouse_event(MOUSEEVENTF_RDOWN, 0, 0, 0, 0);
                 mouse_event(MOUSEEVENTF_RUP, 0, 0, 0, 0);
               

            }
        }

        private void scriptListBoxToolStripMenuItem_CheckedChanged(object sender, EventArgs e)
        {
            if (scriptListBoxToolStripMenuItem.Checked == true)
            {
                scintilla2.Width -= 224;
                listBox1.Show();
            }
            else
            {
                scintilla2.Width += 224;
                listBox1.Hide();
            }
        }

        private void loadToEditorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool niga = listBox1.SelectedIndex == -1;
            if (!niga)
            {
                scintilla2.Text = File.ReadAllText($"./Scripts/{listBox1.SelectedItem}");
            }
        }

        private void setDefaultFontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.scintilla2.ForeColor = Color.Black;
            this.scintilla2.BackColor = Color.FromArgb(101, 148, 239);
            string str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string str2 = "0123456789";
            string str3 = "ŠšŒœŸÿÀàÁáÂâÃãÄäÅåÆæÇçÈèÉéÊêËëÌìÍíÎîÏïÐðÑñÒòÓóÔôÕõÖØøÙùÚúÛûÜüÝýÞþßö";
            this.scintilla2.StyleResetDefault();
            //this.scintilla2.Styles[32].Font = "Consolas";
                this.scintilla2.Styles[32].Font = "Consolas";
            this.scintilla2.Styles[32].Size = 11;
            this.scintilla2.StyleClearAll();
            this.scintilla2.Styles[0].ForeColor = Color.Silver;
            this.scintilla2.Styles[1].ForeColor = Color.FromArgb(0, 0, 127, 0);
            this.scintilla2.Styles[2].ForeColor = Color.FromArgb(0, 0, 127, 0);
            this.scintilla2.Styles[4].ForeColor = Color.FromArgb(0, 0, 127, 127);
            this.scintilla2.Styles[5].ForeColor = Color.FromArgb(0, 0, 0, 127);
            this.scintilla2.Styles[13].ForeColor = Color.FromArgb(0, 255, 128, 0);
            this.scintilla2.Styles[14].ForeColor = Color.FromArgb(0, 255, 0, 0);
            this.scintilla2.Styles[15].ForeColor = Color.DarkSlateBlue;
            this.scintilla2.Styles[6].ForeColor = Color.FromArgb(0, 127, 0, 127);
            this.scintilla2.Styles[7].ForeColor = Color.FromArgb(0, 127, 0, 127);
            this.scintilla2.Styles[8].ForeColor = Color.FromArgb(0, 127, 0, 127);
            this.scintilla2.Styles[10].ForeColor = Color.FromArgb(0, 127, 127, 127);
            this.scintilla2.Styles[9].ForeColor = Color.Maroon;
            this.scintilla2.Lexer = Lexer.Lua;
            this.scintilla2.WordChars = str + str2 + str3;
            this.scintilla2.SetKeywords(0, "info and break do else elseif end for function if in local nil not or repeat return then until while false true goto assert collectgarbage dofile _G getmetatable ipairs loadfile next pairs pcall print rawequal rawget rawset metatable setmetatable tonumber tostring type _VERSION xpcall string table math coroutine io os debug getfenv gcinfo load loadlib loadstring require select setfenv unpack _LOADED LUA_PATH _REQUIREDNAME package rawlen package bit32 utf8 _ENV string.byte string.char string.dump string.find string.format string.gsub string.len string.lower string.rep string.sub string.upper table.concat table.insert table.remove table.sort math.abs math.acos math.asin math.atan math.atan2 math.ceil math.cos math.deg math.exp math.floor math.frexp math.ldexp math.log math.max math.min math.pi math.pow math.rad math.random math.randomseed math.sin math.sqrt math.tan string.gfind string.gmatch string.match string.reverse string.pack string.packsize string.unpack table.foreach table.foreachi table.getn table.setn table.maxn table.pack table.unpack table.move math.cosh math.fmod math.huge math.log10 math.modf math.mod math.sinh math.tanh math.maxinteger math.mininteger math.tointeger math.type math.ult bit32.arshift bit32.band bit32.bnot bit32.bor bit32.btest bit32.bxor bit32.extract bit32.replace bit32.lrotate bit32.lshift bit32.rrotate bit32.rshift utf8.char utf8.charpattern utf8.codes utf8.codepoint utf8.len utf8.offset coroutine.create coroutine.resume coroutine.status coroutine.wrap coroutine.yield io.close io.flush io.input io.lines io.open io.output io.read io.tmpfile io.type io.write io.stdin io.stdout io.stderr os.clock os.date os.difftime os.execute os.exit os.getenv os.remove os.rename os.setlocale os.time os.tmpname coroutine.isyieldable coroutine.running io.popen module package.loaders package.seeall package.config package.searchers package.searchpath require package.cpath package.loaded package.loadlib package.path package.preload");
            this.scintilla2.SetKeywords(1, "warn");
            this.scintilla2.SetKeywords(2, "error");
            this.scintilla2.SetKeywords(3, "getgenv getrenv getreg getgc getinstances getnilinstances getscripts getloadedmodules getconnections firesignal fireclickdetector fireproximityprompt firetouchinterest isnetworkowner gethiddenproperty sethiddenproperty setsimulationradius getsenv getcallingscript getscriptclosure getscripthash getrawmetatable setrawmetatable setreadonly isreadonly iswindowactive keypress keyrelease mouse1click mouse1press mouse1release mouse2click mouse2press mouse2release mousescroll mousemoverel mousemoveabs checkcaller islclosure dumpstring decompile listfiles isfile isfolder makefolder delfolder delfile setclipboard setfflag getnamecallmethod setnamecallmethod getsynasset getspecialinfo saveinstance messagebox syn.crypt.encrypt syn syn.crypt.decrypt syn.crypt.base64.encode syn.crypt.base64.decode syn.crypt.hash syn.crypt.derive syn.crypt.random syn.crypt.custom.encrypt syn.crypt.custom.decrypt syn.crypt.custom.hash debug.getconstants debug.getconstant debug.setconstant debug.getupvalues debug.getupvalue debug.setupvalue debug.getprotos debug.getproto debug.setproto debug.getstack debug.setstack debug.setmetatable debug.getregistry debug.getinfo Drawing syn.cache_replace syn.cache_invalidate syn.set_thread_identity syn.get_thread_identity syn.is_cached syn.write_clipboard syn.queue_on_teleport syn.protect_gui syn.unprotect_gui syn.is_beta syn.request syn.secure_call syn.create_secure_function syn.run_secure_function syn.websocket.connect WebSocket:Send WebSocket:Close ");
            this.scintilla2.SetProperty("fold", "1");
            this.scintilla2.SetProperty("fold.compact", "1");
            this.scintilla2.Margins[1].Type = MarginType.Symbol;
            this.scintilla2.Margins[1].Mask = 4261412864U;
            this.scintilla2.Margins[1].Sensitive = true;
            this.scintilla2.Margins[1].Width = 20;
            for (int i = 25; i <= 31; i++)
            {
                this.scintilla2.Markers[i].SetForeColor(SystemColors.ControlLightLight);
                this.scintilla2.Markers[i].SetBackColor(SystemColors.ControlDark);
            }
            this.scintilla2.Markers[30].Symbol = MarkerSymbol.BoxPlus;
            this.scintilla2.Markers[31].Symbol = MarkerSymbol.BoxMinus;
            this.scintilla2.Markers[25].Symbol = MarkerSymbol.BoxPlusConnected;
            this.scintilla2.Markers[27].Symbol = MarkerSymbol.TCorner;
            this.scintilla2.Markers[26].Symbol = MarkerSymbol.BoxMinusConnected;
            this.scintilla2.Markers[29].Symbol = MarkerSymbol.VLine;
            this.scintilla2.Markers[28].Symbol = MarkerSymbol.LCorner;
            this.scintilla2.AutomaticFold = (AutomaticFold.Show | AutomaticFold.Click | AutomaticFold.Change);
            //scintilla2.SetSelectionForeColor(true,Color.FromArgb(32,32,32));
            scintilla2.SetSelectionBackColor(true, Color.FromArgb(0, 127, 127));

            this.inicls.SetIniValue("Font", "font", "Consolas", "./Nbin/Settings.ini");

        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void listBox1_MouseUp(object sender, MouseEventArgs e)
        {
            bool niga = listBox1.SelectedIndex == -1;
            if (niga)
            {
                executeToolStripMenuItem1.Visible = false;
                loadToEditorToolStripMenuItem.Visible = false;
            }
            else
            {
                executeToolStripMenuItem1.Visible = true;
                loadToEditorToolStripMenuItem.Visible = true;
            }
        }


        public void ugly_highlight_text(bool niga)
        {
            niggertextbox.Text = niga.ToString();
        }
        private async void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;
            if (Loaded == true)
            {
                Shitings ВлинДибилЗамолчиПошёлтыКакогоЧёртаyoimnotrussian = new Shitings(this);
                ВлинДибилЗамолчиПошёлтыКакогоЧёртаyoimnotrussian.Show();
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;

        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            scintilla2.Paste();
        }

        private async void darkDexToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;

            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    NotePad.data = "Dark Dex";
                    Functions.Lib.ScriptHub();
                    Functions.Lib.ScriptHubMarkAsClosed();
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
        }
        
        internal static string data;
        private async void remoteSpyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;
            
            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    NotePad.data = "Remote Spy";
                    Functions.Lib.ScriptHub();
                    Functions.Lib.ScriptHubMarkAsClosed();
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
            
        }

        private async void unnamedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;

            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    NotePad.data = "Unnamed ESP";
                    Functions.Lib.ScriptHub();
                    Functions.Lib.ScriptHubMarkAsClosed();
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
        }

        private async void darkGUIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;

            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    Functions.Lib.Execute("loadstring(game:HttpGet('https://raw.githubusercontent.com/RandomAdamYT/DarkHub/master/Init', true))()");
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
        }

        private async void ctrlClickTPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;

            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    Functions.Lib.Execute("loadstring(game:HttpGet('https://pastebin.com/raw/zv5ca4M7', true))()");
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
        }

        private async void antiAFKToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            isAttached.Enabled = false;
            timer1.Enabled = false;

            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    Functions.Lib.Execute("loadstring(game:HttpGet('https://pastebin.com/raw/UHpr9CG5', true))()");
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
        }

        private async void gameSenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            isAttached.Enabled = false;
            timer1.Enabled = false;

            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    Functions.Lib.Execute("loadstring(game:HttpGet(('https://pastebin.com/raw/cdPJxGDU'),true))()");
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
        }

        private void killRobloxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (Process process in Process.GetProcessesByName("RobloxPlayerBeta"))
                {
                    process.Kill();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error : \n" + ex);
            }
        }

        private void updateLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("the hilight text color is changed pretty color :)\n\nand fixed TopMost bugshit");
        }

        private void niggertextbox_TextChanged(object sender, EventArgs e)
        {
            if (niggertextbox.Text == "True")
            {
                this.TopMost = true;
            }
            else if (niggertextbox.Text == "False")
            {
                this.TopMost = false;
            }
            else
            {
                MessageBox.Show("BItch", niggertextbox.Text);
            }
        }

        private void okItsBugShitToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private async void infiniteYieldFEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;

            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    Functions.Lib.Execute("loadstring(game:HttpGet(('https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source'),true))()");
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
        }

        private void multiRolobxToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void multiRolobxToolStripMenuItem_CheckedChanged(object sender, EventArgs e)
        {
            if (multiRolobxToolStripMenuItem.Checked == true)
            {
                //new Mutex(true, "ROBLOX_singletonMutex");
                CreateMutex(IntPtr.Zero, true, "ROBLOX_singletonMutex");
            }
            else
            {
                new Mutex(false, "ROBLOX_singletonMutex");
                
            }
        }

        private void robloxAppBetaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("roblox-player://roblox-player:+launchmode:app+robloxLocale:en_us+gameLocale:en_us+LaunchExp:InApp");
        }
        bool tastebread;
        private async void fullbrightToggleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;

            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    
                    if (this.fullbrightToggleToolStripMenuItem.Checked == true)
                    {
                        Functions.Lib.Execute("if not _G.FullBrightExecuted then\n_G.FullBrightEnabled = false\n_G.NormalLightingSettings = {\nBrightness = game:GetService('Lighting').Brightness,\nClockTime = game:GetService('Lighting').ClockTime,\nFogEnd = game:GetService('Lighting').FogEnd,\nGlobalShadows = game:GetService('Lighting').GlobalShadows,\nAmbient = game:GetService('Lighting').Ambient\n}\ngame:GetService('Lighting'):GetPropertyChangedSignal('Brightness'):Connect(function()\nif game:GetService('Lighting').Brightness ~= 1 and game:GetService('Lighting').Brightness ~= _G.NormalLightingSettings.Brightness then\n_G.NormalLightingSettings.Brightness = game:GetService('Lighting').Brightness\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').Brightness = 1\nend\nend)\ngame:GetService('Lighting'):GetPropertyChangedSignal('ClockTime'):Connect(function()\nif game:GetService('Lighting').ClockTime ~= 12 and game:GetService('Lighting').ClockTime ~= _G.NormalLightingSettings.ClockTime then\n_G.NormalLightingSettings.ClockTime = game:GetService('Lighting').ClockTime\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').ClockTime = 12\nend\nend)\ngame:GetService('Lighting'):GetPropertyChangedSignal('FogEnd'):Connect(function()\nif game:GetService('Lighting').FogEnd ~= 786543 and game:GetService('Lighting').FogEnd ~= _G.NormalLightingSettings.FogEnd then\n_G.NormalLightingSettings.FogEnd = game:GetService('Lighting').FogEnd\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').FogEnd = 786543\nend\nend)\ngame:GetService('Lighting'):GetPropertyChangedSignal('GlobalShadows'):Connect(function()\nif game:GetService('Lighting').GlobalShadows ~= false and game:GetService('Lighting').GlobalShadows ~= _G.NormalLightingSettings.GlobalShadows then\n_G.NormalLightingSettings.GlobalShadows = game:GetService('Lighting').GlobalShadows\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').GlobalShadows = false\nend\nend)\ngame:GetService('Lighting'):GetPropertyChangedSignal('Ambient'):Connect(function()\nif game:GetService('Lighting').Ambient ~= Color3.fromRGB(178, 178, 178) and game:GetService('Lighting').Ambient ~= _G.NormalLightingSettings.Ambient then\n_G.NormalLightingSettings.Ambient = game:GetService('Lighting').Ambient\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').Ambient = Color3.fromRGB(178, 178, 178)\nend\nend)\ngame:GetService('Lighting').Brightness = 1\ngame:GetService('Lighting').ClockTime = 12\ngame:GetService('Lighting').FogEnd = 786543\ngame:GetService('Lighting').GlobalShadows = false\ngame:GetService('Lighting').Ambient = Color3.fromRGB(178, 178, 178)\nlocal LatestValue = true\nspawn(function()\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nwhile wait() do\nif _G.FullBrightEnabled ~= LatestValue then\nif not _G.FullBrightEnabled then\ngame:GetService('Lighting').Brightness = _G.NormalLightingSettings.Brightness\ngame:GetService('Lighting').ClockTime = _G.NormalLightingSettings.ClockTime\ngame:GetService('Lighting').FogEnd = _G.NormalLightingSettings.FogEnd\ngame:GetService('Lighting').GlobalShadows = _G.NormalLightingSettings.GlobalShadows\ngame:GetService('Lighting').Ambient = _G.NormalLightingSettings.Ambient\nelse\ngame:GetService('Lighting').Brightness = 1\ngame:GetService('Lighting').ClockTime = 12\ngame:GetService('Lighting').FogEnd = 786543\ngame:GetService('Lighting').GlobalShadows = false\ngame:GetService('Lighting').Ambient = Color3.fromRGB(178, 178, 178)\nend\nLatestValue = not LatestValue\nend\nend\nend)\nend\n_G.FullBrightExecuted = true\n_G.FullBrightEnabled = not _G.FullBrightEnabled");
                        tastebread = true;
                        this.fullbrightToggleToolStripMenuItem.Checked = false;
                    }
                    else
                    {
                        Functions.Lib.Execute("if not _G.FullBrightExecuted then\n_G.FullBrightEnabled = false\n_G.NormalLightingSettings = {\nBrightness = game:GetService('Lighting').Brightness,\nClockTime = game:GetService('Lighting').ClockTime,\nFogEnd = game:GetService('Lighting').FogEnd,\nGlobalShadows = game:GetService('Lighting').GlobalShadows,\nAmbient = game:GetService('Lighting').Ambient\n}\ngame:GetService('Lighting'):GetPropertyChangedSignal('Brightness'):Connect(function()\nif game:GetService('Lighting').Brightness ~= 1 and game:GetService('Lighting').Brightness ~= _G.NormalLightingSettings.Brightness then\n_G.NormalLightingSettings.Brightness = game:GetService('Lighting').Brightness\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').Brightness = 1\nend\nend)\ngame:GetService('Lighting'):GetPropertyChangedSignal('ClockTime'):Connect(function()\nif game:GetService('Lighting').ClockTime ~= 12 and game:GetService('Lighting').ClockTime ~= _G.NormalLightingSettings.ClockTime then\n_G.NormalLightingSettings.ClockTime = game:GetService('Lighting').ClockTime\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').ClockTime = 12\nend\nend)\ngame:GetService('Lighting'):GetPropertyChangedSignal('FogEnd'):Connect(function()\nif game:GetService('Lighting').FogEnd ~= 786543 and game:GetService('Lighting').FogEnd ~= _G.NormalLightingSettings.FogEnd then\n_G.NormalLightingSettings.FogEnd = game:GetService('Lighting').FogEnd\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').FogEnd = 786543\nend\nend)\ngame:GetService('Lighting'):GetPropertyChangedSignal('GlobalShadows'):Connect(function()\nif game:GetService('Lighting').GlobalShadows ~= false and game:GetService('Lighting').GlobalShadows ~= _G.NormalLightingSettings.GlobalShadows then\n_G.NormalLightingSettings.GlobalShadows = game:GetService('Lighting').GlobalShadows\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').GlobalShadows = false\nend\nend)\ngame:GetService('Lighting'):GetPropertyChangedSignal('Ambient'):Connect(function()\nif game:GetService('Lighting').Ambient ~= Color3.fromRGB(178, 178, 178) and game:GetService('Lighting').Ambient ~= _G.NormalLightingSettings.Ambient then\n_G.NormalLightingSettings.Ambient = game:GetService('Lighting').Ambient\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').Ambient = Color3.fromRGB(178, 178, 178)\nend\nend)\ngame:GetService('Lighting').Brightness = 1\ngame:GetService('Lighting').ClockTime = 12\ngame:GetService('Lighting').FogEnd = 786543\ngame:GetService('Lighting').GlobalShadows = false\ngame:GetService('Lighting').Ambient = Color3.fromRGB(178, 178, 178)\nlocal LatestValue = true\nspawn(function()\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nwhile wait() do\nif _G.FullBrightEnabled ~= LatestValue then\nif not _G.FullBrightEnabled then\ngame:GetService('Lighting').Brightness = _G.NormalLightingSettings.Brightness\ngame:GetService('Lighting').ClockTime = _G.NormalLightingSettings.ClockTime\ngame:GetService('Lighting').FogEnd = _G.NormalLightingSettings.FogEnd\ngame:GetService('Lighting').GlobalShadows = _G.NormalLightingSettings.GlobalShadows\ngame:GetService('Lighting').Ambient = _G.NormalLightingSettings.Ambient\nelse\ngame:GetService('Lighting').Brightness = 1\ngame:GetService('Lighting').ClockTime = 12\ngame:GetService('Lighting').FogEnd = 786543\ngame:GetService('Lighting').GlobalShadows = false\ngame:GetService('Lighting').Ambient = Color3.fromRGB(178, 178, 178)\nend\nLatestValue = not LatestValue\nend\nend\nend)\nend\n_G.FullBrightExecuted = true\n_G.FullBrightEnabled = not _G.FullBrightEnabled");
                        tastebread = true;
                        this.fullbrightToggleToolStripMenuItem.Checked = true;
                    }
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
            
        }

        private async void executeLineToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }
       
        private async void cToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;
            
            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    if (!File.Exists("./Nbin/line.nigger"))
                    {
                        File.Create("./Nbin/line.nigger").Close();
                    }
                    File.WriteAllText("./Nbin/line.nigger", scintilla2.Text);
                    string path = "./Nbin/line.nigger";
                    using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        int lineNum = 1;
                        StreamReader reader = new StreamReader(fs);
                        while (!reader.EndOfStream)
                        {
                            if (lineNum == scintilla2.CurrentLine + 1)
                            {
                                Functions.Lib.Execute(reader.ReadLine());
                            }
                            else
                            {
                                reader.ReadLine();
                            }
                            lineNum++;
                        }
                        reader.Close();
                    }
                   
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;


           
        }

        private void dToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(scintilla2.CurrentLine.ToString());
        }
    }

}
