﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace NiggerDick
{
	public class iniClass
	{
		// Token: 0x06000001 RID: 1
		[DllImport("kernel32")]
		private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

		// Token: 0x06000002 RID: 2
		[DllImport("kernel32")]
		private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);

		// Token: 0x06000003 RID: 3 RVA: 0x00002050 File Offset: 0x00000250
		public string GetIniValue(string Section, string Key, string iniPath)
		{
			StringBuilder temp = new StringBuilder(255);
			int i = iniClass.GetPrivateProfileString(Section, Key, "", temp, 255, iniPath);
			return temp.ToString();
		}

		// Token: 0x06000004 RID: 4 RVA: 0x00002087 File Offset: 0x00000287
		public void SetIniValue(string Section, string Key, string Value, string iniPath)
		{
			iniClass.WritePrivateProfileString(Section, Key, Value, iniPath);
		}
	}
}
