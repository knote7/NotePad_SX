﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace NiggerDick
{
    public partial class FeedBack : Form
    {
        public FeedBack()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {


            using (dWebHook dcWeb = new dWebHook())
            {
                dcWeb.ProfilePicture = "https://cdn.discordapp.com/banners/839516571474984980/a_8f2a280d6887c1eebe352b1baeef5be2.png?size=512";
                dcWeb.UserName = "DODO#1919"; //this guy is orphanage >.< lol bitch
                dcWeb.WebHook = "https://discord.com/api/webhooks/877133440259076117/7f-47Ii84WP9w9u60Rc0YJXSkfMbehJst6NNVdsZ2vKIcYJYnV2ecGEM3eS8FOrvW4PA";
                dcWeb.SendMessage(textBox1.Text);
                MessageBox.Show("Feedback sent successfully!\nThanks for your feedback!","NotePad");
                Close();
            }
        }
    }
}
