﻿
namespace NiggerDick
{
    partial class NotePad
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NotePad));
            iTalk.ControlRenderer controlRenderer1 = new iTalk.ControlRenderer();
            iTalk.MSColorTable msColorTable1 = new iTalk.MSColorTable();
            this.scintilla2 = new ScintillaNET.Scintilla();
            this.panel1 = new System.Windows.Forms.Panel();
            this.Exe = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.OpenFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.isAttached = new System.Windows.Forms.Timer(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.isrunning = new System.Windows.Forms.Timer(this.components);
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.executeToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.loadToEditorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refreshToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.niggertextbox = new System.Windows.Forms.TextBox();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.MonacoShit = new System.Windows.Forms.WebBrowser();
            this.iTalk_MenuStrip1 = new iTalk.iTalk_MenuStrip();
            this.menuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.New_TOOL = new System.Windows.Forms.ToolStripMenuItem();
            this.shitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.saveAsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.niggerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.undoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.cutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deleteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.searchWithBingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.serchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.replaceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.goToToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.selectAllToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.formatToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.wordWrapToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nigToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.setDefaultFontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.scriptListBoxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sendFeedbackToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exploitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.executeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.injectToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scriptHubToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.darkDexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unnamedToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.remoteSpyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.darkGUIToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gameSenseToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.infiniteYieldFEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.ctrlClickTPToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.antiAFKToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fullbrightToggleToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scintillaNETToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aceEditorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.annoyingToAddToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.monacoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.darkToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator7 = new System.Windows.Forms.ToolStripSeparator();
            this.killRobloxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.multiRolobxToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.robloxAppBetaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.updateLogToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.okItsBugShitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            this.contextMenuStrip1.SuspendLayout();
            this.iTalk_MenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // scintilla2
            // 
            this.scintilla2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.scintilla2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.scintilla2.Location = new System.Drawing.Point(-1, 27);
            this.scintilla2.Name = "scintilla2";
            this.scintilla2.Size = new System.Drawing.Size(809, 419);
            this.scintilla2.TabIndex = 2;
            this.scintilla2.Text = "nigger";
            this.scintilla2.CharAdded += new System.EventHandler<ScintillaNET.CharAddedEventArgs>(this.scintilla2_CharAdded);
            this.scintilla2.InsertCheck += new System.EventHandler<ScintillaNET.InsertCheckEventArgs>(this.scintilla2_InsertCheck);
            this.scintilla2.ZoomChanged += new System.EventHandler<System.EventArgs>(this.scintilla2_ZoomChanged);
            this.scintilla2.SizeChanged += new System.EventHandler(this.scintilla2_SizeChanged);
            this.scintilla2.TextChanged += new System.EventHandler(this.scintilla2_TextChanged);
            this.scintilla2.Click += new System.EventHandler(this.scintilla2_Click);
            this.scintilla2.KeyDown += new System.Windows.Forms.KeyEventHandler(this.scintilla2_KeyDown);
            this.scintilla2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.scintilla2_KeyPress);
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.Controls.Add(this.Exe);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(-1, 448);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(789, 20);
            this.panel1.TabIndex = 3;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            // 
            // Exe
            // 
            this.Exe.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.Exe.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Exe.BackgroundImage")));
            this.Exe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.Exe.FlatAppearance.BorderColor = System.Drawing.SystemColors.Control;
            this.Exe.FlatAppearance.BorderSize = 0;
            this.Exe.FlatAppearance.MouseDownBackColor = System.Drawing.Color.LightGray;
            this.Exe.FlatAppearance.MouseOverBackColor = System.Drawing.Color.White;
            this.Exe.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Exe.ForeColor = System.Drawing.SystemColors.Control;
            this.Exe.Location = new System.Drawing.Point(0, 0);
            this.Exe.Name = "Exe";
            this.Exe.Size = new System.Drawing.Size(25, 21);
            this.Exe.TabIndex = 5;
            this.Exe.UseVisualStyleBackColor = true;
            this.Exe.Click += new System.EventHandler(this.Exe_Click);
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.panel5.BackColor = System.Drawing.Color.LightGray;
            this.panel5.Location = new System.Drawing.Point(524, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(1, 20);
            this.panel5.TabIndex = 4;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.label3.Location = new System.Drawing.Point(531, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(33, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "100%";
            this.label3.TextChanged += new System.EventHandler(this.label3_TextChanged);
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.BackColor = System.Drawing.Color.LightGray;
            this.panel4.Location = new System.Drawing.Point(575, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1, 20);
            this.panel4.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.label2.Location = new System.Drawing.Point(582, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Windows (CRLF)";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.Color.LightGray;
            this.panel2.Location = new System.Drawing.Point(688, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1, 20);
            this.panel2.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.label1.Location = new System.Drawing.Point(695, 3);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(37, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "UTF-8";
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.BackColor = System.Drawing.Color.LightGray;
            this.panel3.Location = new System.Drawing.Point(-21, 448);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(862, 1);
            this.panel3.TabIndex = 2;
            // 
            // OpenFileDialog1
            // 
            this.OpenFileDialog1.AddExtension = false;
            this.OpenFileDialog1.Filter = "Lua files|*.lua;*.txt|All files|*.*";
            this.OpenFileDialog1.SupportMultiDottedExtensions = true;
            this.OpenFileDialog1.Title = "Open Script";
            // 
            // saveFileDialog1
            // 
            this.saveFileDialog1.Filter = "Lua files|*.lua;*.txt|All files|*.*";
            this.saveFileDialog1.Title = "Save Script";
            // 
            // isAttached
            // 
            this.isAttached.Enabled = true;
            this.isAttached.Interval = 10;
            this.isAttached.Tick += new System.EventHandler(this.isAttached_Tick);
            // 
            // timer1
            // 
            this.timer1.Interval = 10000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // isrunning
            // 
            this.isrunning.Enabled = true;
            this.isrunning.Interval = 10;
            this.isrunning.Tick += new System.EventHandler(this.isrunning_Tick);
            // 
            // listBox1
            // 
            this.listBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.listBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listBox1.ContextMenuStrip = this.contextMenuStrip1;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(584, 27);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(217, 418);
            this.listBox1.TabIndex = 4;
            this.listBox1.Visible = false;
            this.listBox1.SelectedIndexChanged += new System.EventHandler(this.listBox1_SelectedIndexChanged);
            this.listBox1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.listBox1_MouseDown);
            this.listBox1.MouseLeave += new System.EventHandler(this.listBox1_MouseLeave);
            this.listBox1.MouseHover += new System.EventHandler(this.listBox1_MouseHover);
            this.listBox1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.listBox1_MouseUp);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.executeToolStripMenuItem1,
            this.loadToEditorToolStripMenuItem,
            this.refreshToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(151, 70);
            this.contextMenuStrip1.Opening += new System.ComponentModel.CancelEventHandler(this.contextMenuStrip1_Opening);
            // 
            // executeToolStripMenuItem1
            // 
            this.executeToolStripMenuItem1.Name = "executeToolStripMenuItem1";
            this.executeToolStripMenuItem1.Size = new System.Drawing.Size(150, 22);
            this.executeToolStripMenuItem1.Text = "Execute";
            this.executeToolStripMenuItem1.Click += new System.EventHandler(this.executeToolStripMenuItem1_Click);
            // 
            // loadToEditorToolStripMenuItem
            // 
            this.loadToEditorToolStripMenuItem.Name = "loadToEditorToolStripMenuItem";
            this.loadToEditorToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.loadToEditorToolStripMenuItem.Text = "Load to Editor";
            this.loadToEditorToolStripMenuItem.Click += new System.EventHandler(this.loadToEditorToolStripMenuItem_Click);
            // 
            // refreshToolStripMenuItem
            // 
            this.refreshToolStripMenuItem.Name = "refreshToolStripMenuItem";
            this.refreshToolStripMenuItem.Size = new System.Drawing.Size(150, 22);
            this.refreshToolStripMenuItem.Text = "Refresh";
            this.refreshToolStripMenuItem.Click += new System.EventHandler(this.refreshToolStripMenuItem_Click);
            // 
            // niggertextbox
            // 
            this.niggertextbox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.niggertextbox.Location = new System.Drawing.Point(105, 79);
            this.niggertextbox.Name = "niggertextbox";
            this.niggertextbox.Size = new System.Drawing.Size(100, 13);
            this.niggertextbox.TabIndex = 5;
            this.niggertextbox.Visible = false;
            this.niggertextbox.TextChanged += new System.EventHandler(this.niggertextbox_TextChanged);
            // 
            // webBrowser1
            // 
            this.webBrowser1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.webBrowser1.Location = new System.Drawing.Point(-1, 27);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.Size = new System.Drawing.Size(809, 419);
            this.webBrowser1.TabIndex = 6;
            this.webBrowser1.Url = new System.Uri("", System.UriKind.Relative);
            this.webBrowser1.Visible = false;
            // 
            // MonacoShit
            // 
            this.MonacoShit.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.MonacoShit.Location = new System.Drawing.Point(-1, 27);
            this.MonacoShit.MinimumSize = new System.Drawing.Size(20, 20);
            this.MonacoShit.Name = "MonacoShit";
            this.MonacoShit.Size = new System.Drawing.Size(809, 419);
            this.MonacoShit.TabIndex = 7;
            this.MonacoShit.Url = new System.Uri("", System.UriKind.Relative);
            this.MonacoShit.Visible = false;
            this.MonacoShit.DocumentCompleted += new System.Windows.Forms.WebBrowserDocumentCompletedEventHandler(this.MonacoShit_DocumentCompleted);
            // 
            // iTalk_MenuStrip1
            // 
            this.iTalk_MenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuToolStripMenuItem,
            this.niggerToolStripMenuItem,
            this.formatToolStripMenuItem1,
            this.viewToolStripMenuItem1,
            this.helpToolStripMenuItem1,
            this.exploitToolStripMenuItem});
            this.iTalk_MenuStrip1.Location = new System.Drawing.Point(0, 0);
            this.iTalk_MenuStrip1.Name = "iTalk_MenuStrip1";
            controlRenderer1.ColorTable = msColorTable1;
            controlRenderer1.RoundedEdges = true;
            this.iTalk_MenuStrip1.Renderer = controlRenderer1;
            this.iTalk_MenuStrip1.Size = new System.Drawing.Size(808, 24);
            this.iTalk_MenuStrip1.TabIndex = 1;
            this.iTalk_MenuStrip1.Text = "iTalk_MenuStrip1";
            this.iTalk_MenuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.iTalk_MenuStrip1_ItemClicked);
            // 
            // menuToolStripMenuItem
            // 
            this.menuToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.New_TOOL,
            this.shitToolStripMenuItem,
            this.openToolStripMenuItem,
            this.saveToolStripMenuItem,
            this.saveAsToolStripMenuItem,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.menuToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.menuToolStripMenuItem.Name = "menuToolStripMenuItem";
            this.menuToolStripMenuItem.ShortcutKeyDisplayString = "F";
            this.menuToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.menuToolStripMenuItem.Text = "File";
            // 
            // New_TOOL
            // 
            this.New_TOOL.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.New_TOOL.Name = "New_TOOL";
            this.New_TOOL.ShortcutKeyDisplayString = "Ctrl+N";
            this.New_TOOL.Size = new System.Drawing.Size(222, 22);
            this.New_TOOL.Text = "New";
            this.New_TOOL.Click += new System.EventHandler(this.New_TOOL_Click);
            // 
            // shitToolStripMenuItem
            // 
            this.shitToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.shitToolStripMenuItem.Name = "shitToolStripMenuItem";
            this.shitToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+Shift+N";
            this.shitToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.shitToolStripMenuItem.Text = "New Window";
            this.shitToolStripMenuItem.Click += new System.EventHandler(this.shitToolStripMenuItem_Click);
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+O";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // saveToolStripMenuItem
            // 
            this.saveToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.saveToolStripMenuItem.Name = "saveToolStripMenuItem";
            this.saveToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl+S";
            this.saveToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.saveToolStripMenuItem.Text = "Save";
            this.saveToolStripMenuItem.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // saveAsToolStripMenuItem
            // 
            this.saveAsToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.saveAsToolStripMenuItem.Name = "saveAsToolStripMenuItem";
            this.saveAsToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.saveAsToolStripMenuItem.Text = "Save As";
            this.saveAsToolStripMenuItem.Click += new System.EventHandler(this.saveAsToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(219, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(222, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // niggerToolStripMenuItem
            // 
            this.niggerToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.undoToolStripMenuItem,
            this.redoToolStripMenuItem,
            this.toolStripSeparator2,
            this.cutToolStripMenuItem,
            this.copyToolStripMenuItem,
            this.pasteToolStripMenuItem,
            this.deleteToolStripMenuItem,
            this.toolStripSeparator3,
            this.searchWithBingToolStripMenuItem,
            this.serchToolStripMenuItem,
            this.replaceToolStripMenuItem,
            this.goToToolStripMenuItem,
            this.toolStripSeparator4,
            this.selectAllToolStripMenuItem});
            this.niggerToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.niggerToolStripMenuItem.Name = "niggerToolStripMenuItem";
            this.niggerToolStripMenuItem.ShortcutKeyDisplayString = "E";
            this.niggerToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.niggerToolStripMenuItem.Text = "Edit";
            this.niggerToolStripMenuItem.Click += new System.EventHandler(this.niggerToolStripMenuItem_Click);
            this.niggerToolStripMenuItem.MouseEnter += new System.EventHandler(this.niggerToolStripMenuItem_MouseEnter);
            this.niggerToolStripMenuItem.VisibleChanged += new System.EventHandler(this.niggerToolStripMenuItem_VisibleChanged);
            // 
            // undoToolStripMenuItem
            // 
            this.undoToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.undoToolStripMenuItem.Name = "undoToolStripMenuItem";
            this.undoToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl + Z";
            this.undoToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.undoToolStripMenuItem.Text = "Undo";
            this.undoToolStripMenuItem.Click += new System.EventHandler(this.undoToolStripMenuItem_Click);
            // 
            // redoToolStripMenuItem
            // 
            this.redoToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.redoToolStripMenuItem.Name = "redoToolStripMenuItem";
            this.redoToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl + Y";
            this.redoToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.redoToolStripMenuItem.Text = "Redo";
            this.redoToolStripMenuItem.Click += new System.EventHandler(this.redoToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(172, 6);
            // 
            // cutToolStripMenuItem
            // 
            this.cutToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cutToolStripMenuItem.Name = "cutToolStripMenuItem";
            this.cutToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl + X";
            this.cutToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.cutToolStripMenuItem.Text = "Cut";
            this.cutToolStripMenuItem.Click += new System.EventHandler(this.cutToolStripMenuItem_Click);
            // 
            // copyToolStripMenuItem
            // 
            this.copyToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.copyToolStripMenuItem.Name = "copyToolStripMenuItem";
            this.copyToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl + C";
            this.copyToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.copyToolStripMenuItem.Text = "Copy";
            this.copyToolStripMenuItem.Click += new System.EventHandler(this.copyToolStripMenuItem_Click);
            // 
            // pasteToolStripMenuItem
            // 
            this.pasteToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.pasteToolStripMenuItem.Name = "pasteToolStripMenuItem";
            this.pasteToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl + V";
            this.pasteToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.pasteToolStripMenuItem.Text = "Paste";
            this.pasteToolStripMenuItem.Click += new System.EventHandler(this.pasteToolStripMenuItem_Click);
            // 
            // deleteToolStripMenuItem
            // 
            this.deleteToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.deleteToolStripMenuItem.Name = "deleteToolStripMenuItem";
            this.deleteToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.deleteToolStripMenuItem.Text = "Delete";
            this.deleteToolStripMenuItem.Click += new System.EventHandler(this.deleteToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(172, 6);
            // 
            // searchWithBingToolStripMenuItem
            // 
            this.searchWithBingToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.searchWithBingToolStripMenuItem.Name = "searchWithBingToolStripMenuItem";
            this.searchWithBingToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.searchWithBingToolStripMenuItem.Text = "Search with Bing";
            this.searchWithBingToolStripMenuItem.Click += new System.EventHandler(this.searchWithBingToolStripMenuItem_Click);
            // 
            // serchToolStripMenuItem
            // 
            this.serchToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.serchToolStripMenuItem.Name = "serchToolStripMenuItem";
            this.serchToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl + F";
            this.serchToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.serchToolStripMenuItem.Text = "Find...";
            this.serchToolStripMenuItem.Click += new System.EventHandler(this.serchToolStripMenuItem_Click);
            // 
            // replaceToolStripMenuItem
            // 
            this.replaceToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.replaceToolStripMenuItem.Name = "replaceToolStripMenuItem";
            this.replaceToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl + H";
            this.replaceToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.replaceToolStripMenuItem.Text = "Replace...";
            this.replaceToolStripMenuItem.Click += new System.EventHandler(this.replaceToolStripMenuItem_Click);
            // 
            // goToToolStripMenuItem
            // 
            this.goToToolStripMenuItem.Enabled = false;
            this.goToToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.goToToolStripMenuItem.Name = "goToToolStripMenuItem";
            this.goToToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.goToToolStripMenuItem.Text = "Go To...";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(172, 6);
            // 
            // selectAllToolStripMenuItem
            // 
            this.selectAllToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.selectAllToolStripMenuItem.Name = "selectAllToolStripMenuItem";
            this.selectAllToolStripMenuItem.ShortcutKeyDisplayString = "Ctrl + A";
            this.selectAllToolStripMenuItem.Size = new System.Drawing.Size(175, 22);
            this.selectAllToolStripMenuItem.Text = "Select All";
            this.selectAllToolStripMenuItem.Click += new System.EventHandler(this.selectAllToolStripMenuItem_Click);
            // 
            // formatToolStripMenuItem1
            // 
            this.formatToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.wordWrapToolStripMenuItem,
            this.nigToolStripMenuItem,
            this.setDefaultFontToolStripMenuItem});
            this.formatToolStripMenuItem1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.formatToolStripMenuItem1.Name = "formatToolStripMenuItem1";
            this.formatToolStripMenuItem1.ShortcutKeyDisplayString = "O";
            this.formatToolStripMenuItem1.Size = new System.Drawing.Size(57, 20);
            this.formatToolStripMenuItem1.Text = "Format";
            this.formatToolStripMenuItem1.Click += new System.EventHandler(this.formatToolStripMenuItem1_Click);
            this.formatToolStripMenuItem1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.formatToolStripMenuItem1_MouseDown);
            this.formatToolStripMenuItem1.MouseEnter += new System.EventHandler(this.formatToolStripMenuItem1_MouseEnter);
            // 
            // wordWrapToolStripMenuItem
            // 
            this.wordWrapToolStripMenuItem.CheckOnClick = true;
            this.wordWrapToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.wordWrapToolStripMenuItem.Name = "wordWrapToolStripMenuItem";
            this.wordWrapToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.wordWrapToolStripMenuItem.Text = "Word Wrap";
            this.wordWrapToolStripMenuItem.CheckedChanged += new System.EventHandler(this.wordWrapToolStripMenuItem_CheckedChanged);
            this.wordWrapToolStripMenuItem.Click += new System.EventHandler(this.wordWrapToolStripMenuItem_Click);
            // 
            // nigToolStripMenuItem
            // 
            this.nigToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.nigToolStripMenuItem.Name = "nigToolStripMenuItem";
            this.nigToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.nigToolStripMenuItem.Text = "Font";
            this.nigToolStripMenuItem.Click += new System.EventHandler(this.nigToolStripMenuItem_Click);
            // 
            // setDefaultFontToolStripMenuItem
            // 
            this.setDefaultFontToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.setDefaultFontToolStripMenuItem.Name = "setDefaultFontToolStripMenuItem";
            this.setDefaultFontToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.setDefaultFontToolStripMenuItem.Text = "Set Default Font";
            this.setDefaultFontToolStripMenuItem.Click += new System.EventHandler(this.setDefaultFontToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem1
            // 
            this.viewToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.scriptListBoxToolStripMenuItem});
            this.viewToolStripMenuItem1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.viewToolStripMenuItem1.Name = "viewToolStripMenuItem1";
            this.viewToolStripMenuItem1.ShortcutKeyDisplayString = "V";
            this.viewToolStripMenuItem1.Size = new System.Drawing.Size(45, 20);
            this.viewToolStripMenuItem1.Text = "View";
            // 
            // scriptListBoxToolStripMenuItem
            // 
            this.scriptListBoxToolStripMenuItem.CheckOnClick = true;
            this.scriptListBoxToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.scriptListBoxToolStripMenuItem.Name = "scriptListBoxToolStripMenuItem";
            this.scriptListBoxToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
            this.scriptListBoxToolStripMenuItem.Text = "Script List Box";
            this.scriptListBoxToolStripMenuItem.CheckedChanged += new System.EventHandler(this.scriptListBoxToolStripMenuItem_CheckedChanged);
            this.scriptListBoxToolStripMenuItem.Click += new System.EventHandler(this.scriptListBoxToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem1
            // 
            this.helpToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.helpToolStripMenuItem,
            this.sendFeedbackToolStripMenuItem});
            this.helpToolStripMenuItem1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.helpToolStripMenuItem1.Name = "helpToolStripMenuItem1";
            this.helpToolStripMenuItem1.ShortcutKeyDisplayString = "H";
            this.helpToolStripMenuItem1.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem1.Text = "Help";
            this.helpToolStripMenuItem1.Click += new System.EventHandler(this.helpToolStripMenuItem1_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.helpToolStripMenuItem_Click);
            // 
            // sendFeedbackToolStripMenuItem
            // 
            this.sendFeedbackToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.sendFeedbackToolStripMenuItem.Name = "sendFeedbackToolStripMenuItem";
            this.sendFeedbackToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.sendFeedbackToolStripMenuItem.Text = "Send Feedback";
            this.sendFeedbackToolStripMenuItem.Click += new System.EventHandler(this.sendFeedbackToolStripMenuItem_Click);
            // 
            // exploitToolStripMenuItem
            // 
            this.exploitToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.executeToolStripMenuItem,
            this.cToolStripMenuItem,
            this.injectToolStripMenuItem,
            this.toolStripSeparator5,
            this.settingsToolStripMenuItem,
            this.scriptHubToolStripMenuItem,
            this.editorToolStripMenuItem,
            this.toolStripSeparator7,
            this.killRobloxToolStripMenuItem,
            this.multiRolobxToolStripMenuItem,
            this.robloxAppBetaToolStripMenuItem,
            this.updateLogToolStripMenuItem});
            this.exploitToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.exploitToolStripMenuItem.Name = "exploitToolStripMenuItem";
            this.exploitToolStripMenuItem.Size = new System.Drawing.Size(55, 20);
            this.exploitToolStripMenuItem.Text = "Exploit";
            // 
            // executeToolStripMenuItem
            // 
            this.executeToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.executeToolStripMenuItem.Name = "executeToolStripMenuItem";
            this.executeToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.executeToolStripMenuItem.Text = "Execute";
            this.executeToolStripMenuItem.Click += new System.EventHandler(this.executeToolStripMenuItem_Click);
            // 
            // cToolStripMenuItem
            // 
            this.cToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.cToolStripMenuItem.Name = "cToolStripMenuItem";
            this.cToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.cToolStripMenuItem.Text = "Execute Line";
            this.cToolStripMenuItem.Click += new System.EventHandler(this.cToolStripMenuItem_Click);
            // 
            // injectToolStripMenuItem
            // 
            this.injectToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.injectToolStripMenuItem.Name = "injectToolStripMenuItem";
            this.injectToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.injectToolStripMenuItem.Text = "Inject";
            this.injectToolStripMenuItem.Click += new System.EventHandler(this.injectToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(194, 6);
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.settingsToolStripMenuItem.Text = "Settings";
            this.settingsToolStripMenuItem.Click += new System.EventHandler(this.settingsToolStripMenuItem_Click);
            // 
            // scriptHubToolStripMenuItem
            // 
            this.scriptHubToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.darkDexToolStripMenuItem,
            this.unnamedToolStripMenuItem,
            this.remoteSpyToolStripMenuItem,
            this.darkGUIToolStripMenuItem,
            this.gameSenseToolStripMenuItem,
            this.infiniteYieldFEToolStripMenuItem,
            this.toolStripSeparator6,
            this.ctrlClickTPToolStripMenuItem,
            this.antiAFKToolStripMenuItem,
            this.fullbrightToggleToolStripMenuItem});
            this.scriptHubToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.scriptHubToolStripMenuItem.Name = "scriptHubToolStripMenuItem";
            this.scriptHubToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.scriptHubToolStripMenuItem.Text = "Script Hub";
            // 
            // darkDexToolStripMenuItem
            // 
            this.darkDexToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.darkDexToolStripMenuItem.Name = "darkDexToolStripMenuItem";
            this.darkDexToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.darkDexToolStripMenuItem.Text = "Dark Dex";
            this.darkDexToolStripMenuItem.Click += new System.EventHandler(this.darkDexToolStripMenuItem_Click);
            // 
            // unnamedToolStripMenuItem
            // 
            this.unnamedToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.unnamedToolStripMenuItem.Name = "unnamedToolStripMenuItem";
            this.unnamedToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.unnamedToolStripMenuItem.Text = "Unnamed ESP";
            this.unnamedToolStripMenuItem.Click += new System.EventHandler(this.unnamedToolStripMenuItem_Click);
            // 
            // remoteSpyToolStripMenuItem
            // 
            this.remoteSpyToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.remoteSpyToolStripMenuItem.Name = "remoteSpyToolStripMenuItem";
            this.remoteSpyToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.remoteSpyToolStripMenuItem.Text = "Remote Spy";
            this.remoteSpyToolStripMenuItem.Click += new System.EventHandler(this.remoteSpyToolStripMenuItem_Click);
            // 
            // darkGUIToolStripMenuItem
            // 
            this.darkGUIToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.darkGUIToolStripMenuItem.Name = "darkGUIToolStripMenuItem";
            this.darkGUIToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.darkGUIToolStripMenuItem.Text = "Dark Hub";
            this.darkGUIToolStripMenuItem.Click += new System.EventHandler(this.darkGUIToolStripMenuItem_Click);
            // 
            // gameSenseToolStripMenuItem
            // 
            this.gameSenseToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.gameSenseToolStripMenuItem.Name = "gameSenseToolStripMenuItem";
            this.gameSenseToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.gameSenseToolStripMenuItem.Text = "Game Sense Aimbot";
            this.gameSenseToolStripMenuItem.Click += new System.EventHandler(this.gameSenseToolStripMenuItem_Click);
            // 
            // infiniteYieldFEToolStripMenuItem
            // 
            this.infiniteYieldFEToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.infiniteYieldFEToolStripMenuItem.Name = "infiniteYieldFEToolStripMenuItem";
            this.infiniteYieldFEToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.infiniteYieldFEToolStripMenuItem.Text = "Infinite Yield FE";
            this.infiniteYieldFEToolStripMenuItem.Click += new System.EventHandler(this.infiniteYieldFEToolStripMenuItem_Click);
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(181, 6);
            // 
            // ctrlClickTPToolStripMenuItem
            // 
            this.ctrlClickTPToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.ctrlClickTPToolStripMenuItem.Name = "ctrlClickTPToolStripMenuItem";
            this.ctrlClickTPToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.ctrlClickTPToolStripMenuItem.Text = "Ctrl + Click TP";
            this.ctrlClickTPToolStripMenuItem.Click += new System.EventHandler(this.ctrlClickTPToolStripMenuItem_Click);
            // 
            // antiAFKToolStripMenuItem
            // 
            this.antiAFKToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.antiAFKToolStripMenuItem.Name = "antiAFKToolStripMenuItem";
            this.antiAFKToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.antiAFKToolStripMenuItem.Text = "Anti-AFK";
            this.antiAFKToolStripMenuItem.Click += new System.EventHandler(this.antiAFKToolStripMenuItem_Click);
            // 
            // fullbrightToggleToolStripMenuItem
            // 
            this.fullbrightToggleToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.fullbrightToggleToolStripMenuItem.Name = "fullbrightToggleToolStripMenuItem";
            this.fullbrightToggleToolStripMenuItem.Size = new System.Drawing.Size(184, 22);
            this.fullbrightToggleToolStripMenuItem.Text = "Fullbright [Toggle]";
            this.fullbrightToggleToolStripMenuItem.Click += new System.EventHandler(this.fullbrightToggleToolStripMenuItem_Click);
            // 
            // editorToolStripMenuItem
            // 
            this.editorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.scintillaNETToolStripMenuItem,
            this.aceEditorToolStripMenuItem,
            this.monacoToolStripMenuItem});
            this.editorToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.editorToolStripMenuItem.Name = "editorToolStripMenuItem";
            this.editorToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.editorToolStripMenuItem.Text = "Editor";
            // 
            // scintillaNETToolStripMenuItem
            // 
            this.scintillaNETToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.scintillaNETToolStripMenuItem.Name = "scintillaNETToolStripMenuItem";
            this.scintillaNETToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.scintillaNETToolStripMenuItem.Text = "Scintilla NET";
            this.scintillaNETToolStripMenuItem.Click += new System.EventHandler(this.scintillaNETToolStripMenuItem_Click);
            // 
            // aceEditorToolStripMenuItem
            // 
            this.aceEditorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.annoyingToAddToolStripMenuItem});
            this.aceEditorToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.aceEditorToolStripMenuItem.Name = "aceEditorToolStripMenuItem";
            this.aceEditorToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.aceEditorToolStripMenuItem.Text = "Ace Editor";
            this.aceEditorToolStripMenuItem.Click += new System.EventHandler(this.aceEditorToolStripMenuItem_Click);
            // 
            // annoyingToAddToolStripMenuItem
            // 
            this.annoyingToAddToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.annoyingToAddToolStripMenuItem.Name = "annoyingToAddToolStripMenuItem";
            this.annoyingToAddToolStripMenuItem.Size = new System.Drawing.Size(165, 22);
            this.annoyingToAddToolStripMenuItem.Text = "Annoying to add";
            // 
            // monacoToolStripMenuItem
            // 
            this.monacoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.darkToolStripMenuItem,
            this.lightToolStripMenuItem});
            this.monacoToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.monacoToolStripMenuItem.Name = "monacoToolStripMenuItem";
            this.monacoToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.monacoToolStripMenuItem.Text = "Monaco";
            this.monacoToolStripMenuItem.Click += new System.EventHandler(this.monacoToolStripMenuItem_Click);
            // 
            // darkToolStripMenuItem
            // 
            this.darkToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.darkToolStripMenuItem.Name = "darkToolStripMenuItem";
            this.darkToolStripMenuItem.Size = new System.Drawing.Size(101, 22);
            this.darkToolStripMenuItem.Text = "Dark";
            this.darkToolStripMenuItem.Click += new System.EventHandler(this.darkToolStripMenuItem_Click);
            // 
            // lightToolStripMenuItem
            // 
            this.lightToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.lightToolStripMenuItem.Name = "lightToolStripMenuItem";
            this.lightToolStripMenuItem.Size = new System.Drawing.Size(101, 22);
            this.lightToolStripMenuItem.Text = "Light";
            this.lightToolStripMenuItem.Click += new System.EventHandler(this.lightToolStripMenuItem_Click);
            // 
            // toolStripSeparator7
            // 
            this.toolStripSeparator7.Name = "toolStripSeparator7";
            this.toolStripSeparator7.Size = new System.Drawing.Size(194, 6);
            // 
            // killRobloxToolStripMenuItem
            // 
            this.killRobloxToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.killRobloxToolStripMenuItem.Name = "killRobloxToolStripMenuItem";
            this.killRobloxToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.killRobloxToolStripMenuItem.Text = "Kill Roblox";
            this.killRobloxToolStripMenuItem.Click += new System.EventHandler(this.killRobloxToolStripMenuItem_Click);
            // 
            // multiRolobxToolStripMenuItem
            // 
            this.multiRolobxToolStripMenuItem.CheckOnClick = true;
            this.multiRolobxToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.multiRolobxToolStripMenuItem.Name = "multiRolobxToolStripMenuItem";
            this.multiRolobxToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.multiRolobxToolStripMenuItem.Text = "Multi Rolobx";
            this.multiRolobxToolStripMenuItem.CheckedChanged += new System.EventHandler(this.multiRolobxToolStripMenuItem_CheckedChanged);
            this.multiRolobxToolStripMenuItem.Click += new System.EventHandler(this.multiRolobxToolStripMenuItem_Click);
            // 
            // robloxAppBetaToolStripMenuItem
            // 
            this.robloxAppBetaToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.robloxAppBetaToolStripMenuItem.Name = "robloxAppBetaToolStripMenuItem";
            this.robloxAppBetaToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.robloxAppBetaToolStripMenuItem.Text = "Open Roblox App Beta";
            this.robloxAppBetaToolStripMenuItem.Click += new System.EventHandler(this.robloxAppBetaToolStripMenuItem_Click);
            // 
            // updateLogToolStripMenuItem
            // 
            this.updateLogToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.okItsBugShitToolStripMenuItem});
            this.updateLogToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.updateLogToolStripMenuItem.Name = "updateLogToolStripMenuItem";
            this.updateLogToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.updateLogToolStripMenuItem.Text = "Update Log";
            this.updateLogToolStripMenuItem.Click += new System.EventHandler(this.updateLogToolStripMenuItem_Click);
            // 
            // okItsBugShitToolStripMenuItem
            // 
            this.okItsBugShitToolStripMenuItem.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.okItsBugShitToolStripMenuItem.Name = "okItsBugShitToolStripMenuItem";
            this.okItsBugShitToolStripMenuItem.Size = new System.Drawing.Size(385, 22);
            this.okItsBugShitToolStripMenuItem.Text = "In my opinion, the highlight text color was prettier before";
            this.okItsBugShitToolStripMenuItem.Click += new System.EventHandler(this.okItsBugShitToolStripMenuItem_Click);
            // 
            // NotePad
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(808, 468);
            this.Controls.Add(this.MonacoShit);
            this.Controls.Add(this.webBrowser1);
            this.Controls.Add(this.iTalk_MenuStrip1);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.scintilla2);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.niggertextbox);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(300, 39);
            this.Name = "NotePad";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.Text = "NotePad";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.NotePad_FormClosing);
            this.Load += new System.EventHandler(this.NotePad_Load);
            this.MouseHover += new System.EventHandler(this.NotePad_MouseHover);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.contextMenuStrip1.ResumeLayout(false);
            this.iTalk_MenuStrip1.ResumeLayout(false);
            this.iTalk_MenuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private iTalk.iTalk_MenuStrip iTalk_MenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem menuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem New_TOOL;
        private System.Windows.Forms.ToolStripMenuItem shitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem niggerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem formatToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem1;
        
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Exe;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem saveToolStripMenuItem;
        public System.Windows.Forms.OpenFileDialog OpenFileDialog1;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.ToolStripMenuItem saveAsToolStripMenuItem;
        private System.Windows.Forms.Timer isAttached;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer isrunning;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem undoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redoToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem cutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem deleteToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem searchWithBingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem serchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem replaceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem goToToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem selectAllToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sendFeedbackToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exploitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem injectToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem executeToolStripMenuItem;
        public ScintillaNET.Scintilla scintilla2;
        private System.Windows.Forms.ToolStripMenuItem wordWrapToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nigToolStripMenuItem;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem executeToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem refreshToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scriptListBoxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loadToEditorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem setDefaultFontToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scriptHubToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem darkDexToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem unnamedToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem remoteSpyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem darkGUIToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripMenuItem ctrlClickTPToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem antiAFKToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gameSenseToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator7;
        private System.Windows.Forms.ToolStripMenuItem killRobloxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem updateLogToolStripMenuItem;
        private System.Windows.Forms.TextBox niggertextbox;
        private System.Windows.Forms.ToolStripMenuItem okItsBugShitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem infiniteYieldFEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem multiRolobxToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem robloxAppBetaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fullbrightToggleToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cToolStripMenuItem;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.ToolStripMenuItem editorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scintillaNETToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aceEditorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem monacoToolStripMenuItem;
        private System.Windows.Forms.WebBrowser MonacoShit;
        private System.Windows.Forms.ToolStripMenuItem annoyingToAddToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem darkToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lightToolStripMenuItem;
    }
}

