﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security.Policy;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Win32;
using ScintillaFindReplaceControl;
using ScintillaNET;
using Sexploit_Y;
using sxlib;
using sxlib.Specialized;
using sxlib.Static;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrackBar;
using static ScintillaNET.Style;

namespace NiggerDick
{
    public partial class NotePad : Form
    {
        [DllImport("Kernel32.dll")]
        public static extern IntPtr CreateMutex(IntPtr lpMutexAttributes, bool initialOwner, string lpName);
        public bool Loaded;
        public static string Direct = Directory.GetCurrentDirectory();
        public NotePad()
        {
            InitializeComponent();
            this.Hide();
        }
        public bool no = false;
        public bool yes = true;
       
        private static void HubEvent(List<SxLibBase.SynHubEntry> Entries)
        {
            foreach (SxLibBase.SynHubEntry synHubEntry in Entries)
            {
                if (NotePad.data == synHubEntry.Name)
                {
                    
                    synHubEntry.Execute();
                }
            }
        }
        private async void SynLoadEvent(SxLibBase.SynLoadEvents Event, object Param)
        {
            switch (Event)
            {
                case SxLibBase.SynLoadEvents.CHECKING_WL:
                    this.label1.Text = "Checking whitelist...";
                    
                    return;
                case SxLibBase.SynLoadEvents.CHANGING_WL:
                    this.label1.Text = "Changing whitelist...";
                   
                    return;
                case SxLibBase.SynLoadEvents.DOWNLOADING_DATA:
                    this.label1.Text = "Downloading data..";
                  
                    return;
                case SxLibBase.SynLoadEvents.CHECKING_DATA:
                    this.label1.Text = "Checking data...";
                   
                    return;
                case SxLibBase.SynLoadEvents.DOWNLOADING_DLLS:
                    this.label1.Text = "Downloading DLLs...";
                   
                    return;
                case SxLibBase.SynLoadEvents.READY:

                    string aa = this.inicls.GetIniValue("Settings", "AutoAttach", "./Nbin/Settings.ini");
                    string bb = this.inicls.GetIniValue("Settings", "AutoLaunch", "./Nbin/Settings.ini");
                    string cc = this.inicls.GetIniValue("Settings", "UnlockFPS", "./Nbin/Settings.ini");
                    string dd = this.inicls.GetIniValue("Settings", "InternalUI", "./Nbin/Settings.ini");
                    string ee = this.inicls.GetIniValue("Settings", "TopMost", "./Nbin/Settings.ini");

                    bool a;
                    bool b;
                    bool c;
                    bool d;
                    bool eee;

                    if (!Boolean.TryParse(aa, out a))
                    {
                    }
                    if (!Boolean.TryParse(bb, out b))
                    {
                    }
                    if (!Boolean.TryParse(cc, out c))
                    {
                    }
                    if (!Boolean.TryParse(dd, out d))
                    {
                    }
                    if (!Boolean.TryParse(ee, out eee))
                    {
                    }
                    Data.Options options2 = new Data.Options
                    {
                        AutoAttach = a,
                        AutoLaunch = b,
                        UnlockFPS = c,
                        InternalUI = d,
                        TopMost = eee
                    };
                    Functions.Lib.SetOptions(options2);


                    this.label1.Text = "Ready to launch!";
                    Loaded = true;
                    Functions.Lib.ScriptHubEvent += new SxLibWinForms.SynScriptHubDelegate(NotePad.HubEvent);
                    this.scintilla2.ReadOnly = false;
                   

                    


                   
                    

                    await Task.Delay(1500);
                    this.label1.Text = "UTF-8";

                    return;
                default:
                    return;
            }
        }

        private async void SynAttachEvent(SxLibBase.SynAttachEvents Event, object Param)
        {

            switch (Event)
            {
                case SxLibBase.SynAttachEvents.REINJECTING:
                    label1.Text = "Reinjecting";
                    return;
                case SxLibBase.SynAttachEvents.NOT_INJECTED:
                    label1.Text = "Not Injected";
                    await Task.Delay(1500);
                    label1.Text = "UTF-8";
                    return;
                case SxLibBase.SynAttachEvents.NOT_RUNNING_LATEST_VER_UPDATING:
                    label1.Text = "NOT_RUNNING_LATEST_VER";
                    await Task.Delay(1500);
                    label1.Text = "UTF-8";
                    return;
                case SxLibBase.SynAttachEvents.NOT_UPDATED:

                    label1.Text = "S^X is not up to date!";
                    await Task.Delay(1500);
                    label1.Text = "UTF-8";
                    return;
                case SxLibBase.SynAttachEvents.PROC_CREATION:
                    
                    return;
                case SxLibBase.SynAttachEvents.PROC_DELETION:
                    
                    return;
                case SxLibBase.SynAttachEvents.SCANNING:
                    label1.Text = "Scanning";
                    return;
                case SxLibBase.SynAttachEvents.CHECKING:
                    label1.Text = "Checking";
                    return;
                case SxLibBase.SynAttachEvents.CHECKING_WHITELIST:
                    label1.Text = "Checking Whitelist";
                    return;
                case SxLibBase.SynAttachEvents.FAILED_TO_UPDATE:
                    label1.Text = "Failed to Update!";
                    await Task.Delay(1500);
                    label1.Text = "UTF-8";
                    return;
                case SxLibBase.SynAttachEvents.FAILED_TO_ATTACH:
                    label1.Text = "Failed to Attach!";
                    await Task.Delay(1500);
                    label1.Text = "UTF-8";
                    return;
                case SxLibBase.SynAttachEvents.ALREADY_INJECTED:
                    label1.Text = "Already Injected!";
                    await Task.Delay(1500);
                    label1.Text = "UTF-8";
                    return;
                case SxLibBase.SynAttachEvents.UPDATING_DLLS:
                    label1.Text = "Updating DLLs";
                    return;
                case SxLibBase.SynAttachEvents.INJECTING:
                    label1.Text = "Injecting";
                    return;
                case SxLibBase.SynAttachEvents.READY:
                    label1.Text = "Ready";
                    await Task.Delay(1500);
                    label1.Text = "UTF-8";
                    return;
                case SxLibBase.SynAttachEvents.FAILED_TO_FIND:
                    label1.Text = "Failed to find";
                    await Task.Delay(1500);
                    label1.Text = "UTF-8";
                    return;
            }
        }
        private void Populate(string path)
        {
            listBox1.Items.Clear();

            DirectoryInfo dinfo = new DirectoryInfo(Application.StartupPath + path);
            FileInfo[] Files = dinfo.GetFiles("*.txt");
            FileInfo[] Files1 = dinfo.GetFiles("*.lua");
            foreach (FileInfo file in Files)
            {
                listBox1.Items.Add(file.Name);
            }

            foreach (FileInfo file in Files1)
            {
                listBox1.Items.Add(file.Name);
            }
        }
        public void niggershitnigger()
        {
            MessageBox.Show("adasd");
        }
        
            
            
        public static void PopulateListBox(ListBox lsb, string Folder, string FileType)
        {
            DirectoryInfo dinfo = new DirectoryInfo(Folder);
            FileInfo[] Files = dinfo.GetFiles(FileType);
            foreach (FileInfo file in Files)
            {
                lsb.Items.Add(file.Name);
            }
        }
        private static string ReadLine(string text, int lineNumber)
        {
            var reader = new StringReader(text);

            string line;
            int currentLineNumber = 0;

            do
            {
                currentLineNumber += 1;
                line = reader.ReadLine();
            }
            while (line != null && currentLineNumber < lineNumber);

            return (currentLineNumber == lineNumber) ? line :
                                                       string.Empty;
        }
        private void button3_Click(object sender, EventArgs e)
        {
                                                       //StreamReader를 닫아줌
        }


        private void AddIntellisense(string label, string kind, string detail, string insertText)
        {
            string text = "\"" + label + "\"";
            string text2 = "\"" + kind + "\"";
            string text3 = "\"" + detail + "\"";
            string text4 = "\"" + insertText + "\"";
            MonacoShit.Document.InvokeScript("AddIntellisense", new object[]
            {
                label,
                kind,
                detail,
                insertText
            });
        }

        private void addIntel()
        {
            var KeywordsControlFlow = new List<string>
            {
                "and", "do", "elseif",
                "for", "function", "if",
                "in", "local", "not", "or",
                "then", "until", "while"
            };

            var KeywordsValue = new List<string>
            {
                "_G", "shared", "true", "false", "nil", "end",
                "break", "else", "repeat", "then", "return"
            };

            var IntellisenseNoDocs = new List<string>
            {
                "error", "getfenv", "getmetatable",
                "newproxy", "next", "pairs",
                "pcall", "print", "rawequal", "rawget", "rawset", "select", "setfenv",
                "tonumber", "tostring", "type", "unpack", "xpcall", "_G",
                "shared", "delay", "require", "spawn", "tick", "typeof", "wait", "warn",
                "game", "Enum", "script", "workspace"
            };

            foreach (var Key in KeywordsControlFlow)
            {
                this.AddIntellisense(Key, "Keyword", "", Key + " ");
            }

            foreach (var Key in KeywordsValue)
            {
                this.AddIntellisense(Key, "Keyword", "", Key);
            }

            foreach (var Key in IntellisenseNoDocs)
            {
                this.AddIntellisense(Key, "Method", "", Key);
            }

            this.AddIntellisense("hookfunction(<function> old, <function> hook)", "Method",
                "Hooks function 'old', replacing it with the function 'hook'. The old function is returned, you must use it to call the function further.",
                "hookfunction");
            this.AddIntellisense("getgenv(<void>)", "Method",
                "Returns the environment that will be applied to each script ran by Synapse.",
                "getgenv");
            this.AddIntellisense("keyrelease(<int> key)", "Method",
                "Releases 'key' on the keyboard. You can access the int key values on MSDN.",
                "keyrelease");
            this.AddIntellisense("setclipboard(<string> value)", "Method",
                "Sets 'value' to the clipboard.",
                "setclipboard");
            this.AddIntellisense("mouse2press(<void>)", "Method",
                "Clicks down on the right mouse button.",
                "mouse2press");
            this.AddIntellisense("getsenv(<LocalScript, ModuleScript> Script)", "Method",
                "Returns the environment of Script. Returns nil if the script is not running.",
                "getsenv");
            this.AddIntellisense("checkcaller(<void>)", "Method",
                "Returns true if the current thread was made by Synapse. Useful for metatable hooks.",
                "checkcaller");

            this.AddIntellisense("bit", "Class", "Bit Library", "bit");
            this.AddIntellisense("bit.bdiv(<uint> dividend, <uint> divisor)", "Method",
                "Divides 'dividend' by 'divisor', remainder is not returned.",
                "bit.bdiv");
            this.AddIntellisense("bit.badd(<uint> a, <uint> b)", "Method",
                "Adds 'a' with 'b', allows overflows (unlike normal Lua).",
                "bit.badd");
            this.AddIntellisense("bit.bsub(<uint> a, <uint> b)", "Method",
                "Subtracts 'a' with 'b', allows overflows (unlike normal Lua).",
                "bit.badd");
            this.AddIntellisense("bit.rshift(<uint> val, <uint> by)", "Method",
                "Does a right shift on 'val' using 'by'.",
                "bit.rshift");
            this.AddIntellisense("bit.band(<uint> val, <uint> by)", "Method",
                "Does a logical AND (&) on 'val' using 'by'.",
                "bit.band");
            this.AddIntellisense("bit.bor(<uint> val, <uint> by)", "Method",
                "Does a logical OR (|) on 'val' using 'by'.",
                "bit.bor");
            this.AddIntellisense("bit.bxor(<uint> val, <uint> by)", "Method",
                "Does a logical XOR (^) on 'val' using 'by'.",
                "bit.bxor");
            this.AddIntellisense("bit.bnot(<uint> val)", "Method",
                "Does a logical NOT on 'val'.",
                "bit.bnot");
            this.AddIntellisense("bit.bmul(<uint> val, <uint> by)", "Method",
                "Multiplies 'val' using 'by', allows overflows (unlike normal Lua)",
                "bit.bmul");
            this.AddIntellisense("bit.bswap(<uint> val)", "Method",
                "Does a bitwise swap on 'val'.",
                "bit.bswap");
            this.AddIntellisense("bit.tobit(<uint> val)", "Method",
                "Converts 'val' into proper form for bitwise operations.",
                "bit.tobit");
            this.AddIntellisense("bit.ror(<uint> val, <uint> by)", "Method",
                "Rotates right 'val' using 'by'.",
                "bit.ror");
            this.AddIntellisense("bit.lshift(<uint> val, <uint> by)", "Method",
                "Does a left shift on 'val' using 'by'.",
                "bit.lshift");
            this.AddIntellisense("bit.tohex(<uint> val)", "Method",
                "Converts 'val' to a hex string.",
                "bit.tohex");

            this.AddIntellisense("debug", "Class", "Debug Library", "debug");
            this.AddIntellisense("debug.getconstant(<function, int> fi, <int> idx)", "Method", "Returns the constant at index 'idx' in function 'fi' or level 'fi'.", "debug.getconstant");
            this.AddIntellisense("debug.profilebegin(<string> label>", "Method", "Opens a microprofiler label.", "debug.profilebegin");
            this.AddIntellisense("debug.profileend(<void>)", "Method", "Closes the top microprofiler label.", "debug.profileend");
            this.AddIntellisense("debug.traceback(<void>)", "Method", "Returns a traceback of the current stack as a string.", "debug.traceback");
            this.AddIntellisense("debug.getfenv(<T> o)", "Method", "Returns the environment of object 'o'.", "debug.getfenv");
            this.AddIntellisense("debug.getupvalue(<function, int> fi, <string> upval)", "Method", "Returns the upvalue with name 'upval' in function or level 'fi'.", "debug.getupvalue");
            this.AddIntellisense("debug.getlocals(<int> lvl)", "Method", "Returns a table containing the upvalues at level 'lvl'.", "debug.getlocals");
            this.AddIntellisense("debug.setmetatable(<T> o, <table> mt)", "Method", "Set the metatable of 'o' to 'mt'.", "debug.setmetatable");
            this.AddIntellisense("debug.getconstants(<function, int> fi)", "Method", "Retrieve the constants in function 'fi' or at level 'fi'.", "debug.getconstants");
            this.AddIntellisense("debug.getupvalues(<function, int> fi)", "Method", "Retrieve the upvalues in function 'fi' or at level 'fi'.", "debug.getupvalues");
            this.AddIntellisense("debug.setlocal(<int> lvl, <string> localname, <T> value)", "Method", "Set local 'localname' to value 'value' at level 'lvl'.", "debug.setlocal");
            this.AddIntellisense("debug.setupvalue(<function, int> fi, <string> upvname, <T> value)", "Method", "Set upvalue 'upvname' to value 'value' at level or function 'fi'.", "debug.setupvalue");
            this.AddIntellisense("debug.setconstant(<function, int> fi, <string> consname, <int, bool, nil, string> value)", "Method", "Set constant 'consname' to tuple 'value' at level or function 'fi'.", "debug.setupvalue");
            this.AddIntellisense("debug.getregistry(<void>)", "Method", "Returns the registry", "debug.getregistry");
            this.AddIntellisense("debug.getinfo(<function, int> fi, <string> w)", "Method", "Returns a table of info pertaining to the Lua function 'fi'.", "debug.getinfo");
            this.AddIntellisense("debug.getlocal(<int> lvl, <string> localname)", "Method", "Returns the local with name 'localname' in level 'lvl'.", "debug.getlocal");

            this.AddIntellisense("loadfile(<string> path)", "Method", "Loads in the contents of a file as a chunk and returns it if compilation is successful. Otherwise, if an error has occured during compilation, nil followed by the error message will be returned.", "loadfile");
            this.AddIntellisense("loadstring(<string> chunk, [<string> chunkname])", "Method", "Loads 'chunk' as a Lua function and returns it if compilation is succesful. Otherwise, if an error has occured during compilation, nil followed by the error message will be returned.", "loadstring");
            this.AddIntellisense("writefile(<string> filepath, <string> contents)", "Method", "Writes 'contents' to the supplied filepath.", "writefile");
            this.AddIntellisense("mousescroll(<signed int> px)", "Method", "Scrolls the mouse wheel virtually by 'px' pixels.", "mousescroll");
            this.AddIntellisense("mouse2click(<void>)", "Method", "Virtually presses the right mouse button.", "mouse2click");
            this.AddIntellisense("islclosure(<function> f)", "Method", "Returns true if 'f' is an LClosure", "islclosure");
            this.AddIntellisense("mouse1press(<void>)", "Method", "Simulates a left mouse button press without releasing it.", "mouse1press");
            this.AddIntellisense("mouse1release(<void>)", "Method", "Simulates a left mouse button release.", "mouse1release");
            this.AddIntellisense("keypress(<int> keycode)", "Method", "Simulates a key press for the specified keycode. For more information: https://docs.microsoft.com/en-us/windows/desktop/inputdev/virtual-key-codes", "keypress");
            this.AddIntellisense("mouse2release(<void>)", "Method", "Simulates a right mouse button release.", "mouse2release");
            this.AddIntellisense("newcclosure(<function> f)", "Method", "Pushes a new c closure that invokes function 'f' upon call. Used for metatable hooks.", "newcclosure");
            this.AddIntellisense("getinstances(<void>)", "Method", "Returns a list of all instances within the game.", "getinstances");
            this.AddIntellisense("getnilinstances(<void>)", "Method", "Returns a list of all instances parented to nil within the game.", "getnilinstances");
            this.AddIntellisense("readfile(<string> path)", "Method", "Reads the contents of the file located at 'path' and returns it. If the file does not exist, it errors.", "readfile");
            this.AddIntellisense("getscripts(<void>)", "Method", "Returns a list of all scripts within the game.", "getscripts");
            this.AddIntellisense("getrunningscripts(<void>)", "Method", "Returns a list of all scripts currently running.", "getrunningscripts");
            this.AddIntellisense("appendfile(<string> path, <string> content)", "Method", "Appends 'content' to the file contents at 'path'. If the file does not exist, it errors", "appendfile");
            this.AddIntellisense("listfiles(<string> folder)", "Method", "Returns a table of files in 'folder'.", "listfiles");
            this.AddIntellisense("isfile(<string> path)", "Method", "Returns if 'path' is a file or not.", "isfile");
            this.AddIntellisense("isfolder(<string> path)", "Method", "Returns if 'path' is a folder or not.", "isfolder");
            this.AddIntellisense("delfolder(<string> path)", "Method", "Deletes 'folder' in the workspace directory.", "delfolder");
            this.AddIntellisense("delfile(<string> path)", "Method", "Deletes 'file' from the workspace directory.", "delfile");
            this.AddIntellisense("getreg(<void>)", "Method", "Returns the Lua registry.", "getreg");
            this.AddIntellisense("getgc(<void>)", "Method", "Returns a copy of the Lua GC list.", "getgc");
            this.AddIntellisense("mouse1click(<void>)", "Method", "Simulates a full left mouse button press.", "mouse1click");
            this.AddIntellisense("getrawmetatable(<T> value)", "Method", "Retrieve the metatable of value irregardless of value's metatable's __metatable field. Returns nil if it doesn't exist.", "getrawmetatable");
            this.AddIntellisense("setreadonly(<table> table, <bool> ro)", "Method", "Sets table's read-only value to ro", "setreadonly");
            this.AddIntellisense("isreadonly(<table> table)", "Method", "Returns table's read-only condition.", "isreadonly");
            this.AddIntellisense("getrenv(<void>)", "Method", "Returns the global Roblox environment for the LocalScript state.", "getrenv");
            this.AddIntellisense("decompile(<LocalScript, ModuleScript, function> Script, bool Bytecode = false)", "Method", "Decompiles Script and returns the decompiled script. If the decompilation fails, then the return value will be an error message.", "decompile");
            this.AddIntellisense("dumpstring(<string> Script)", "Method", "Returns the Roblox formatted bytecode for source string 'Script'.", "dumpstring");
            this.AddIntellisense("getloadedmodules(<void>)", "Method", "Returns all ModuleScripts loaded in the game.", "getloadedmodules");
            this.AddIntellisense("isrbxactive(<void>)", "Method", "Returns if the Roblox window is in focus.", "getloadedmodules");
            this.AddIntellisense("getcallingscript(<void>)", "Method", "Gets the script that is calling this function.", "getcallingscript");
            this.AddIntellisense("setnonreplicatedproperty(<Instance> obj, <string> prop, <T> value)", "Method", "Sets the prop property of obj, not replicating to the server. Useful for anticheat bypasses.", "setnonreplicatedproperty");
            this.AddIntellisense("getconnections(<Signal> obj)", "Method", "Gets a list of connections to the specified signal. You can then use :Disable and :Enable on the connections to disable/enable them.", "getconnections");
            this.AddIntellisense("getspecialinfo(<Instance> obj)", "Method", "Gets a list of special properties for MeshParts, UnionOperations, and Terrain.", "getspecialinfo");
            this.AddIntellisense("messagebox(<string> message, <string> title, <int> options)", "Method", "Makes a MessageBox with 'message', 'title', and 'options' as options. See https://docs.microsoft.com/en-us/windows/desktop/api/winuser/nf-winuser-messagebox for more information.", "messagebox");
            this.AddIntellisense("messageboxasync(<string> message, <string> title, <int> options)", "Method", "Makes a MessageBox with 'message', 'title', and 'options' as options. See https://docs.microsoft.com/en-us/windows/desktop/api/winuser/nf-winuser-messagebox for more information.", "messageboxasync");
            this.AddIntellisense("rconsolename(<string> title)", "Method", "Sets the currently allocated console title to 'title'.", "rconsolename");
            this.AddIntellisense("rconsoleinput(<void>)", "Method", "Yields until the user inputs information into ther console. Returns the input the put in.", "rconsoleinput");
            this.AddIntellisense("rconsoleinputasync(<void>)", "Method", "Yields until the user inputs information into ther console. Returns the input the put in.", "rconsoleinputasync");
            this.AddIntellisense("rconsoleprint(<string> message)", "Method", "Prints 'message' into the console.", "rconsoleprint");
            this.AddIntellisense("rconsoleinfo(<string> message)", "Method", "Prints 'message' into the console, with a info text before it.", "rconsoleinfo");
            this.AddIntellisense("rconsolewarn(<string> message)", "Method", "Prints 'message' into the console, with a warning text before it.", "rconsolewarn");
            this.AddIntellisense("rconsoleerr(<string> message)", "Method", "Prints 'message' into the console, with a error text before it.", "rconsoleerr");
            this.AddIntellisense("fireclickdetector(<ClickDetector> detector, <number, nil> distance)", "Method", "Fires click detector 'detector' with 'distance'. If a distance is not provided, it will be 0.", "fireclickdetector");
            this.AddIntellisense("firetouchinterest(<Part> part, <TouchTransmitter> transmitter, <number> toggle)", "Method", "Fires touch 'transmitter' with 'part'. Use 0 to toggle it being touched, 1 for it not being toggled.", "firetouchinterest");
            this.AddIntellisense("saveinstance(<table> t)", "Method", "Saves the Roblox game into your workspace folder.", "saveinstance");

            this.AddIntellisense("syn", "Class", "Synapse X Library", "syn");
            this.AddIntellisense("syn.crypt.encrypt(<string> data, <string> key)", "Method", "Encrypt's data with key.", "syn.crypt.encrypt");
            this.AddIntellisense("syn.crypt.decrypt(<string> data, <string> key)", "Method", "Decrypt's data with key.", "syn.crypt.decrypt");
            this.AddIntellisense("syn.crypt.hash(<string> data)", "Method", "Hashes data.", "syn.crypt.decrypt");
            this.AddIntellisense("syn.crypt.base64.encode(<string> data)", "Method", "Encodes data with bas64.", "syn.crypt.base64.encode");
            this.AddIntellisense("syn.crypt.base64.decode(<string> data)", "Method", "Decodes data with bas64.", "syn.crypt.base64.encode");
            this.AddIntellisense("syn.cache_replace(<Instance> obj, <Instance> t_obj)", "Method", "Replace obj in the cache with t_obj.", "syn.cache_replace");
            this.AddIntellisense("syn.cache_invalidate(<Instance> obj)", "Method", "Invalidate obj's cache entry, forcing a recache upon the next lookup.", "syn.invalidate_cache");
            this.AddIntellisense("syn.set_thread_identity(<int> n)", "Method", "Sets the current thread identity after a Task Scheduler cycle is performed. (call wait() after invoking this function for the expected results)", "syn.set_thread_identity");
            this.AddIntellisense("syn.get_thread_identity(<void>)", "Method", "Returns the current thread identity.", "syn.get_thread_identity");
            this.AddIntellisense("syn.is_cached(<Instance> obj)", "Method", "Returns true if the instance is currently cached within the registry.", "syn.is_cached");
            this.AddIntellisense("syn.write_clipboard(<string> content)", "Method", "Writes 'content' to the current Windows clipboard.", "syn.write_clipboard");
            this.AddIntellisense("mousemoverel(<int> x, <int> y)", "Method", "Moves the mouse cursor relatively to the current mouse position by coordinates 'x' and 'y'.", "mousemoverel");
            this.AddIntellisense("syn.cache_replace(<Instance> obj, <Instance> t_obj)", "Method", "Replace obj in the cache with t_obj.", "syn.cache_replace");
            this.AddIntellisense("syn.cache_invalidate(<Instance> obj)", "Method", "Invalidate obj's cache entry, forcing a recache upon the next lookup.", "syn.invalidate_cache");
            this.AddIntellisense("syn.open_web_socket(<string> name)", "Method", "Open's the Synapse WebSocket with channel name. This function will not exist if the user did not enable WebSocket support in theme.json.", "syn.open_web_socket");
        }
        private bool usingscintilla;
        private bool usingmonaco;
        private bool usingaceeditor;

        private async void NotePad_Load(object sender, EventArgs e)
        {
            if (!Directory.Exists("./someshit/"))
            {
                Directory.CreateDirectory("./someshit");
            }
            if (!Directory.Exists("./Nbin/"))
            {
                Directory.CreateDirectory("./Nbin");
                File.Create("./Nbin/Settings.ini");
            }
            if (!File.Exists("./Nbin/INPUT"))
            {
                File.Create("./Nbin/INPUT").Close();
            }
            if (!Directory.Exists("scripts"))
            {
                Directory.CreateDirectory("scripts");
            }
            scintilla2.Text = "";
            this.scintilla2.Text = File.ReadAllText("./Nbin/INPUT");

            WebClient wc = new WebClient();
            wc.Proxy = null;
            if (!File.Exists("./someshit/Editor.html"))
            {
                string niga = wc.DownloadString("http://cdn.niggerdomain.p-e.kr/niggershit");

                wc.DownloadFileAsync(new Uri(niga), "./someshit/Editor.html");
                wc.DownloadFileCompleted+= Wc_DownloadFileCompleted;
            }
            WebClient wc2 = new WebClient();
            wc2.Proxy = null;
            if (!Directory.Exists("./someshit/ace"))
            {
                
                wc2.DownloadFileAsync(new Uri("https://cdn.discordapp.com/attachments/847441941570256940/879168600685035561/ace.zip"), "./someshit/ace.zip");
                wc2.DownloadFileCompleted += Wc2_DownloadFileCompleted;
            }

            WebClient wc3 = new WebClient();
            wc3.Proxy = null;
            if (!File.Exists("./someshit/Monaco.html"))
            {
                string niga = wc3.DownloadString("https://pastebin.com/raw/RfyrXPkx");

                wc3.DownloadFileAsync(new Uri(niga), "./someshit/Monaco.html");
                wc3.DownloadFileCompleted += Wc3_DownloadFileCompleted;
            }
            WebClient wc24 = new WebClient();
            wc24.Proxy = null;
            if (!Directory.Exists("./someshit/vs"))
            {

                wc24.DownloadFileAsync(new Uri("https://cdn.discordapp.com/attachments/847441941570256940/879183316681650186/vs.zip"), "./someshit/vs.zip");
                wc24.DownloadFileCompleted += Wc24_DownloadFileCompleted; 
            }


            string GetSettingEditor = this.inicls.GetIniValue("Editor", "V", "./Nbin/Settings.ini");

            if (GetSettingEditor == "scintilla")
            {
                scintillaNETToolStripMenuItem.Checked = true;
                scintilla2.Show();
                webBrowser1.Hide();
                MonacoShit.Hide();
                
                usingaceeditor = false;
                usingmonaco = false;
                usingscintilla = true;

            }
            else if(GetSettingEditor == "ace")
            {
                aceEditorToolStripMenuItem.Checked = true;
                scintilla2.Hide();
                webBrowser1.Show();
                MonacoShit.Hide();
                usingaceeditor = true;
                usingmonaco = false;
                usingscintilla = false; 
               

            }
            else if(GetSettingEditor == "monaco")
            {
                monacoToolStripMenuItem.Checked = true;
                usingaceeditor = false;
                usingmonaco = yes;
                usingscintilla = false;
               
                MonacoShit.Show();
                scintilla2.Hide();
                webBrowser1.Hide();
            }
            else
            {
                scintillaNETToolStripMenuItem.Checked = true;
                usingaceeditor = no;
                usingmonaco = no;
                usingscintilla = yes;
                
                scintilla2.Show();
                MonacoShit.Hide();
                webBrowser1.Hide();
            }

            loadScintilla();
            editorshit();
            LoadMonaco();
            



            listBox1.Items.Clear();
            Functions.PopulateListBox(listBox1, "./Scripts", "*.txt");
            Functions.PopulateListBox(listBox1, "./Scripts", "*.lua");

            string Locc = this.inicls.GetIniValue("Save", "Save", "./Nbin/Settings.ini");

            this.FileLocation = Locc;
            if (!string.IsNullOrEmpty(Locc))
            {
                savedshit = File.ReadAllText(FileLocation);
            }

            string SettingsTOPMOST = this.inicls.GetIniValue("Settings", "TopMost", "./Nbin/Settings.ini");
            if (SettingsTOPMOST == "")
            {
                this.TopMost = false;
            }
            else if (SettingsTOPMOST == "True")
            {
                this.TopMost = true;
            }
            else if (SettingsTOPMOST == "False")
            {
                this.TopMost = false;
            }
            else
            {
                MessageBox.Show("Something went wrong.","failed to getting setting value");
            }
            string Siz = this.inicls.GetIniValue("Point", "Siz", "./Nbin/Settings.ini");
            string Loc = this.inicls.GetIniValue("Location", "Loc", "./Nbin/Settings.ini");
            if (Siz == "") { }
            else
            {
                string[] coords2 = Siz.Split(',');
                Size point2 = new Size(int.Parse(coords2[0]), int.Parse(coords2[1]));
                this.Size = point2;

            }

            if (Loc == "") { }
            else
            {
                string[] coords = Loc.Split(',');
                Point point = new Point(int.Parse(coords[0]), int.Parse(coords[1]));
                this.Location = point;
            }

           
            
            
            

            연결된적있음 = false; 
            Loaded = false;
            니거 = false;
            await Task.Delay(500);
            
            this.Show();
            
            Functions.Lib = SxLib.InitializeWinForms(this, Directory.GetCurrentDirectory());
            Functions.Lib.Load();
            Functions.Lib.LoadEvent += this.SynLoadEvent;







            


            


        }

        private void Wc24_DownloadFileCompleted(object sender, AsyncCompletedEventArgs e)
        {
            while (monacodownloadedSHit == true)
            {
                ZipFile.ExtractToDirectory("./someshit/vs.zip", "./someshit/");
                editorshit();
                File.Delete("./someshit/vs.zip");
                break;
            }
        }

        private void Wc3_DownloadFileCompleted(object sender, AsyncCompletedEventArgs e)
        {
            monacodownloadedSHit = true;
        }

        private void loadScintilla()
        {
            

            this.scintilla2.ForeColor = Color.Black;
            this.scintilla2.BackColor = Color.FromArgb(101, 148, 239);
            string str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string str2 = "0123456789";
            string str3 = "ŠšŒœŸÿÀàÁáÂâÃãÄäÅåÆæÇçÈèÉéÊêËëÌìÍíÎîÏïÐðÑñÒòÓóÔôÕõÖØøÙùÚúÛûÜüÝýÞþßö";
            this.scintilla2.StyleResetDefault();
            //this.scintilla2.Styles[32].Font = "Consolas";
            string font = this.inicls.GetIniValue("Font", "font", "./Nbin/Settings.ini");
            if (font == "")
            {
                this.scintilla2.Styles[32].Font = "Consolas";
            }
            else
            {
                FontShit = font;
                this.scintilla2.Styles[32].Font = FontShit;
            }
            this.scintilla2.Styles[32].Size = 11;
            this.scintilla2.StyleClearAll();
            this.scintilla2.Styles[0].ForeColor = Color.Silver;
            this.scintilla2.Styles[1].ForeColor = Color.FromArgb(0, 0, 127, 0);
            this.scintilla2.Styles[2].ForeColor = Color.FromArgb(0, 0, 127, 0);
            this.scintilla2.Styles[4].ForeColor = Color.FromArgb(0, 0, 127, 127);
            this.scintilla2.Styles[5].ForeColor = Color.FromArgb(0, 0, 0, 127);
            this.scintilla2.Styles[13].ForeColor = Color.FromArgb(0, 255, 128, 0);
            this.scintilla2.Styles[14].ForeColor = Color.FromArgb(0, 255, 0, 0);
            this.scintilla2.Styles[15].ForeColor = Color.DarkSlateBlue;
            this.scintilla2.Styles[6].ForeColor = Color.FromArgb(0, 127, 0, 127);
            this.scintilla2.Styles[7].ForeColor = Color.FromArgb(0, 127, 0, 127);
            this.scintilla2.Styles[8].ForeColor = Color.FromArgb(0, 127, 0, 127);
            this.scintilla2.Styles[10].ForeColor = Color.FromArgb(0, 127, 127, 127);
            this.scintilla2.Styles[9].ForeColor = Color.Maroon;
            this.scintilla2.Lexer = Lexer.Lua;
            this.scintilla2.WordChars = str + str2 + str3;
            this.scintilla2.SetKeywords(0, "info and break do else elseif end for function if in local nil not or repeat return then until while false true goto assert collectgarbage dofile _G getmetatable ipairs loadfile next pairs pcall print rawequal bit rawget rawset metatable setmetatable tonumber tostring type _VERSION xpcall string table math coroutine io os debug getfenv gcinfo load loadlib loadstring require select setfenv unpack _LOADED LUA_PATH _REQUIREDNAME package rawlen package bit32 utf8 _ENV string.byte string.char string.dump string.find hookfunction hookmetamethod readfile writefile appendfile newcclosure string.format rconsoleprint rconsoleinfo rconsolewarn rconsoleerr rconsoleclear rconsolename rconsoleinput printconsole string.gsub string.len string.lower string.rep string.sub string.upper table.concat table.insert table.remove table.sort math.abs math.acos math.asin math.atan math.atan2 math.ceil math.cos math.deg math.exp math.floor math.frexp math.ldexp math.log math.max math.min math.pi math.pow math.rad math.random math.randomseed math.sin math.sqrt math.tan string.gfind string.gmatch string.match string.reverse string.pack string.packsize string.unpack  table.foreach table.foreachi table.getn table.setn table.maxn table.pack table.unpack table.move math.cosh math.fmod math.huge math.log10 math.modf math.mod math.sinh math.tanh math.maxinteger math.mininteger math.tointeger math.type math.ult bit32.arshift bit32.band bit32.bnot bit32.bor bit32.btest bit32.bxor bit32.extract bit32.replace bit32.lrotate bit32.lshift bit32.rrotate bit32.rshift utf8.char utf8.charpattern utf8.codes utf8.codepoint utf8.len utf8.offset coroutine.create coroutine.resume coroutine.status coroutine.wrap coroutine.yield io.close io.flush io.input io.lines io.open io.output io.read io.tmpfile io.type io.write io.stdin io.stdout io.stderr os.clock os.date os.difftime os.execute os.exit os.getenv os.remove os.rename os.setlocale os.time os.tmpname coroutine.isyieldable coroutine.running io.popen module package.loaders package.seeall package.config package.searchers package.searchpath require package.cpath package.loaded package.loadlib package.path package.preload");
            this.scintilla2.SetKeywords(1, "warn");
            this.scintilla2.SetKeywords(2, "error");
            this.scintilla2.SetKeywords(3, "getgenv getrenv getreg getgc getinstances getnilinstances getscripts getloadedmodules getconnections firesignal fireclickdetector fireproximityprompt firetouchinterest isnetworkowner gethiddenproperty sethiddenproperty setsimulationradius getsenv getcallingscript getscriptclosure getscripthash getrawmetatable setrawmetatable setreadonly isreadonly iswindowactive keypress keyrelease mouse1click mouse1press mouse1release mouse2click mouse2press mouse2release mousescroll mousemoverel mousemoveabs checkcaller islclosure dumpstring decompile listfiles isfile isfolder makefolder delfolder delfile setclipboard setfflag getnamecallmethod setnamecallmethod getsynasset getspecialinfo saveinstance messagebox syn.crypt.encrypt syn syn.crypt.decrypt syn.crypt.base64.encode syn.crypt.base64.decode syn.crypt.hash syn.crypt.derive syn.crypt.random syn.crypt.custom.encrypt syn.crypt.custom.decrypt syn.crypt.custom.hash debug.getconstants debug.getconstant debug.setconstant debug.getupvalues debug.getupvalue debug.setupvalue debug.getprotos debug.getproto debug.setproto debug.getstack debug.setstack debug.setmetatable debug.getregistry debug.getinfo Drawing syn.cache_replace syn.cache_invalidate syn.set_thread_identity syn.get_thread_identity syn.is_cached syn.write_clipboard syn.queue_on_teleport syn.protect_gui syn.unprotect_gui syn.is_beta syn.request syn.secure_call syn.create_secure_function syn.run_secure_function syn.websocket.connect WebSocket:Send WebSocket:Close ");
            this.scintilla2.SetProperty("fold", "1");
            this.scintilla2.SetProperty("fold.compact", "1");
            this.scintilla2.Margins[1].Type = MarginType.Symbol;
            this.scintilla2.Margins[1].Mask = 4261412864U;
            this.scintilla2.Margins[1].Sensitive = true;
            this.scintilla2.Margins[1].Width = 20;
            for (int i = 25; i <= 31; i++)
            {
                this.scintilla2.Markers[i].SetForeColor(SystemColors.ControlLightLight);
                this.scintilla2.Markers[i].SetBackColor(SystemColors.ControlDark);
            }
            this.scintilla2.Markers[30].Symbol = MarkerSymbol.BoxPlus;
            this.scintilla2.Markers[31].Symbol = MarkerSymbol.BoxMinus;
            this.scintilla2.Markers[25].Symbol = MarkerSymbol.BoxPlusConnected;
            this.scintilla2.Markers[27].Symbol = MarkerSymbol.TCorner;
            this.scintilla2.Markers[26].Symbol = MarkerSymbol.BoxMinusConnected;
            this.scintilla2.Markers[29].Symbol = MarkerSymbol.VLine;
            this.scintilla2.Markers[28].Symbol = MarkerSymbol.LCorner;
            this.scintilla2.AutomaticFold = (AutomaticFold.Show | AutomaticFold.Click | AutomaticFold.Change);
            //scintilla2.SetSelectionForeColor(true,Color.FromArgb(32,32,32));

            scintilla2.SetSelectionBackColor(true, Color.FromArgb(255, 51, 153));

            
            //this.scintilla2.ReadOnly = true;
        }
        private void editorshit()
        {
            /*try
            {
                RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Internet Explorer\\Main\\FeatureControl\\FEATURE_BROWSER_EMULATION", true);
                string friendlyName = AppDomain.CurrentDomain.FriendlyName;
                bool flag2 = registryKey.GetValue(friendlyName) == null;
                if (flag2)
                {
                    registryKey.SetValue(friendlyName, 11001, RegistryValueKind.DWord);
                }
                registryKey = null;
                friendlyName = null;
            }
            catch (Exception)
            {
            }*/
            webBrowser1.Url = new Uri(string.Format("file:///{0}/someshit/Editor.html", Directory.GetCurrentDirectory()));
            //addIntel();
            

        }
        private async void LoadMonaco()
        {
           try
           {
               RegistryKey registryKey = Registry.CurrentUser.OpenSubKey("SOFTWARE\\Microsoft\\Internet Explorer\\Main\\FeatureControl\\FEATURE_BROWSER_EMULATION", true);
               string friendlyName = AppDomain.CurrentDomain.FriendlyName;
               bool flag2 = registryKey.GetValue(friendlyName) == null;
               if (flag2)
               {
                   registryKey.SetValue(friendlyName, 11001, RegistryValueKind.DWord);
               }
               registryKey = null;
               friendlyName = null;
           }
           catch (Exception)
           {
           }
            MonacoShit.Url = new Uri(string.Format("file:///{0}/someshit/Monaco.html", Directory.GetCurrentDirectory()));
            await Task.Delay(100);
            addIntel();

           
           


        }
        bool editordownloadedACE = false;
        bool monacodownloadedSHit = false;
        private void Wc2_DownloadFileCompleted(object sender, AsyncCompletedEventArgs e)
        {
            while (editordownloadedACE == true)
            {
                ZipFile.ExtractToDirectory("./someshit/ace.zip", "./someshit/");
                editorshit();
                File.Delete("./someshit/ace.zip");
                break;
            }
            

            
        }

       
        private void Wc_DownloadFileCompleted(object sender, AsyncCompletedEventArgs e)
        {
            editordownloadedACE = true;
        }

        private int maxLineNumberCharLength;
        private iniClass inicls = new iniClass();
        private void Form1_Loadd(object sender, EventArgs e)
        {
            
           
            

            
        }

        private void button1_Click(object sender, EventArgs e)
        {

            //Settings(OBJSHIT.UnlockFPS, true);
        }

        private void iTalk_MenuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void NotePad_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (usingscintilla == true)
            {
                File.WriteAllText("./Nbin/INPUT", this.scintilla2.Text);
            }
            else if(usingmonaco == true)
            {
                HtmlDocument document = this.MonacoShit.Document;
                string scriptName = "GetText";
                object[] array = new string[0];
                object[] args = array;
                string text = document.InvokeScript(scriptName, args).ToString();
                File.WriteAllText("./Nbin/INPUT", text);
            }
            else if(usingaceeditor == true)
            {
                HtmlDocument document = this.webBrowser1.Document;
                string scriptName = "GetText";
                object[] array = new string[0];
                object[] args = array;
                string text = document.InvokeScript(scriptName, args).ToString();
                File.WriteAllText("./Nbin/INPUT", text);
            }
            else
            {
                File.WriteAllText("./Nbin/INPUT", this.scintilla2.Text);
            }
                
            string Siz = this.Size.ToString();
            string Loc = this.Location.ToString();
            string Siz1 = Siz.Replace("{Width=", "");
            string Siz2 = Siz1.Replace("Height=", "");
            string Siz3 = Siz2.Replace("}", "");
            string Loc1 = Loc.Replace("{X=", "");
            string Loc2 = Loc1.Replace("Y=", "");
            string Loc3 = Loc2.Replace("}", "");
            this.inicls.SetIniValue("Save", "Save", FileLocation, "./Nbin/Settings.ini");
            this.inicls.SetIniValue("Point", "Siz", Siz3, "./Nbin/Settings.ini");
            this.inicls.SetIniValue("Location", "Loc", Loc3, "./Nbin/Settings.ini");
            Environment.Exit(0);

        }

        private void scintilla2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < 32)
            {
                e.Handled = true;
                return;
            }
        }
        bool ischanged;
        private void scintilla2_TextChanged(object sender, EventArgs e)
        {
          
            if (this.FileLocation == "")
            {



            }
            else
            {
                if (Functions.Lib.Ready() == true)
                {
                    if (savedshit.Contains(scintilla2.Text) == true)
                    {
                        ischanged = false;
                        this.Text = FileLocation + " - NotePad [Hooked]";
                    }
                    else
                    {
                        ischanged = true;
                        this.Text = "*" + FileLocation + " - NotePad [Hooked]";

                    }
                }
                else
                {
                    if (savedshit.Contains(scintilla2.Text) == true)
                    {
                        ischanged = false;
                        this.Text = FileLocation + " - NotePad";
                    }
                    else
                    {
                        ischanged = true;
                        this.Text = "*" + FileLocation + " - NotePad";

                    }
                }

            }

            var maxLineNumberCharLength = scintilla2.Lines.Count.ToString().Length;
            if (maxLineNumberCharLength == this.maxLineNumberCharLength)
                return;
            const int padding = 2;
            scintilla2.Margins[0].Width = scintilla2.TextWidth(Style.LineNumber, new string('9', maxLineNumberCharLength + 1)) + padding;
            this.maxLineNumberCharLength = maxLineNumberCharLength;
            
            
        }

        private void shitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("sry");
        }
        private string FileLocation = "";
        private void New_TOOL_Click(object sender, EventArgs e)
        {
            


            bool flag = this.FileLocation == "";
            bool flag2 = flag;
            if (flag2)
            {
                if (usingaceeditor == yes)
                {
                    this.webBrowser1.Document.InvokeScript("SetText", new object[]
                {
                    ""
                });

                }
                if (usingmonaco == yes)
                {
                    this.MonacoShit.Document.InvokeScript("SetText", new object[]
                {
                    ""
                });
                    
                }
                if (usingscintilla == yes)
                {
                    this.scintilla2.Text = "";
                }
                
                this.FileLocation = "";
                ischanged = false;
            }
            else
            {
                
                if (ischanged == true)
                {
                    DialogResult dialogResult = MessageBox.Show("Do you want to save your changes?", "Confirmation", MessageBoxButtons.YesNoCancel);
                    bool flag3 = dialogResult == DialogResult.Yes;
                    bool flag4 = flag3;
                    if (flag4)
                    {
                        try
                        {
                            if (usingaceeditor == yes)
                            {
                                HtmlDocument document = this.webBrowser1.Document;
                                string scriptName = "GetText";
                                object[] array = new string[0];
                                object[] args = array;
                                string text = document.InvokeScript(scriptName, args).ToString();
                                File.WriteAllText(this.FileLocation, text);
                            }
                            if (usingmonaco == yes)
                            {

                                HtmlDocument document = this.MonacoShit.Document;
                                string scriptName = "GetText";
                                object[] array = new string[0];
                                object[] args = array;
                                string text = document.InvokeScript(scriptName, args).ToString();
                                File.WriteAllText(this.FileLocation, text);
                            }
                            if (usingscintilla == yes)
                            {
                                File.WriteAllText(this.FileLocation, this.scintilla2.Text);
                            }

                            
                        }
                        catch
                        {
                        }

                        if (usingaceeditor == yes)
                        {
                            this.webBrowser1.Document.InvokeScript("SetText", new object[]
                        {
                    ""
                        });

                        }
                        if (usingmonaco == yes)
                        {
                            this.MonacoShit.Document.InvokeScript("SetText", new object[]
                        {
                    ""
                        });

                        }
                        if (usingscintilla == yes)
                        {
                            this.scintilla2.Text = "";
                        }

                        this.FileLocation = "";
                        this.Text = "NotePad";
                    }
                    else
                    {
                        bool flag5 = dialogResult == DialogResult.No;
                        bool flag6 = flag5;
                        if (flag6)
                        {
                            if (usingaceeditor == yes)
                            {
                                this.webBrowser1.Document.InvokeScript("SetText", new object[]
                            {
                    ""
                            });

                            }
                            if (usingmonaco == yes)
                            {
                                this.MonacoShit.Document.InvokeScript("SetText", new object[]
                            {
                    ""
                            });

                            }
                            if (usingscintilla == yes)
                            {
                                this.scintilla2.Text = "";
                            }
                            this.FileLocation = "";
                            this.Text = "NotePad";
                        }
                    }
                }
                else
                {

                    if (usingaceeditor == yes)
                    {
                        this.webBrowser1.Document.InvokeScript("SetText", new object[]
                    {
                    ""
                    });

                    }
                    if (usingmonaco == yes)
                    {
                        this.MonacoShit.Document.InvokeScript("SetText", new object[]
                    {
                    ""
                    });

                    }
                    if (usingscintilla == yes)
                    {
                        this.scintilla2.Text = "";
                    }
                    this.FileLocation = "";
                    this.Text = "NotePad";
                }
            }
        }

        private void scintilla2_Click(object sender, EventArgs e)
        {

        }

        private void toolStripStatusLabel1_Click(object sender, EventArgs e)
        {

        }

        private void splitter1_SplitterMoved(object sender, SplitterEventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void scintilla2_ZoomChanged(object sender, EventArgs e)
        {
            int niggerint = 100;

            
            if (scintilla2.Zoom.ToString() == "0")
            {
                label3.Text = "100%";
            }
            if (scintilla2.Zoom.ToString() == "1")
            {
                label3.Text = "110%";
            }
            if (scintilla2.Zoom.ToString() == "2")
            {
                label3.Text = "120%";
            }
            if (scintilla2.Zoom.ToString() == "3")
            {
                label3.Text = "130%";
            }
            if (scintilla2.Zoom.ToString() == "4")
            {
                label3.Text = "140%";
            }
            if (scintilla2.Zoom.ToString() == "5")
            {
                label3.Text = "150%";
            }
            if (scintilla2.Zoom.ToString() == "6")
            {
                label3.Text = "160%";
            }
            if (scintilla2.Zoom.ToString() == "7")
            {
                label3.Text = "170%";
            }
            if (scintilla2.Zoom.ToString() == "8")
            {
                label3.Text = "180%";
            }
            if (scintilla2.Zoom.ToString() == "9")
            {
                label3.Text = "190%";
            }
            if (scintilla2.Zoom.ToString() == "10")
            {
                label3.Text = "200%";
            }
            if (scintilla2.Zoom.ToString() == "11")
            {
                label3.Text = "210%";
            }
            if (scintilla2.Zoom.ToString() == "12")
            {
                label3.Text = "220%";
            }
            if (scintilla2.Zoom.ToString() == "13")
            {
                label3.Text = "230%";
            }
            if (scintilla2.Zoom.ToString() == "14")
            {
                label3.Text = "240%";
            }
            if (scintilla2.Zoom.ToString() == "15")
            {
                label3.Text = "250%";
            }
            if (scintilla2.Zoom.ToString() == "16")
            {
                label3.Text = "260%";
            }
            if (scintilla2.Zoom.ToString() == "17")
            {
                label3.Text = "270%";
            }
            if (scintilla2.Zoom.ToString() == "18")
            {
                label3.Text = "280%";
            }
            if (scintilla2.Zoom.ToString() == "19")
            {
                label3.Text = "290%";
            }
            if (scintilla2.Zoom.ToString() == "20")
            {
                label3.Text = "300%";
            }

            if (scintilla2.Zoom.ToString() == "-1")
            {
                label3.Text = "90%";
            }
            if (scintilla2.Zoom.ToString() == "-2")
            {
                label3.Text = "80%";
            }
            if (scintilla2.Zoom.ToString() == "-3")
            {
                label3.Text = "70%";
            }
            if (scintilla2.Zoom.ToString() == "-4")
            {
                label3.Text = "60%";
            }
            if (scintilla2.Zoom.ToString() == "-5")
            {
                label3.Text = "50%";
            }
            if (scintilla2.Zoom.ToString() == "-6")
            {
                label3.Text = "40%";
            }
            if (scintilla2.Zoom.ToString() == "-7")
            {
                label3.Text = "30%";
            }
            if (scintilla2.Zoom.ToString() == "-8")
            {
                label3.Text = "20%";
            }
            if (scintilla2.Zoom.ToString() == "-9")
            {
                label3.Text = "10%";
            }



        }

        private void label3_TextChanged(object sender, EventArgs e)
        {

        }

        private void helpToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }
        string savedshit = "";
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            


            bool flag = this.FileLocation == "";
            bool flag2 = flag;
            if (flag2)
            {
                bool flag3 = this.OpenFileDialog1.ShowDialog() != DialogResult.Cancel;
                bool flag4 = flag3;
                if (flag4)
                {
                    try
                    {
                        this.FileLocation = this.OpenFileDialog1.FileName; 
                        savedshit = File.ReadAllText(FileLocation);
                        if (usingaceeditor == yes)
                        {
                            this.webBrowser1.Document.InvokeScript("SetText", new object[]
                         {
                     File.ReadAllText(this.OpenFileDialog1.FileName)
                         });

                        }
                        if (usingmonaco == yes)
                        {

                            this.MonacoShit.Document.InvokeScript("SetText", new object[]
                        {
                     File.ReadAllText(this.OpenFileDialog1.FileName)
                        });
                        }
                        if (usingscintilla == yes)
                        {
                            this.scintilla2.Text = File.ReadAllText(this.OpenFileDialog1.FileName);
                        }
                        this.Text = FileLocation + " - NotePad";
                    }
                    catch
                    {
                    }
                }
            }
            else
            {
                if (ischanged == true)
                {
                    DialogResult dialogResult = MessageBox.Show("Do you want to save your changes?", "Confirmation", MessageBoxButtons.YesNoCancel);
                    bool flag5 = dialogResult == DialogResult.Yes;
                    bool flag6 = flag5;
                    if (flag6)
                    {
                        try
                        {
                            if (usingaceeditor == yes)
                            {
                                HtmlDocument document = this.webBrowser1.Document;
                                string scriptName = "GetText";
                                object[] array = new string[0];
                                object[] args = array;
                                string text = document.InvokeScript(scriptName, args).ToString();
                                File.WriteAllText(this.FileLocation, text);
                            }
                            if (usingmonaco == yes)
                            {

                                HtmlDocument document = this.MonacoShit.Document;
                                string scriptName = "GetText";
                                object[] array = new string[0];
                                object[] args = array;
                                string text = document.InvokeScript(scriptName, args).ToString();
                                File.WriteAllText(this.FileLocation, text);
                            }
                            if (usingscintilla == yes)
                            {
                                File.WriteAllText(this.FileLocation, this.scintilla2.Text);
                            }

                        }
                        catch
                        {
                        }
                        bool flag7 = this.OpenFileDialog1.ShowDialog() != DialogResult.Cancel;
                        bool flag8 = flag7;
                        if (flag8)
                        {
                            try
                            {
                                this.FileLocation = this.OpenFileDialog1.FileName; 
                                this.savedshit = File.ReadAllText(this.FileLocation);
                                if (usingaceeditor == yes)
                                {
                                    this.webBrowser1.Document.InvokeScript("SetText", new object[]
                                 {
                     File.ReadAllText(this.OpenFileDialog1.FileName)
                                 });

                                }
                                if (usingmonaco == yes)
                                {

                                    this.MonacoShit.Document.InvokeScript("SetText", new object[]
                                {
                     File.ReadAllText(this.OpenFileDialog1.FileName)
                                });
                                }
                                if (usingscintilla == yes)
                                {
                                    this.scintilla2.Text = File.ReadAllText(this.OpenFileDialog1.FileName);
                                }

                            }
                            catch
                            {
                            }
                        }
                    }
                    else
                    {
                        bool flag9 = dialogResult == DialogResult.No;
                        bool flag10 = flag9;
                        if (flag10)
                        {
                            bool flag11 = this.OpenFileDialog1.ShowDialog() != DialogResult.Cancel;
                            bool flag12 = flag11;
                            if (flag12)
                            {
                                try
                                {
                                    this.FileLocation = this.OpenFileDialog1.FileName; 
                                    this.savedshit = File.ReadAllText(this.FileLocation);

                                    if (usingaceeditor == yes)
                                    {
                                        this.webBrowser1.Document.InvokeScript("SetText", new object[]
                                     {
                     File.ReadAllText(this.OpenFileDialog1.FileName)
                                     });

                                    }
                                    if (usingmonaco == yes)
                                    {

                                        this.MonacoShit.Document.InvokeScript("SetText", new object[]
                                    {
                     File.ReadAllText(this.OpenFileDialog1.FileName)
                                    });
                                    }
                                    if (usingscintilla == yes)
                                    {
                                        this.scintilla2.Text = File.ReadAllText(this.OpenFileDialog1.FileName);
                                    }

                                }
                                catch
                                {
                                }
                            }
                        }
                    }
                }
                else
                {
                    bool flag11 = this.OpenFileDialog1.ShowDialog() != DialogResult.Cancel;
                    bool flag12 = flag11;
                    if (flag12)
                    {
                        try
                        {
                            this.FileLocation = this.OpenFileDialog1.FileName;
                            this.savedshit = File.ReadAllText(this.FileLocation);
                            if (usingaceeditor == yes)
                            {
                                this.webBrowser1.Document.InvokeScript("SetText", new object[]
                             {
                     File.ReadAllText(this.OpenFileDialog1.FileName)
                             });
                               
                            }
                            if (usingmonaco == yes)
                            {

                                this.MonacoShit.Document.InvokeScript("SetText", new object[]
                            {
                     File.ReadAllText(this.OpenFileDialog1.FileName)
                            });
                            }
                            if (usingscintilla == yes)
                            {
                                this.scintilla2.Text = File.ReadAllText(this.OpenFileDialog1.FileName);
                            }
                           
                           
                        }
                        catch
                        {
                        }
                    }
                }
                
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
          

            bool flag = this.FileLocation == "";
            bool flag2 = flag;
            if (flag2)
            {
                bool flag3 = this.saveFileDialog1.ShowDialog() != DialogResult.Cancel;
                bool flag4 = flag3;
                if (flag4)
                {
                    try
                    {
                        this.FileLocation = this.saveFileDialog1.FileName;
                        File.Create(this.saveFileDialog1.FileName).Close();
                        if (usingaceeditor == yes)
                        {
                            HtmlDocument document = this.webBrowser1.Document;
                            string scriptName = "GetText";
                            object[] array = new string[0];
                            object[] args = array;
                            string text = document.InvokeScript(scriptName, args).ToString();
                            File.WriteAllText(this.saveFileDialog1.FileName, text);
                        }
                        if (usingmonaco == yes)
                        {

                            HtmlDocument document = this.MonacoShit.Document;
                            string scriptName = "GetText";
                            object[] array = new string[0];
                            object[] args = array;
                            string text = document.InvokeScript(scriptName, args).ToString();
                            File.WriteAllText(this.saveFileDialog1.FileName, text);
                        }
                        if (usingscintilla == yes)
                        {
                            File.WriteAllText(this.saveFileDialog1.FileName, this.scintilla2.Text);
                        }
                    }
                    catch
                    {
                    }
                }
            }
            else
            {
                if (ischanged == true)
                {
                    try
                    {
                        if (usingaceeditor == yes)
                        {
                            HtmlDocument document = this.webBrowser1.Document;
                            string scriptName = "GetText";
                            object[] array = new string[0];
                            object[] args = array;
                            string text = document.InvokeScript(scriptName, args).ToString();
                            File.WriteAllText(this.FileLocation, text);
                        }
                        if (usingmonaco == yes)
                        {

                            HtmlDocument document = this.MonacoShit.Document;
                            string scriptName = "GetText";
                            object[] array = new string[0];
                            object[] args = array;
                            string text = document.InvokeScript(scriptName, args).ToString();
                            File.WriteAllText(this.FileLocation, text);
                        }
                        if (usingscintilla == yes)
                        {
                            File.WriteAllText(this.FileLocation, this.scintilla2.Text);
                        }

                        this.savedshit = File.ReadAllText(this.FileLocation);
                        this.Text = FileLocation + " - NotePad";
                    }
                    catch
                    {
                    }
                }
                else
                {
                    try
                    {
                        if (usingaceeditor == yes)
                        {
                            HtmlDocument document = this.webBrowser1.Document;
                            string scriptName = "GetText";
                            object[] array = new string[0];
                            object[] args = array;
                            string text = document.InvokeScript(scriptName, args).ToString();
                            File.WriteAllText(this.FileLocation, text);
                        }
                        if (usingmonaco == yes)
                        {

                            HtmlDocument document = this.MonacoShit.Document;
                            string scriptName = "GetText";
                            object[] array = new string[0];
                            object[] args = array;
                            string text = document.InvokeScript(scriptName, args).ToString();
                            File.WriteAllText(this.FileLocation, text);
                        }
                        if (usingscintilla == yes)
                        {
                            File.WriteAllText(this.FileLocation, this.scintilla2.Text);
                        }

                        this.savedshit = File.ReadAllText(this.FileLocation);
                        this.Text = FileLocation + " - NotePad";
                    }
                    catch
                    {
                    }
                }

               
            }
        }

        private async void Exe_Click(object sender, EventArgs e)
        {
            
            isAttached.Enabled = false;
            timer1.Enabled = false;
            string script = this.scintilla2.Text;
            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    if (usingaceeditor == yes)
                    {
                        HtmlDocument document = this.webBrowser1.Document;
                        string scriptName = "GetText";
                        object[] array = new string[0];
                        object[] args = array;
                        string text = document.InvokeScript(scriptName, args).ToString();
                        Functions.Lib.Execute(text);

                    }
                    if (usingmonaco == yes)
                    {
                        HtmlDocument document = this.MonacoShit.Document;
                        string scriptName = "GetText";
                        object[] array = new string[0];
                        object[] args = array;
                        string text = document.InvokeScript(scriptName, args).ToString();
                        Functions.Lib.Execute(text);
                    }
                    if (usingscintilla == yes)
                    {
                        Functions.Lib.Execute(script);
                    }
                    
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;

        }

        private async void button1_Click_1(object sender, EventArgs e)
        {
            
        }

        private void isAttached_Tick(object sender, EventArgs e)
        {
            


            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad [Hooked]";
                    }
                    else
                    {
                        if (ischanged == true)
                        {
                            this.Text ="*"+ FileLocation + " - NotePad [Hooked]";
                        }
                        else
                        {
                            this.Text = FileLocation + " - NotePad [Hooked]";
                        }
                        
                    }

                }

                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        if (ischanged == true)
                        {
                            this.Text = "*" + FileLocation + " - NotePad";
                        }
                        else
                        {
                            this.Text = FileLocation + " - NotePad";
                        }
                    }

                }
            }

        }

        private void dToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
        }

        private void scintilla2_KeyDown(object sender, KeyEventArgs e)
        {
            Keys key = ~(Keys.Shift | Keys.Control);
            if (e.KeyCode == ~(Keys.Control & Keys.N))
            {
                New_TOOL.PerformClick();
            } 
            switch (key)
            {
                case Keys.N:

                    if ((Keys.Control) != 0)
                    {
                        
                    }
                    break;
                case Keys.S:
                    if ((Keys.Control) != 0)
                    {
                        saveToolStripMenuItem.PerformClick();
                    }
                    break;
                case Keys.O:
                    if ((Keys.Control) != 0)
                    {
                        openToolStripMenuItem.PerformClick();

                    }
                    break;


                default:
                    return;

            }
        }

        private void iTalk_Button_21_Click(object sender, EventArgs e)
        {
            this.Text = FileLocation;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            
        }
       
        private void timer2_Tick(object sender, EventArgs e)
        {
            if (tastebread == true)
            {
                if (Process.GetProcessesByName("RobloxPlayerBeta").Length == 1) //로블켜져있을때
                {

                }
                else
                {
                    fullbrightToggleToolStripMenuItem.Checked = false;
                    tastebread = false;
                }
            }
            else
            {

            }
            
            
        }
        bool 연결된적있음;

        bool 니거;
        private void isrunning_Tick(object sender, EventArgs e)
        {
            if (Process.GetProcessesByName("RobloxPlayerBeta").Length == 1) //로블켜져있을때
            {
                if (Loaded == true)
                {
                    if (Functions.Lib.Ready() == true)//로블켜져있고 연결됨
                    {
                        연결된적있음 = true;
                        if (니거 == false)
                        {
                            string niga = this.inicls.GetIniValue("Settings", "InjectedMes", "./Nbin/Settings.ini");
                            if (niga == "")
                            {
                                string bb = this.inicls.GetIniValue("Settings", "AutoLaunch", "./Nbin/Settings.ini");
                                if (bb == "False")
                                {
                                    try
                                    {
                                        Functions.Lib.Execute("wait(1)\ngame.StarterGui:SetCore('SendNotification', {\nTitle = 'NotePad';\nText = 'Power by NotePad';\nIcon = '';\nDuration = 8;\n})");
                                    }
                                    catch (Exception ex)
                                    {
                                        Functions.Lib.Execute("Print('error : " + ex + "')");
                                    }
                                }

                                니거 = true;
                            }
                            else if (niga == "True")
                            {
                                string bb = this.inicls.GetIniValue("Settings", "AutoLaunch", "./Nbin/Settings.ini");
                                if (bb == "False")
                                {
                                    try
                                    {
                                        Functions.Lib.Execute("wait(1)\ngame.StarterGui:SetCore('SendNotification', {\nTitle = 'NotePad';\nText = 'Power by NotePad';\nIcon = '';\nDuration = 8;\n})");
                                    }
                                    catch (Exception ex)
                                    {
                                        Functions.Lib.Execute("Print('error : " + ex + "')");
                                    }
                                }
                                니거 = true;
                            }
                            else if (niga == "False")
                            {

                            }
                        }


                        //
                    }
                    else//로블은 켜져있는데 연결은 안됨
                    {

                    }
                }
                
            }
            else//로블 꺼져있음
            {
                if (연결된적있음 == true)
                {
                    니거 = false;
                }
            }
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool flag = this.saveFileDialog1.ShowDialog() != DialogResult.Cancel;
            bool flag2 = flag;
            if (flag2)
            {
                try
                {
                    this.FileLocation = this.saveFileDialog1.FileName;
                    File.Create(this.saveFileDialog1.FileName).Close();
                    if (usingaceeditor == yes)
                    {
                        HtmlDocument document = this.webBrowser1.Document;
                        string scriptName = "GetText";
                        object[] array = new string[0];
                        object[] args = array;
                        string text = document.InvokeScript(scriptName, args).ToString();
                        File.WriteAllText(this.saveFileDialog1.FileName, text);
                    }
                    if (usingmonaco == yes)
                    {

                        HtmlDocument document = this.webBrowser1.Document;
                        string scriptName = "GetText";
                        object[] array = new string[0];
                        object[] args = array;
                        string text = document.InvokeScript(scriptName, args).ToString();
                        File.WriteAllText(this.saveFileDialog1.FileName, text);
                    }
                    if (usingscintilla == yes)
                    {
                        File.WriteAllText(this.saveFileDialog1.FileName, this.scintilla2.Text);
                    }
                    
                }
                catch
                {
                }
            }
        }

        private void scintilla2_CharAdded(object sender, CharAddedEventArgs e)
        {
            

            
        }

        private void scintilla2_InsertCheck(object sender, InsertCheckEventArgs e)
        {
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void selectAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            scintilla2.SelectAll();
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            scintilla2.Undo();
        }

        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            scintilla2.Redo();
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            scintilla2.Cut();
        }

        private void deleteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.scintilla2 != null)
            {
                scintilla2.Text = scintilla2.Text.Replace(scintilla2.SelectedText, "");

            }
        }

        private void NotePad_MouseHover(object sender, EventArgs e)
        {
           
        }

        private void niggerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!usingscintilla)
            {
                MessageBox.Show("this only use scintilla NET editor, sorry.");
            }
        }

        private void niggerToolStripMenuItem_VisibleChanged(object sender, EventArgs e)
        {
            
        }

        private void niggerToolStripMenuItem_MouseEnter(object sender, EventArgs e)
        {
            
            DataObject retrievedData = (DataObject)Clipboard.GetDataObject();
            if (retrievedData == null)
            {
                pasteToolStripMenuItem.Enabled = false;
            }
            else
            {
                pasteToolStripMenuItem.Enabled = true;
            }
            bool da = scintilla2.SelectedText == "";

            if (da)
            {
                cutToolStripMenuItem.Enabled = false;
                copyToolStripMenuItem.Enabled = false;
                deleteToolStripMenuItem.Enabled = false;
                searchWithBingToolStripMenuItem.Enabled = false;
            }
            else
            {
                cutToolStripMenuItem.Enabled = true;
                copyToolStripMenuItem.Enabled = true;
                deleteToolStripMenuItem.Enabled = true;
                searchWithBingToolStripMenuItem.Enabled = true;
            }

            
        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(scintilla2.SelectedText);
        }

        private void searchWithBingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string niggershit = scintilla2.SelectedText.Replace(" ","+");
            string linkl1 = "https://www.bing.com/search?q=" + niggershit;

            Process.Start(linkl1);
        }

        public static string niggershit = "";
        private void serchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            niggershit = "serach";
            ScintillaFindReplaceControl.FindReplace da = new ScintillaFindReplaceControl.FindReplace();
            da.Show(this);
        }

        private void replaceToolStripMenuItem_Click(object sender, EventArgs e)
        {
            niggershit = "replace";
            ScintillaFindReplaceControl.FindReplace da = new ScintillaFindReplaceControl.FindReplace();
            da.Show(this);
            
        }

        private void sendFeedbackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FeedBack fuckthatshitniggershitsuckmydickandsomebitcheslikemelolthisisfeelgoodlol = new FeedBack();
            fuckthatshitniggershitsuckmydickandsomebitcheslikemelolthisisfeelgoodlol.ShowDialog();
        }

        private void helpToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("what u gon do");
        }

        private async void injectToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;
            if (Loaded == true)
            {
                
                    Functions.Lib.Attach();
                    Functions.Lib.AttachEvent += SynAttachEvent;
               
                   
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
        }

        private async void executeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;
            string script = this.scintilla2.Text;
            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    if (usingaceeditor == yes)
                    {
                        HtmlDocument document = this.webBrowser1.Document;
                        string scriptName = "GetText";
                        object[] array = new string[0];
                        object[] args = array;
                        string text = document.InvokeScript(scriptName, args).ToString();
                        Functions.Lib.Execute(text);

                    }
                    if (usingmonaco == yes)
                    {
                        HtmlDocument document = this.MonacoShit.Document;
                        string scriptName = "GetText";
                        object[] array = new string[0];
                        object[] args = array;
                        string text = document.InvokeScript(scriptName, args).ToString();
                        Functions.Lib.Execute(text);
                    }
                    if (usingscintilla == yes)
                    {
                        Functions.Lib.Execute(script);
                    }
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
        }
        
        public void SetTarget(Scintilla scintilla)
        {
            scintilla2 = scintilla;
        }


        public void SetFind(Scintilla scintilla)
        {
            ScintillaFindReplaceControl.FindReplace frm = (ScintillaFindReplaceControl.FindReplace)this.Owner;
            frm.tabControlFindReplace.SelectTab(0);
            scintilla2 = scintilla;
        }


        public void SetReplace(Scintilla scintilla)
        {
            ScintillaFindReplaceControl.FindReplace frm = (ScintillaFindReplaceControl.FindReplace)this.Owner;

            frm.tabControlFindReplace.SelectTab(1);
            scintilla2 = scintilla;
        }




        public void buttonFindPrev_Click()
        {
            ScintillaFindReplaceControl.FindReplace frm = (ScintillaFindReplaceControl.FindReplace)this.Owner;

            frm.SetFindSearchFlags();
            var text = frm.textBoxFind.Text;
            FindPrevious(text, frm._findSearchFlags);
        }

        public void buttonFindNext(string niga)
        {
            ScintillaFindReplaceControl.FindReplace frm = (ScintillaFindReplaceControl.FindReplace)this.Owner;
            frm.SetFindSearchFlags();
            var text = frm.textBoxFind.Text;
            FindNext(text,frm._findSearchFlags);
        }

      

        public void buttonReplaceNext_Click()
        {
            ScintillaFindReplaceControl.FindReplace frm = (ScintillaFindReplaceControl.FindReplace)this.Owner;
            frm.SetReplaceSearchFlags();

            frm.ReplaceNext(frm.textBoxFindRep.Text, frm.textBoxReplace.Text);
        }

        public void nigger_button_replace_next(string replaceText)
        {
            scintilla2.ReplaceSelection(replaceText);
        }

        public void buttonReplaceAll_Click()
        {
           

            scintilla2.CurrentPosition = 0;
            scintilla2.AnchorPosition = 0;
        }
        public void buttonReplaceAl32l_Click()
        {
            var currentPos = scintilla2.CurrentPosition;
            var currentAnchorPos = scintilla2.AnchorPosition;
            scintilla2.CurrentPosition = currentPos;
            scintilla2.AnchorPosition = currentAnchorPos;
        }


        public int FindNext(string text, SearchFlags searchFlags)
        {
            scintilla2.SearchFlags = searchFlags;
            scintilla2.TargetStart = Math.Max(scintilla2.CurrentPosition, scintilla2.AnchorPosition);
            scintilla2.TargetEnd = scintilla2.TextLength;

            var pos = scintilla2.SearchInTarget(text);
            if (pos >= 0)
                scintilla2.SetSel(scintilla2.TargetStart, scintilla2.TargetEnd);

            return pos;
        }

   
        public int FindPrevious(string text, SearchFlags searchFlags)
        {
            scintilla2.SearchFlags = searchFlags;
            scintilla2.TargetStart = Math.Min(scintilla2.CurrentPosition, scintilla2.AnchorPosition);
            scintilla2.TargetEnd = 0;

            var pos = scintilla2.SearchInTarget(text);
            if (pos >= 0)
                scintilla2.SetSel(scintilla2.TargetStart, scintilla2.TargetEnd);
            
            return pos;
        }

        private void wordWrapToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void wordWrapToolStripMenuItem_CheckedChanged(object sender, EventArgs e)
        {
            if (wordWrapToolStripMenuItem.Checked == true)
            {
                scintilla2.WrapMode = WrapMode.Word;
            }
            else
            {
                scintilla2.WrapMode = WrapMode.None;
            }
        }
        string FontShit;
        private void nigToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FontDialog fontDlg = new FontDialog();
            fontDlg.ShowColor = true;
            fontDlg.ShowApply = true;
            fontDlg.ShowEffects = true;
            fontDlg.ShowHelp = true;
            if (fontDlg.ShowDialog() != DialogResult.Cancel)
            {
                
                FontShit = fontDlg.Font.Name.ToString();


                this.scintilla2.ForeColor = Color.Black;
                this.scintilla2.BackColor = Color.FromArgb(101, 148, 239);
                string str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
                string str2 = "0123456789";
                string str3 = "ŠšŒœŸÿÀàÁáÂâÃãÄäÅåÆæÇçÈèÉéÊêËëÌìÍíÎîÏïÐðÑñÒòÓóÔôÕõÖØøÙùÚúÛûÜüÝýÞþßö";
                this.scintilla2.StyleResetDefault();

                this.scintilla2.Styles[32].Font = FontShit;

                this.scintilla2.Styles[32].Size = 11;
                this.scintilla2.StyleClearAll();
                this.scintilla2.Styles[0].ForeColor = Color.Silver;
                this.scintilla2.Styles[1].ForeColor = Color.FromArgb(0, 0, 127, 0);
                this.scintilla2.Styles[2].ForeColor = Color.FromArgb(0, 0, 127, 0);
                this.scintilla2.Styles[4].ForeColor = Color.FromArgb(0, 0, 127, 127);
                this.scintilla2.Styles[5].ForeColor = Color.FromArgb(0, 0, 0, 127);
                this.scintilla2.Styles[13].ForeColor = Color.FromArgb(0, 255, 128, 0);
                this.scintilla2.Styles[14].ForeColor = Color.FromArgb(0, 255, 0, 0);
                this.scintilla2.Styles[15].ForeColor = Color.DarkSlateBlue;
                this.scintilla2.Styles[6].ForeColor = Color.FromArgb(0, 127, 0, 127);
                this.scintilla2.Styles[7].ForeColor = Color.FromArgb(0, 127, 0, 127);
                this.scintilla2.Styles[8].ForeColor = Color.FromArgb(0, 127, 0, 127);
                this.scintilla2.Styles[10].ForeColor = Color.FromArgb(0, 127, 127, 127);
                this.scintilla2.Styles[9].ForeColor = Color.Maroon;
                this.scintilla2.Lexer = Lexer.Lua;
                this.scintilla2.WordChars = str + str2 + str3;
                this.scintilla2.SetKeywords(0, "info and break do else elseif end for function if in local nil not or repeat return then until while false true goto assert collectgarbage dofile _G getmetatable ipairs loadfile next pairs pcall print rawequal rawget rawset metatable setmetatable tonumber tostring type _VERSION xpcall string table math coroutine io os debug getfenv gcinfo load loadlib loadstring require select setfenv unpack _LOADED LUA_PATH _REQUIREDNAME package rawlen package bit32 utf8 _ENV string.byte string.char string.dump string.find string.format string.gsub string.len string.lower string.rep string.sub string.upper table.concat table.insert table.remove table.sort math.abs math.acos math.asin math.atan math.atan2 math.ceil math.cos math.deg math.exp math.floor math.frexp math.ldexp math.log math.max math.min math.pi math.pow math.rad math.random math.randomseed math.sin math.sqrt math.tan string.gfind string.gmatch string.match string.reverse string.pack string.packsize string.unpack table.foreach table.foreachi table.getn table.setn table.maxn table.pack table.unpack table.move math.cosh math.fmod math.huge math.log10 math.modf math.mod math.sinh math.tanh math.maxinteger math.mininteger math.tointeger math.type math.ult bit32.arshift bit32.band bit32.bnot bit32.bor bit32.btest bit32.bxor bit32.extract bit32.replace bit32.lrotate bit32.lshift bit32.rrotate bit32.rshift utf8.char utf8.charpattern utf8.codes utf8.codepoint utf8.len utf8.offset coroutine.create coroutine.resume coroutine.status coroutine.wrap coroutine.yield io.close io.flush io.input io.lines io.open io.output io.read io.tmpfile io.type io.write io.stdin io.stdout io.stderr os.clock os.date os.difftime os.execute os.exit os.getenv os.remove os.rename os.setlocale os.time os.tmpname coroutine.isyieldable coroutine.running io.popen module package.loaders package.seeall package.config package.searchers package.searchpath require package.cpath package.loaded package.loadlib package.path package.preload");
                this.scintilla2.SetKeywords(1, "warn");
                this.scintilla2.SetKeywords(2, "error");
                this.scintilla2.SetKeywords(3, "getgenv getrenv getreg getgc getinstances getnilinstances getscripts getloadedmodules getconnections firesignal fireclickdetector fireproximityprompt firetouchinterest isnetworkowner gethiddenproperty sethiddenproperty setsimulationradius getsenv getcallingscript getscriptclosure getscripthash getrawmetatable setrawmetatable setreadonly isreadonly iswindowactive keypress keyrelease mouse1click mouse1press mouse1release mouse2click mouse2press mouse2release mousescroll mousemoverel mousemoveabs checkcaller islclosure dumpstring decompile listfiles isfile isfolder makefolder delfolder delfile setclipboard setfflag getnamecallmethod setnamecallmethod getsynasset getspecialinfo saveinstance messagebox syn.crypt.encrypt syn syn.crypt.decrypt syn.crypt.base64.encode syn.crypt.base64.decode syn.crypt.hash syn.crypt.derive syn.crypt.random syn.crypt.custom.encrypt syn.crypt.custom.decrypt syn.crypt.custom.hash debug.getconstants debug.getconstant debug.setconstant debug.getupvalues debug.getupvalue debug.setupvalue debug.getprotos debug.getproto debug.setproto debug.getstack debug.setstack debug.setmetatable debug.getregistry debug.getinfo Drawing syn.cache_replace syn.cache_invalidate syn.set_thread_identity syn.get_thread_identity syn.is_cached syn.write_clipboard syn.queue_on_teleport syn.protect_gui syn.unprotect_gui syn.is_beta syn.request syn.secure_call syn.create_secure_function syn.run_secure_function syn.websocket.connect WebSocket:Send WebSocket:Close ");
                this.scintilla2.SetProperty("fold", "1");
                this.scintilla2.SetProperty("fold.compact", "1");
                this.scintilla2.Margins[1].Type = MarginType.Symbol;
                this.scintilla2.Margins[1].Mask = 4261412864U;
                this.scintilla2.Margins[1].Sensitive = true;
                this.scintilla2.Margins[1].Width = 20;
                for (int i = 25; i <= 31; i++)
                {
                    this.scintilla2.Markers[i].SetForeColor(SystemColors.ControlLightLight);
                    this.scintilla2.Markers[i].SetBackColor(SystemColors.ControlDark);
                }
                this.scintilla2.Markers[30].Symbol = MarkerSymbol.BoxPlus;
                this.scintilla2.Markers[31].Symbol = MarkerSymbol.BoxMinus;
                this.scintilla2.Markers[25].Symbol = MarkerSymbol.BoxPlusConnected;
                this.scintilla2.Markers[27].Symbol = MarkerSymbol.TCorner;
                this.scintilla2.Markers[26].Symbol = MarkerSymbol.BoxMinusConnected;
                this.scintilla2.Markers[29].Symbol = MarkerSymbol.VLine;
                this.scintilla2.Markers[28].Symbol = MarkerSymbol.LCorner;
                this.scintilla2.AutomaticFold = (AutomaticFold.Show | AutomaticFold.Click | AutomaticFold.Change);
                //scintilla2.SetSelectionForeColor(true,Color.FromArgb(32,32,32));
                scintilla2.SetSelectionBackColor(true, Color.FromArgb(0, 127, 127));

              

               
                this.inicls.SetIniValue("Font", "font", FontShit, "./Nbin/Settings.ini");
            }
        }

        private void iTalk_Button_11_Click(object sender, EventArgs e)
        {
           
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
        }

        private void scintilla2_SizeChanged(object sender, EventArgs e)
        {
            listBox1.Height = scintilla2.Size.Height;
        }

        private void refreshToolStripMenuItem_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            Functions.PopulateListBox(listBox1, "./Scripts", "*.txt");
            Functions.PopulateListBox(listBox1, "./Scripts", "*.lua");
        }
        public void TOpMost(bool val)
        {
            base.TopMost = val;
        }
        private async void executeToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;
            string script = File.ReadAllText($"./Scripts/{listBox1.SelectedItem}");
            bool niga = listBox1.SelectedIndex == -1;
            if (!niga)
            {
                if (Loaded == true)
                {
                    if (Functions.Lib.Ready() == true)
                    {
                        Functions.Lib.Execute(script);
                    }
                    else
                    {
                        if (FileLocation == "")
                        {
                            this.Text = "NotePad (NotePad is Not Attached!)";
                        }
                        else
                        {
                            this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                        }
                        await Task.Delay(1500);
                        if (FileLocation == "")
                        {
                            this.Text = "NotePad";
                        }
                        else
                        {
                            this.Text = FileLocation + " - NotePad";
                        }
                    }
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Loaded!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }

                }
                isAttached.Enabled = true;
                timer1.Enabled = true;
            }
            
        }
        bool mousein = false;
        private void listBox1_MouseHover(object sender, EventArgs e)
        {
            mousein = true;
        }

        private void listBox1_MouseLeave(object sender, EventArgs e)
        {
            mousein = false;
        }
        [DllImport("user32.dll")]
        static extern void mouse_event(uint dwFlags, uint dx, uint dy, uint dwData, int dwExtraInfo);

        private const uint MOUSEEVENTF_RDOWN = 0x0002;      // The left button is down.
        private const uint MOUSEEVENTF_RUP = 0x0004;
        private void listBox1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == System.Windows.Forms.MouseButtons.Right)
            {
                
                 mouse_event(MOUSEEVENTF_RDOWN, 0, 0, 0, 0);
                 mouse_event(MOUSEEVENTF_RUP, 0, 0, 0, 0);
               

            }
        }

        private void scriptListBoxToolStripMenuItem_CheckedChanged(object sender, EventArgs e)
        {
            if (scriptListBoxToolStripMenuItem.Checked == true)
            {
                webBrowser1.Width -= 228;
                MonacoShit.Width -= 228;
                scintilla2.Width -= 228;
                listBox1.Show();
            }
            else
            {
                webBrowser1.Width += 228;
                MonacoShit.Width += 228;
                scintilla2.Width += 228;
                listBox1.Hide();
            }
        }

        private void loadToEditorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            bool niga = listBox1.SelectedIndex == -1;
            if (!niga)
            {
                if (usingaceeditor == yes)
                {
                    this.webBrowser1.Document.InvokeScript("SetText", new object[]
                {
                    File.ReadAllText($"./Scripts/{listBox1.SelectedItem}")
                });
                   

                }
                if (usingmonaco == yes)
                {
                    this.MonacoShit.Document.InvokeScript("SetText", new object[]
                {
                    File.ReadAllText($"./Scripts/{listBox1.SelectedItem}")
                });
                }
                if (usingscintilla == yes)
                {
                    scintilla2.Text = File.ReadAllText($"./Scripts/{listBox1.SelectedItem}");
                }
               
            }
        }

        private void setDefaultFontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.scintilla2.ForeColor = Color.Black;
            this.scintilla2.BackColor = Color.FromArgb(101, 148, 239);
            string str = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string str2 = "0123456789";
            string str3 = "ŠšŒœŸÿÀàÁáÂâÃãÄäÅåÆæÇçÈèÉéÊêËëÌìÍíÎîÏïÐðÑñÒòÓóÔôÕõÖØøÙùÚúÛûÜüÝýÞþßö";
            this.scintilla2.StyleResetDefault();
            //this.scintilla2.Styles[32].Font = "Consolas";
                this.scintilla2.Styles[32].Font = "Consolas";
            this.scintilla2.Styles[32].Size = 11;
            this.scintilla2.StyleClearAll();
            this.scintilla2.Styles[0].ForeColor = Color.Silver;
            this.scintilla2.Styles[1].ForeColor = Color.FromArgb(0, 0, 127, 0);
            this.scintilla2.Styles[2].ForeColor = Color.FromArgb(0, 0, 127, 0);
            this.scintilla2.Styles[4].ForeColor = Color.FromArgb(0, 0, 127, 127);
            this.scintilla2.Styles[5].ForeColor = Color.FromArgb(0, 0, 0, 127);
            this.scintilla2.Styles[13].ForeColor = Color.FromArgb(0, 255, 128, 0);
            this.scintilla2.Styles[14].ForeColor = Color.FromArgb(0, 255, 0, 0);
            this.scintilla2.Styles[15].ForeColor = Color.DarkSlateBlue;
            this.scintilla2.Styles[6].ForeColor = Color.FromArgb(0, 127, 0, 127);
            this.scintilla2.Styles[7].ForeColor = Color.FromArgb(0, 127, 0, 127);
            this.scintilla2.Styles[8].ForeColor = Color.FromArgb(0, 127, 0, 127);
            this.scintilla2.Styles[10].ForeColor = Color.FromArgb(0, 127, 127, 127);
            this.scintilla2.Styles[9].ForeColor = Color.Maroon;
            this.scintilla2.Lexer = Lexer.Lua;
            this.scintilla2.WordChars = str + str2 + str3;
            this.scintilla2.SetKeywords(0, "info and break do else elseif end for function if in local nil not or repeat return then until while false true goto assert collectgarbage dofile _G getmetatable ipairs loadfile next pairs pcall print rawequal rawget rawset metatable setmetatable tonumber tostring type _VERSION xpcall string table math coroutine io os debug getfenv gcinfo load loadlib loadstring require select setfenv unpack _LOADED LUA_PATH _REQUIREDNAME package rawlen package bit32 utf8 _ENV string.byte string.char string.dump string.find string.format string.gsub string.len string.lower string.rep string.sub string.upper table.concat table.insert table.remove table.sort math.abs math.acos math.asin math.atan math.atan2 math.ceil math.cos math.deg math.exp math.floor math.frexp math.ldexp math.log math.max math.min math.pi math.pow math.rad math.random math.randomseed math.sin math.sqrt math.tan string.gfind string.gmatch string.match string.reverse string.pack string.packsize string.unpack table.foreach table.foreachi table.getn table.setn table.maxn table.pack table.unpack table.move math.cosh math.fmod math.huge math.log10 math.modf math.mod math.sinh math.tanh math.maxinteger math.mininteger math.tointeger math.type math.ult bit32.arshift bit32.band bit32.bnot bit32.bor bit32.btest bit32.bxor bit32.extract bit32.replace bit32.lrotate bit32.lshift bit32.rrotate bit32.rshift utf8.char utf8.charpattern utf8.codes utf8.codepoint utf8.len utf8.offset coroutine.create coroutine.resume coroutine.status coroutine.wrap coroutine.yield io.close io.flush io.input io.lines io.open io.output io.read io.tmpfile io.type io.write io.stdin io.stdout io.stderr os.clock os.date os.difftime os.execute os.exit os.getenv os.remove os.rename os.setlocale os.time os.tmpname coroutine.isyieldable coroutine.running io.popen module package.loaders package.seeall package.config package.searchers package.searchpath require package.cpath package.loaded package.loadlib package.path package.preload");
            this.scintilla2.SetKeywords(1, "warn");
            this.scintilla2.SetKeywords(2, "error");
            this.scintilla2.SetKeywords(3, "getgenv getrenv getreg getgc getinstances getnilinstances getscripts getloadedmodules getconnections firesignal fireclickdetector fireproximityprompt firetouchinterest isnetworkowner gethiddenproperty sethiddenproperty setsimulationradius getsenv getcallingscript getscriptclosure getscripthash getrawmetatable setrawmetatable setreadonly isreadonly iswindowactive keypress keyrelease mouse1click mouse1press mouse1release mouse2click mouse2press mouse2release mousescroll mousemoverel mousemoveabs checkcaller islclosure dumpstring decompile listfiles isfile isfolder makefolder delfolder delfile setclipboard setfflag getnamecallmethod setnamecallmethod getsynasset getspecialinfo saveinstance messagebox syn.crypt.encrypt syn syn.crypt.decrypt syn.crypt.base64.encode syn.crypt.base64.decode syn.crypt.hash syn.crypt.derive syn.crypt.random syn.crypt.custom.encrypt syn.crypt.custom.decrypt syn.crypt.custom.hash debug.getconstants debug.getconstant debug.setconstant debug.getupvalues debug.getupvalue debug.setupvalue debug.getprotos debug.getproto debug.setproto debug.getstack debug.setstack debug.setmetatable debug.getregistry debug.getinfo Drawing syn.cache_replace syn.cache_invalidate syn.set_thread_identity syn.get_thread_identity syn.is_cached syn.write_clipboard syn.queue_on_teleport syn.protect_gui syn.unprotect_gui syn.is_beta syn.request syn.secure_call syn.create_secure_function syn.run_secure_function syn.websocket.connect WebSocket:Send WebSocket:Close ");
            this.scintilla2.SetProperty("fold", "1");
            this.scintilla2.SetProperty("fold.compact", "1");
            this.scintilla2.Margins[1].Type = MarginType.Symbol;
            this.scintilla2.Margins[1].Mask = 4261412864U;
            this.scintilla2.Margins[1].Sensitive = true;
            this.scintilla2.Margins[1].Width = 20;
            for (int i = 25; i <= 31; i++)
            {
                this.scintilla2.Markers[i].SetForeColor(SystemColors.ControlLightLight);
                this.scintilla2.Markers[i].SetBackColor(SystemColors.ControlDark);
            }
            this.scintilla2.Markers[30].Symbol = MarkerSymbol.BoxPlus;
            this.scintilla2.Markers[31].Symbol = MarkerSymbol.BoxMinus;
            this.scintilla2.Markers[25].Symbol = MarkerSymbol.BoxPlusConnected;
            this.scintilla2.Markers[27].Symbol = MarkerSymbol.TCorner;
            this.scintilla2.Markers[26].Symbol = MarkerSymbol.BoxMinusConnected;
            this.scintilla2.Markers[29].Symbol = MarkerSymbol.VLine;
            this.scintilla2.Markers[28].Symbol = MarkerSymbol.LCorner;
            this.scintilla2.AutomaticFold = (AutomaticFold.Show | AutomaticFold.Click | AutomaticFold.Change);
            //scintilla2.SetSelectionForeColor(true,Color.FromArgb(32,32,32));
            scintilla2.SetSelectionBackColor(true, Color.FromArgb(0, 127, 127));

            this.inicls.SetIniValue("Font", "font", "Consolas", "./Nbin/Settings.ini");

        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void listBox1_MouseUp(object sender, MouseEventArgs e)
        {
            bool niga = listBox1.SelectedIndex == -1;
            if (niga)
            {
                executeToolStripMenuItem1.Visible = false;
                loadToEditorToolStripMenuItem.Visible = false;
            }
            else
            {
                executeToolStripMenuItem1.Visible = true;
                loadToEditorToolStripMenuItem.Visible = true;
            }
        }


        public void ugly_highlight_text(bool niga)
        {
            niggertextbox.Text = niga.ToString();
        }
        private async void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;
            if (Loaded == true)
            {
                Shitings ВлинДибилЗамолчиПошёлтыКакогоЧёртаyoimnotrussian = new Shitings(this);
                ВлинДибилЗамолчиПошёлтыКакогоЧёртаyoimnotrussian.Show();
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;

        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            scintilla2.Paste();
        }

        private async void darkDexToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;

            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    NotePad.data = "Dark Dex";
                    Functions.Lib.ScriptHub();
                    Functions.Lib.ScriptHubMarkAsClosed();
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
        }
        
        internal static string data;
        private async void remoteSpyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;
            
            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    NotePad.data = "Remote Spy";
                    Functions.Lib.ScriptHub();
                    Functions.Lib.ScriptHubMarkAsClosed();
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
            
        }

        private async void unnamedToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;

            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    NotePad.data = "Unnamed ESP";
                    Functions.Lib.ScriptHub();
                    Functions.Lib.ScriptHubMarkAsClosed();
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
        }

        private async void darkGUIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;

            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    Functions.Lib.Execute("loadstring(game:HttpGet('https://raw.githubusercontent.com/RandomAdamYT/DarkHub/master/Init', true))()");
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
        }

        private async void ctrlClickTPToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;

            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    Functions.Lib.Execute("loadstring(game:HttpGet('https://pastebin.com/raw/zv5ca4M7', true))()");
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
        }

        private async void antiAFKToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            isAttached.Enabled = false;
            timer1.Enabled = false;

            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    Functions.Lib.Execute("loadstring(game:HttpGet('https://pastebin.com/raw/UHpr9CG5', true))()");
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
        }

        private async void gameSenseToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            isAttached.Enabled = false;
            timer1.Enabled = false;

            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    Functions.Lib.Execute("loadstring(game:HttpGet(('https://pastebin.com/raw/cdPJxGDU'),true))()");
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
        }

        private void killRobloxToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (Process process in Process.GetProcessesByName("RobloxPlayerBeta"))
                {
                    process.Kill();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error : \n" + ex);
            }
        }

        private void updateLogToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("the hilight text color is changed pretty color :)\n\nand fixed TopMost bugshit");
        }

        private void niggertextbox_TextChanged(object sender, EventArgs e)
        {
            if (niggertextbox.Text == "True")
            {
                this.TopMost = true;
            }
            else if (niggertextbox.Text == "False")
            {
                this.TopMost = false;
            }
            else
            {
                MessageBox.Show("BItch", niggertextbox.Text);
            }
        }

        private void okItsBugShitToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private async void infiniteYieldFEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;

            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    Functions.Lib.Execute("loadstring(game:HttpGet(('https://raw.githubusercontent.com/EdgeIY/infiniteyield/master/source'),true))()");
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
        }

        private void multiRolobxToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void multiRolobxToolStripMenuItem_CheckedChanged(object sender, EventArgs e)
        {
            if (multiRolobxToolStripMenuItem.Checked == true)
            {
                //new Mutex(true, "ROBLOX_singletonMutex");
                CreateMutex(IntPtr.Zero, true, "ROBLOX_singletonMutex");
            }
            else
            {
                new Mutex(false, "ROBLOX_singletonMutex");
                
            }
        }

        private void robloxAppBetaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("roblox-player://roblox-player:+launchmode:app+robloxLocale:en_us+gameLocale:en_us+LaunchExp:InApp");
        }
        bool tastebread;
        private async void fullbrightToggleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;

            if (Loaded == true)
            {
                if (Functions.Lib.Ready() == true)
                {
                    
                    if (this.fullbrightToggleToolStripMenuItem.Checked == true)
                    {
                        Functions.Lib.Execute("if not _G.FullBrightExecuted then\n_G.FullBrightEnabled = false\n_G.NormalLightingSettings = {\nBrightness = game:GetService('Lighting').Brightness,\nClockTime = game:GetService('Lighting').ClockTime,\nFogEnd = game:GetService('Lighting').FogEnd,\nGlobalShadows = game:GetService('Lighting').GlobalShadows,\nAmbient = game:GetService('Lighting').Ambient\n}\ngame:GetService('Lighting'):GetPropertyChangedSignal('Brightness'):Connect(function()\nif game:GetService('Lighting').Brightness ~= 1 and game:GetService('Lighting').Brightness ~= _G.NormalLightingSettings.Brightness then\n_G.NormalLightingSettings.Brightness = game:GetService('Lighting').Brightness\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').Brightness = 1\nend\nend)\ngame:GetService('Lighting'):GetPropertyChangedSignal('ClockTime'):Connect(function()\nif game:GetService('Lighting').ClockTime ~= 12 and game:GetService('Lighting').ClockTime ~= _G.NormalLightingSettings.ClockTime then\n_G.NormalLightingSettings.ClockTime = game:GetService('Lighting').ClockTime\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').ClockTime = 12\nend\nend)\ngame:GetService('Lighting'):GetPropertyChangedSignal('FogEnd'):Connect(function()\nif game:GetService('Lighting').FogEnd ~= 786543 and game:GetService('Lighting').FogEnd ~= _G.NormalLightingSettings.FogEnd then\n_G.NormalLightingSettings.FogEnd = game:GetService('Lighting').FogEnd\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').FogEnd = 786543\nend\nend)\ngame:GetService('Lighting'):GetPropertyChangedSignal('GlobalShadows'):Connect(function()\nif game:GetService('Lighting').GlobalShadows ~= false and game:GetService('Lighting').GlobalShadows ~= _G.NormalLightingSettings.GlobalShadows then\n_G.NormalLightingSettings.GlobalShadows = game:GetService('Lighting').GlobalShadows\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').GlobalShadows = false\nend\nend)\ngame:GetService('Lighting'):GetPropertyChangedSignal('Ambient'):Connect(function()\nif game:GetService('Lighting').Ambient ~= Color3.fromRGB(178, 178, 178) and game:GetService('Lighting').Ambient ~= _G.NormalLightingSettings.Ambient then\n_G.NormalLightingSettings.Ambient = game:GetService('Lighting').Ambient\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').Ambient = Color3.fromRGB(178, 178, 178)\nend\nend)\ngame:GetService('Lighting').Brightness = 1\ngame:GetService('Lighting').ClockTime = 12\ngame:GetService('Lighting').FogEnd = 786543\ngame:GetService('Lighting').GlobalShadows = false\ngame:GetService('Lighting').Ambient = Color3.fromRGB(178, 178, 178)\nlocal LatestValue = true\nspawn(function()\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nwhile wait() do\nif _G.FullBrightEnabled ~= LatestValue then\nif not _G.FullBrightEnabled then\ngame:GetService('Lighting').Brightness = _G.NormalLightingSettings.Brightness\ngame:GetService('Lighting').ClockTime = _G.NormalLightingSettings.ClockTime\ngame:GetService('Lighting').FogEnd = _G.NormalLightingSettings.FogEnd\ngame:GetService('Lighting').GlobalShadows = _G.NormalLightingSettings.GlobalShadows\ngame:GetService('Lighting').Ambient = _G.NormalLightingSettings.Ambient\nelse\ngame:GetService('Lighting').Brightness = 1\ngame:GetService('Lighting').ClockTime = 12\ngame:GetService('Lighting').FogEnd = 786543\ngame:GetService('Lighting').GlobalShadows = false\ngame:GetService('Lighting').Ambient = Color3.fromRGB(178, 178, 178)\nend\nLatestValue = not LatestValue\nend\nend\nend)\nend\n_G.FullBrightExecuted = true\n_G.FullBrightEnabled = not _G.FullBrightEnabled");
                        tastebread = true;
                        this.fullbrightToggleToolStripMenuItem.Checked = false;
                    }
                    else
                    {
                        Functions.Lib.Execute("if not _G.FullBrightExecuted then\n_G.FullBrightEnabled = false\n_G.NormalLightingSettings = {\nBrightness = game:GetService('Lighting').Brightness,\nClockTime = game:GetService('Lighting').ClockTime,\nFogEnd = game:GetService('Lighting').FogEnd,\nGlobalShadows = game:GetService('Lighting').GlobalShadows,\nAmbient = game:GetService('Lighting').Ambient\n}\ngame:GetService('Lighting'):GetPropertyChangedSignal('Brightness'):Connect(function()\nif game:GetService('Lighting').Brightness ~= 1 and game:GetService('Lighting').Brightness ~= _G.NormalLightingSettings.Brightness then\n_G.NormalLightingSettings.Brightness = game:GetService('Lighting').Brightness\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').Brightness = 1\nend\nend)\ngame:GetService('Lighting'):GetPropertyChangedSignal('ClockTime'):Connect(function()\nif game:GetService('Lighting').ClockTime ~= 12 and game:GetService('Lighting').ClockTime ~= _G.NormalLightingSettings.ClockTime then\n_G.NormalLightingSettings.ClockTime = game:GetService('Lighting').ClockTime\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').ClockTime = 12\nend\nend)\ngame:GetService('Lighting'):GetPropertyChangedSignal('FogEnd'):Connect(function()\nif game:GetService('Lighting').FogEnd ~= 786543 and game:GetService('Lighting').FogEnd ~= _G.NormalLightingSettings.FogEnd then\n_G.NormalLightingSettings.FogEnd = game:GetService('Lighting').FogEnd\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').FogEnd = 786543\nend\nend)\ngame:GetService('Lighting'):GetPropertyChangedSignal('GlobalShadows'):Connect(function()\nif game:GetService('Lighting').GlobalShadows ~= false and game:GetService('Lighting').GlobalShadows ~= _G.NormalLightingSettings.GlobalShadows then\n_G.NormalLightingSettings.GlobalShadows = game:GetService('Lighting').GlobalShadows\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').GlobalShadows = false\nend\nend)\ngame:GetService('Lighting'):GetPropertyChangedSignal('Ambient'):Connect(function()\nif game:GetService('Lighting').Ambient ~= Color3.fromRGB(178, 178, 178) and game:GetService('Lighting').Ambient ~= _G.NormalLightingSettings.Ambient then\n_G.NormalLightingSettings.Ambient = game:GetService('Lighting').Ambient\nif not _G.FullBrightEnabled then\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nend\ngame:GetService('Lighting').Ambient = Color3.fromRGB(178, 178, 178)\nend\nend)\ngame:GetService('Lighting').Brightness = 1\ngame:GetService('Lighting').ClockTime = 12\ngame:GetService('Lighting').FogEnd = 786543\ngame:GetService('Lighting').GlobalShadows = false\ngame:GetService('Lighting').Ambient = Color3.fromRGB(178, 178, 178)\nlocal LatestValue = true\nspawn(function()\nrepeat\nwait()\nuntil _G.FullBrightEnabled\nwhile wait() do\nif _G.FullBrightEnabled ~= LatestValue then\nif not _G.FullBrightEnabled then\ngame:GetService('Lighting').Brightness = _G.NormalLightingSettings.Brightness\ngame:GetService('Lighting').ClockTime = _G.NormalLightingSettings.ClockTime\ngame:GetService('Lighting').FogEnd = _G.NormalLightingSettings.FogEnd\ngame:GetService('Lighting').GlobalShadows = _G.NormalLightingSettings.GlobalShadows\ngame:GetService('Lighting').Ambient = _G.NormalLightingSettings.Ambient\nelse\ngame:GetService('Lighting').Brightness = 1\ngame:GetService('Lighting').ClockTime = 12\ngame:GetService('Lighting').FogEnd = 786543\ngame:GetService('Lighting').GlobalShadows = false\ngame:GetService('Lighting').Ambient = Color3.fromRGB(178, 178, 178)\nend\nLatestValue = not LatestValue\nend\nend\nend)\nend\n_G.FullBrightExecuted = true\n_G.FullBrightEnabled = not _G.FullBrightEnabled");
                        tastebread = true;
                        this.fullbrightToggleToolStripMenuItem.Checked = true;
                    }
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;
            
        }

        private async void executeLineToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }
       
        private async void cToolStripMenuItem_Click(object sender, EventArgs e)
        {
            isAttached.Enabled = false;
            timer1.Enabled = false;
            
            if (Loaded == true)
            {
                if (!usingscintilla)
                {
                    MessageBox.Show("Execute Line only use scintilla NET editor, sorry.");
                }
                else
                {
                

                if (Functions.Lib.Ready() == true)
                {
                    if (!File.Exists("./Nbin/line.nigger"))
                    {
                        File.Create("./Nbin/line.nigger").Close();
                    }
                    File.WriteAllText("./Nbin/line.nigger", scintilla2.Text);
                    string path = "./Nbin/line.nigger";
                    using (FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
                    {
                        int lineNum = 1;
                        StreamReader reader = new StreamReader(fs);
                        while (!reader.EndOfStream)
                        {
                            if (lineNum == scintilla2.CurrentLine + 1)
                            {
                                Functions.Lib.Execute(reader.ReadLine());
                            }
                            else
                            {
                                reader.ReadLine();
                            }
                            lineNum++;
                        }
                        reader.Close();
                    }
                }
                else
                {
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad (NotePad is Not Attached!)";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad (NotePad is Not Attached!)";
                    }
                    await Task.Delay(1500);
                    if (FileLocation == "")
                    {
                        this.Text = "NotePad";
                    }
                    else
                    {
                        this.Text = FileLocation + " - NotePad";
                    }
                }
                }
            }
            else
            {
                if (FileLocation == "")
                {
                    this.Text = "NotePad (NotePad is Not Loaded!)";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad (NotePad is Not Loaded!)";
                }
                await Task.Delay(1500);
                if (FileLocation == "")
                {
                    this.Text = "NotePad";
                }
                else
                {
                    this.Text = FileLocation + " - NotePad";
                }

            }
            isAttached.Enabled = true;
            timer1.Enabled = true;


           
        }

        private void dToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(scintilla2.CurrentLine.ToString());
        }

        private void textboxToolStripMenuItem_CheckedChanged(object sender, EventArgs e)
        {
           
        }
       
        private void scintillaNETToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (scintillaNETToolStripMenuItem.Checked == true)
            {
                
                this.inicls.SetIniValue("Editor", "V", "scintilla", "./Nbin/Settings.ini");
                webBrowser1.Visible = no;
                scintilla2.Visible = yes;
                MonacoShit.Visible = no;

                usingscintilla = true;
                usingmonaco = false;
                usingaceeditor = false;
            }
            else
            {
                
               
                if (usingaceeditor == true)
            {
                HtmlDocument document = this.webBrowser1.Document;
                string scriptName = "GetText";
                object[] array = new string[0];
                object[] args = array;
                string text = document.InvokeScript(scriptName, args).ToString();
                scintilla2.Text = text;
            }

            else if (usingmonaco == true)
            {
                HtmlDocument document = this.MonacoShit.Document;
                string scriptName = "GetText";
                object[] array = new string[0];
                object[] args = array;
                string text = document.InvokeScript(scriptName, args).ToString();

                scintilla2.Text = text;

            }
                this.inicls.SetIniValue("Editor", "V", "scintilla", "./Nbin/Settings.ini");
                webBrowser1.Visible = no;
                scintilla2.Visible = yes;
                MonacoShit.Visible = no;

                usingscintilla = true;
                usingmonaco = false;
                usingaceeditor=false;

                scintillaNETToolStripMenuItem.Checked = true;
                aceEditorToolStripMenuItem.Checked = false;
                monacoToolStripMenuItem.Checked = false;
            }
        }

        private void aceEditorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (aceEditorToolStripMenuItem.Checked == true)
            {

                
                this.inicls.SetIniValue("Editor", "V", "ace", "./Nbin/Settings.ini");
                webBrowser1.Visible = true;
                scintilla2.Visible = false;
                MonacoShit.Visible = no;
                //
                usingscintilla = false;
                usingmonaco = false;
                usingaceeditor = true;

            }
            else
            {



                if (usingscintilla == true)
                {
                    this.webBrowser1.Document.InvokeScript("SetText", new object[]
                {
                    scintilla2.Text
                });
                }

                else if (usingmonaco == true)
                {
                    HtmlDocument document = this.MonacoShit.Document;
                    string scriptName = "GetText";
                    object[] array = new string[0];
                    object[] args = array;
                    string text = document.InvokeScript(scriptName, args).ToString();

                    this.webBrowser1.Document.InvokeScript("SetText", new object[]
                   {
                    text
                   });

                }

                this.inicls.SetIniValue("Editor", "V", "ace", "./Nbin/Settings.ini");
                webBrowser1.Visible = true;
                scintilla2.Visible = false;
                MonacoShit.Visible = no;
                //
                usingscintilla = false;
                usingmonaco = false;
                usingaceeditor = true;

                aceEditorToolStripMenuItem.Checked = true;
                scintillaNETToolStripMenuItem.Checked = false;
                monacoToolStripMenuItem.Checked = false;
            }
        }

        private void monacoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (monacoToolStripMenuItem.Checked == true)
            {
                
                this.inicls.SetIniValue("Editor", "V", "monaco", "./Nbin/Settings.ini");
                webBrowser1.Visible = no;
                scintilla2.Visible = no;
                MonacoShit.Visible = yes;
                
                //
                usingscintilla = no;
                usingmonaco = yes;
                usingaceeditor = no;
            }
            else
            {


                if (usingaceeditor == true)
                {
                    HtmlDocument document = this.webBrowser1.Document;
                    string scriptName = "GetText";
                    object[] array = new string[0];
                    object[] args = array;
                    string text = document.InvokeScript(scriptName, args).ToString();

                    this.MonacoShit.Document.InvokeScript("SetText", new object[]
               {
                   text
               });
                }

                else if (usingscintilla == true)
                {

                    this.MonacoShit.Document.InvokeScript("SetText", new object[]
                {
                    scintilla2.Text
                });


                }
                this.inicls.SetIniValue("Editor", "V", "monaco", "./Nbin/Settings.ini");
                webBrowser1.Visible = no;
                scintilla2.Visible = no;
                MonacoShit.Visible = yes;
               
                //
                usingscintilla = no;
                usingmonaco = yes;
                usingaceeditor = no;

                aceEditorToolStripMenuItem.Checked = no;
                scintillaNETToolStripMenuItem.Checked = no;
                monacoToolStripMenuItem.Checked = yes;
            }
        }

        private void textboxToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private async void MonacoShit_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            string GetSettingEditor = this.inicls.GetIniValue("Editor", "V", "./Nbin/Settings.ini");
            if (GetSettingEditor == "scintilla")
            {
                this.scintilla2.Text = File.ReadAllText("./Nbin/INPUT");
            }
            else if (GetSettingEditor == "monaco")
            {
                await Task.Delay(500);
                string gnia = File.ReadAllText("./Nbin/INPUT");
                this.MonacoShit.Document.InvokeScript("SetText", new object[]
                {
                   gnia
                });

            }
            else if (GetSettingEditor == "ace")
            {
                string gnidasa = File.ReadAllText("./Nbin/INPUT");
                this.webBrowser1.Document.InvokeScript("SetText", new object[]
                 {
                   gnidasa
                 });
            }
            else
            {
                this.scintilla2.Text = File.ReadAllText("./Nbin/INPUT");
            }


            string fa = this.inicls.GetIniValue("Theme", "Monaco", "./Nbin/Settings.ini");
            if (fa == "Light")
            {
                this.MonacoShit.Document.InvokeScript("SetTheme", new object[]{
                 "Light"
            });
                lightToolStripMenuItem.Checked = true;
            }
            if (fa == "Dark")
            {
                this.MonacoShit.Document.InvokeScript("SetTheme", new object[]{
                 "Dark"
            });
                darkToolStripMenuItem.Checked = true;
            }
            else
            {
                this.MonacoShit.Document.InvokeScript("SetTheme", new object[]{
                 "Light"
            });
                lightToolStripMenuItem.Checked = true;
            }
        }

        private void lightToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (lightToolStripMenuItem.Checked == true)
            {
                lightToolStripMenuItem.Checked = true;
            }
            else
            {
                darkToolStripMenuItem.Checked = false;
                lightToolStripMenuItem.Checked = true;
                this.inicls.SetIniValue("Theme", "Monaco", "Light", "./Nbin/Settings.ini");
                this.MonacoShit.Document.InvokeScript("SetTheme", new object[]{
                 "Light"
            });
            }
           
        }

        private void darkToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (darkToolStripMenuItem.Checked == true)
            {
                darkToolStripMenuItem.Checked = true;
            }
            else
            {
                darkToolStripMenuItem.Checked = true;
                lightToolStripMenuItem.Checked = false;
                this.inicls.SetIniValue("Theme", "Monaco", "Dark", "./Nbin/Settings.ini");
                this.MonacoShit.Document.InvokeScript("SetTheme", new object[]{
                 "Dark"
                 });
            }
            
        }

        private void scriptListBoxToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void formatToolStripMenuItem1_MouseEnter(object sender, EventArgs e)
        {
           
        }

        private void formatToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            if (!usingscintilla)
            {
                MessageBox.Show("this only use scintilla NET editor, sorry.");
            }
        }

        private void formatToolStripMenuItem1_MouseDown(object sender, MouseEventArgs e)
        {

        }
    }

}
